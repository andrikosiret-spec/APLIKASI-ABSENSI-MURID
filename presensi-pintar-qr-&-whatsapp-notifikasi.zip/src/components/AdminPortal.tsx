import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Users, 
  GraduationCap, 
  Settings, 
  FileText, 
  MessageSquare, 
  Plus, 
  Trash2, 
  Edit3, 
  Search, 
  Download, 
  Printer, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Save, 
  RotateCcw, 
  Check, 
  X, 
  School,
  ExternalLink,
  Send,
  Phone,
  UserCheck,
  TrendingUp,
  CreditCard,
  Camera,
  Layers,
  Sparkles,
  Eye,
  UserPlus,
  HelpCircle,
  Info
} from 'lucide-react';
import { Siswa, Guru, PengaturanSekolah, PresensiRecord, StatusKehadiran } from '../types';
import { 
  getSiswaList, 
  saveSiswa, 
  deleteSiswa, 
  getGuruList, 
  saveGuru, 
  deleteGuru, 
  getPresensiRecords, 
  deletePresensiRecord,
  getDaftarKelas,
  addKelas,
  deleteKelas,
  getWaliKelasMap,
  saveWaliKelasForClass,
  getSettings, 
  saveSettings, 
  resetToDefaultData, 
  subscribeToDataChanges 
} from '../services/storage';
import { WhatsAppPreviewModal } from './WhatsAppPreviewModal';
import { ProfilSekolahTab } from './ProfilSekolahTab';
import { ConfirmDeleteModal } from './ConfirmDeleteModal';
import { TooltipNozzle } from './TooltipNozzle';

interface AdminPortalProps {
  settings: PengaturanSekolah;
  onSettingsUpdated: (newSettings: PengaturanSekolah) => void;
}

export const AdminPortal: React.FC<AdminPortalProps> = ({
  settings,
  onSettingsUpdated,
}) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'profil_sekolah' | 'murid' | 'guru' | 'kelas' | 'rekap' | 'pengaturan'>('dashboard');

  const [students, setStudents] = useState<Siswa[]>([]);
  const [teachers, setTeachers] = useState<Guru[]>([]);
  const [records, setRecords] = useState<PresensiRecord[]>([]);
  const [daftarKelas, setDaftarKelas] = useState<string[]>([]);
  const [waliKelasMap, setWaliKelasMap] = useState<Record<string, string>>({});
  
  // Class Management State
  const [newKelasInput, setNewKelasInput] = useState<string>('');
  const [newWaliInput, setNewWaliInput] = useState<string>('');
  const [kelasAddError, setKelasAddError] = useState<string | null>(null);

  // Manual Wali Kelas Modal State
  const [waliModal, setWaliModal] = useState<{
    isOpen: boolean;
    kelas: string;
    namaWali: string;
  }>({
    isOpen: false,
    kelas: '',
    namaWali: '',
  });

  // Murid filters & Modal
  const [selectedClassFilter, setSelectedClassFilter] = useState<string>('all');
  const [searchStudent, setSearchStudent] = useState<string>('');
  const [studentModalOpen, setStudentModalOpen] = useState<boolean>(false);
  const [editingStudent, setEditingStudent] = useState<Siswa | null>(null);

  // Murid Form State
  const [formNisn, setFormNisn] = useState<string>('');
  const [formNama, setFormNama] = useState<string>('');
  const [formKelas, setFormKelas] = useState<string>('7A');
  const [formJK, setFormJK] = useState<'L' | 'P'>('L');
  const [formNamaOrtu, setFormNamaOrtu] = useState<string>('');
  const [formNoHpOrtu, setFormNoHpOrtu] = useState<string>('');
  const [formAlamat, setFormAlamat] = useState<string>('');

  // Teacher Form Modal
  const [teacherModalOpen, setTeacherModalOpen] = useState<boolean>(false);
  const [editingTeacher, setEditingTeacher] = useState<Guru | null>(null);
  const [formGuruNip, setFormGuruNip] = useState<string>('');
  const [formGuruNama, setFormGuruNama] = useState<string>('');
  const [formGuruEmail, setFormGuruEmail] = useState<string>('');
  const [formGuruNoHp, setFormGuruNoHp] = useState<string>('');
  const [formGuruWali, setFormGuruWali] = useState<string>('7A');
  const [formGuruMapel, setFormGuruMapel] = useState<string>('');

  // Delete Confirmation Modal State
  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    title: string;
    itemName: string;
    itemType: string;
    description?: string;
    onConfirm: () => void;
    isDangerAll?: boolean;
    confirmButtonText?: string;
  }>({
    isOpen: false,
    title: '',
    itemName: '',
    itemType: '',
    onConfirm: () => {},
  });

  // Photo Zoom Modal State
  const [photoZoomModal, setPhotoZoomModal] = useState<{
    isOpen: boolean;
    photoUrl: string;
    title: string;
    subtitle: string;
  }>({
    isOpen: false,
    photoUrl: '',
    title: '',
    subtitle: '',
  });

  // Settings local state
  const [settingsForm, setSettingsForm] = useState<PengaturanSekolah>(settings);
  const [saveSuccessNotice, setSaveSuccessNotice] = useState<boolean>(false);

  // Rekap Date Filter
  const [rekapDate, setRekapDate] = useState<string>(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  });
  const [rekapClassFilter, setRekapClassFilter] = useState<string>('all');
  const [rekapStatusFilter, setRekapStatusFilter] = useState<string>('all');

  // WhatsApp Preview state
  const [activeWaRecord, setActiveWaRecord] = useState<{ record: PresensiRecord; student: Siswa } | null>(null);

  const loadData = () => {
    setStudents(getSiswaList());
    setTeachers(getGuruList());
    setRecords(getPresensiRecords());
    setDaftarKelas(getDaftarKelas());
    setWaliKelasMap(getWaliKelasMap());
    setSettingsForm(getSettings());
  };

  useEffect(() => {
    loadData();
    const unsub = subscribeToDataChanges(loadData);
    return () => unsub();
  }, []);

  // Today stats
  const today = rekapDate;
  const todayRecords = records.filter(r => r.tanggal === today);
  const totalStudents = students.length || 1;
  const hadirCount = todayRecords.filter(r => r.status === 'hadir').length;
  const terlambatCount = todayRecords.filter(r => r.status === 'terlambat').length;
  const sakitCount = todayRecords.filter(r => r.status === 'sakit').length;
  const izinCount = todayRecords.filter(r => r.status === 'izin').length;
  const alpaCount = Math.max(0, totalStudents - (hadirCount + terlambatCount + sakitCount + izinCount));
  const persentaseHadir = Math.round(((hadirCount + terlambatCount) / totalStudents) * 100);

  // Open add/edit student modal
  const handleOpenStudentModal = (studentToEdit?: Siswa) => {
    const defaultKelas = daftarKelas.length > 0 ? daftarKelas[0] : '7A';
    if (studentToEdit) {
      setEditingStudent(studentToEdit);
      setFormNisn(studentToEdit.nisn);
      setFormNama(studentToEdit.nama);
      setFormKelas(studentToEdit.kelas);
      setFormJK(studentToEdit.jenisKelamin);
      setFormNamaOrtu(studentToEdit.namaOrangTua);
      setFormNoHpOrtu(studentToEdit.noHpOrangTua);
      setFormAlamat(studentToEdit.alamat || '');
    } else {
      setEditingStudent(null);
      setFormNisn(`009${Math.floor(1000000 + Math.random() * 9000000)}`);
      setFormNama('');
      setFormKelas(defaultKelas);
      setFormJK('L');
      setFormNamaOrtu('');
      setFormNoHpOrtu('0812');
      setFormAlamat('');
    }
    setStudentModalOpen(true);
  };

  const handleSaveStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formNisn.trim() || !formNama.trim() || !formNoHpOrtu.trim()) {
      alert('Mohon lengkapi NISN, Nama Murid, dan Nomor WhatsApp Orang Tua.');
      return;
    }

    const newStudent: Siswa = {
      id: editingStudent ? editingStudent.id : `S${Date.now().toString().slice(-4)}`,
      nisn: formNisn.trim(),
      nama: formNama.trim(),
      kelas: formKelas,
      jenisKelamin: formJK,
      namaOrangTua: formNamaOrtu.trim() || 'Wali Murid',
      noHpOrangTua: formNoHpOrtu.trim(),
      alamat: formAlamat.trim(),
      pin: '1234',
      terdaftarPada: editingStudent ? editingStudent.terdaftarPada : new Date().toISOString().split('T')[0],
      fotoUrl: editingStudent?.fotoUrl || `https://images.unsplash.com/photo-${formJK === 'L' ? '1506794778202-cad84cf45f1d' : '1534528741775-53994a69daeb'}?w=150&auto=format&fit=crop&q=80`,
    };

    saveSiswa(newStudent);
    setStudentModalOpen(false);
    loadData();
  };

  const handleDeleteStudent = (id: string, nama: string) => {
    setDeleteModal({
      isOpen: true,
      title: 'Hapus Data Murid Terdaftar',
      itemName: `${nama} (ID: ${id})`,
      itemType: 'Murid',
      description: 'Apakah Anda yakin bahwa Anda akan menghapus data murid ini? Murid yang dihapus tidak akan dapat melakukan scan presensi.',
      onConfirm: () => {
        deleteSiswa(id);
        loadData();
      },
    });
  };

  // Class Management Handlers
  const handleAddKelas = (e: React.FormEvent) => {
    e.preventDefault();
    setKelasAddError(null);
    if (!newKelasInput.trim()) return;
    const cleanKelas = newKelasInput.trim().toUpperCase();
    const success = addKelas(cleanKelas);
    if (success) {
      if (newWaliInput.trim()) {
        saveWaliKelasForClass(cleanKelas, newWaliInput.trim());
      }
      setNewKelasInput('');
      setNewWaliInput('');
      loadData();
    } else {
      setKelasAddError(`Kelas "${cleanKelas}" sudah ada dalam daftar.`);
    }
  };

  const handleDeleteKelas = (namaKelas: string) => {
    const studentCount = students.filter(s => s.kelas === namaKelas).length;
    setDeleteModal({
      isOpen: true,
      title: 'Hapus Rombongan Belajar (Kelas)',
      itemName: `Kelas ${namaKelas} (${studentCount} murid terdaftar)`,
      itemType: 'Kelas',
      description: `Apakah Anda yakin bahwa Anda akan menghapus Kelas ${namaKelas}? ${
        studentCount > 0 ? `Perhatian: Terdapat ${studentCount} murid yang masih berada di kelas ini.` : ''
      }`,
      onConfirm: () => {
        deleteKelas(namaKelas);
        loadData();
      },
    });
  };

  // Manual Wali Kelas Edit Handler
  const handleOpenWaliModal = (kelas: string) => {
    const currentName = waliKelasMap[kelas] || teachers.find(t => t.waliKelas === kelas)?.nama || '';
    setWaliModal({
      isOpen: true,
      kelas,
      namaWali: currentName,
    });
  };

  const handleSaveWaliModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!waliModal.kelas) return;
    saveWaliKelasForClass(waliModal.kelas, waliModal.namaWali.trim());
    setWaliModal({ isOpen: false, kelas: '', namaWali: '' });
    loadData();
  };

  // Teacher handlers
  const handleOpenTeacherModal = (guruToEdit?: Guru) => {
    const defaultKelas = daftarKelas.length > 0 ? daftarKelas[0] : '7A';
    if (guruToEdit) {
      setEditingTeacher(guruToEdit);
      setFormGuruNip(guruToEdit.nip);
      setFormGuruNama(guruToEdit.nama);
      setFormGuruEmail(guruToEdit.email);
      setFormGuruNoHp(guruToEdit.noHp);
      setFormGuruWali(guruToEdit.waliKelas || defaultKelas);
      setFormGuruMapel(guruToEdit.mataPelajaran || '');
    } else {
      setEditingTeacher(null);
      setFormGuruNip('19850101 201001 1 001');
      setFormGuruNama('');
      setFormGuruEmail('');
      setFormGuruNoHp('0812');
      setFormGuruWali(defaultKelas);
      setFormGuruMapel('Pendidikan Agama Islam');
    }
    setTeacherModalOpen(true);
  };

  const handleSaveTeacher = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formGuruNama.trim()) return;

    const newGuru: Guru = {
      id: editingTeacher ? editingTeacher.id : `G${Date.now().toString().slice(-3)}`,
      nip: formGuruNip.trim(),
      nama: formGuruNama.trim(),
      email: formGuruEmail.trim(),
      noHp: formGuruNoHp.trim(),
      waliKelas: formGuruWali,
      mataPelajaran: formGuruMapel.trim(),
      fotoUrl: editingTeacher?.fotoUrl || 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    };

    saveGuru(newGuru);
    // Also sync wali kelas map if assigned
    if (formGuruWali && formGuruWali !== 'none') {
      saveWaliKelasForClass(formGuruWali, formGuruNama.trim());
    }
    setTeacherModalOpen(false);
    loadData();
  };

  const handleDeleteTeacher = (id: string, nama: string) => {
    setDeleteModal({
      isOpen: true,
      title: 'Hapus Data Guru / Wali Kelas',
      itemName: `${nama} (NIP: ${id})`,
      itemType: 'Guru',
      description: 'Apakah Anda yakin bahwa Anda akan menghapus data guru ini?',
      onConfirm: () => {
        deleteGuru(id);
        loadData();
      },
    });
  };

  const handleDeletePresensi = (recordId: string, namaSiswa: string, tanggal: string) => {
    setDeleteModal({
      isOpen: true,
      title: 'Hapus Log Kehadiran Presensi',
      itemName: `${namaSiswa} - Tanggal ${tanggal}`,
      itemType: 'Data Presensi',
      description: 'Apakah Anda yakin ingin menghapus catatan presensi ini dari database?',
      onConfirm: () => {
        deletePresensiRecord(recordId);
        loadData();
      },
    });
  };

  const handleResetAllData = () => {
    setDeleteModal({
      isOpen: true,
      title: 'Konfirmasi Reset Seluruh Data Uji Coba',
      itemName: 'Database Sekolah, Murid, Guru & Log Presensi',
      itemType: 'Seluruh Database',
      description: 'Apakah Anda yakin ingin mengembalikan seluruh data ke data sampel bawaan awal? Tindakan ini akan menghapus data murid dan presensi yang baru Anda tambahkan.',
      isDangerAll: true,
      confirmButtonText: 'Ya, Reset Semua Data',
      onConfirm: () => {
        resetToDefaultData();
        loadData();
      },
    });
  };

  // Settings Save
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    saveSettings(settingsForm);
    onSettingsUpdated(settingsForm);
    setSaveSuccessNotice(true);
    setTimeout(() => setSaveSuccessNotice(false), 3000);
  };

  // Export CSV of Attendance Records
  const handleExportCSV = () => {
    const headers = ['ID Presensi', 'Tanggal', 'Waktu', 'NISN', 'Nama Murid', 'Kelas', 'Status', 'Keterlambatan (Mnt)', 'WA Terkirim', 'No HP Ortu'];
    const rows = filteredRekapRecords.map(r => {
      const siswa = students.find(s => s.id === r.siswaId);
      return [
        r.id,
        r.tanggal,
        r.waktuKedatangan,
        r.nisn,
        `"${r.namaSiswa}"`,
        r.kelas,
        r.status,
        r.menitKeterlambatan,
        r.waTerkirim ? 'Ya' : 'Belum',
        siswa?.noHpOrangTua || '-',
      ];
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Rekap_Presensi_${settings.namaSekolah.replace(/\s+/g, '_')}_${rekapDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filtered lists
  const filteredStudentsList = students.filter(s => {
    const matchClass = selectedClassFilter === 'all' || s.kelas === selectedClassFilter;
    const matchSearch = s.nama.toLowerCase().includes(searchStudent.toLowerCase()) || s.nisn.includes(searchStudent);
    return matchClass && matchSearch;
  });

  const filteredRekapRecords = records.filter(r => {
    const matchDate = !rekapDate || r.tanggal === rekapDate;
    const matchClass = rekapClassFilter === 'all' || r.kelas === rekapClassFilter;
    const matchStatus = rekapStatusFilter === 'all' || r.status === rekapStatusFilter;
    return matchDate && matchClass && matchStatus;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6">
      
      {/* Top Header Card */}
      <div className="bg-white border-2 border-blue-100 rounded-[32px] p-5 sm:p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <TooltipNozzle content="Panel Utama Pengelolaan Presensi Sekolah & Master Data Terpusat" badge="Admin" position="bottom">
            <div className="w-14 h-14 rounded-2xl bg-[#0EA5E9] flex items-center justify-center text-white font-bold shadow-lg shadow-sky-200 shrink-0">
              <ShieldCheck className="w-7 h-7 stroke-[2.5]" />
            </div>
          </TooltipNozzle>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-xl sm:text-2xl font-black text-[#1E293B]">
                Panel Kontrol Administrator
              </h2>
              <span className="px-3 py-0.5 rounded-full text-xs font-black bg-sky-100 text-[#0EA5E9] border border-sky-300">
                Penuh
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Pusat pengelolaan master data murid, nama wali kelas manual, rekapitulasi kehadiran sekolah, dan pengaturan WhatsApp.
            </p>
          </div>
        </div>

        {/* Global Tab Navigation */}
        <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1.5 rounded-2xl border border-slate-200 w-full md:w-auto">
          <TooltipNozzle content="Lihat ringkasan statistik kehadiran murid real-time hari ini" position="top">
            <button
              id="admin-tab-dashboard"
              onClick={() => setActiveTab('dashboard')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all ${
                activeTab === 'dashboard' ? 'bg-[#0EA5E9] text-white shadow-md shadow-sky-200 scale-[1.02]' : 'text-slate-600 hover:text-[#0EA5E9] hover:bg-white'
              }`}
            >
              Ringkasan
            </button>
          </TooltipNozzle>

          <TooltipNozzle content="Kelola profil lembaga, logo sekolah, visi-misi, dan data Kepala Sekolah" position="top">
            <button
              id="admin-tab-profil-sekolah"
              onClick={() => setActiveTab('profil_sekolah')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black flex items-center space-x-1.5 transition-all ${
                activeTab === 'profil_sekolah' ? 'bg-[#0EA5E9] text-white shadow-md shadow-sky-200 scale-[1.02]' : 'text-slate-600 hover:text-[#0EA5E9] hover:bg-white'
              }`}
            >
              <School className="w-3.5 h-3.5" />
              <span>Profil Sekolah</span>
            </button>
          </TooltipNozzle>

          <TooltipNozzle content="Tambah rombel kelas baru, hapus kelas, dan atur nama wali kelas secara manual" position="top">
            <button
              id="admin-tab-kelas"
              onClick={() => setActiveTab('kelas')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black flex items-center space-x-1.5 transition-all ${
                activeTab === 'kelas' ? 'bg-[#0EA5E9] text-white shadow-md shadow-sky-200 scale-[1.02]' : 'text-slate-600 hover:text-[#0EA5E9] hover:bg-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Kelola Kelas ({daftarKelas.length})</span>
            </button>
          </TooltipNozzle>

          <TooltipNozzle content="Kelola data ratusan murid, NISN, kelas, dan nomor WhatsApp orang tua" position="top">
            <button
              id="admin-tab-murid"
              onClick={() => setActiveTab('murid')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all ${
                activeTab === 'murid' ? 'bg-[#0EA5E9] text-white shadow-md shadow-sky-200 scale-[1.02]' : 'text-slate-600 hover:text-[#0EA5E9] hover:bg-white'
              }`}
            >
              Data Murid ({students.length})
            </button>
          </TooltipNozzle>

          <TooltipNozzle content="Kelola data guru pengajar dan wali kelas" position="top">
            <button
              id="admin-tab-guru"
              onClick={() => setActiveTab('guru')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all ${
                activeTab === 'guru' ? 'bg-[#0EA5E9] text-white shadow-md shadow-sky-200 scale-[1.02]' : 'text-slate-600 hover:text-[#0EA5E9] hover:bg-white'
              }`}
            >
              Guru & Wali ({teachers.length})
            </button>
          </TooltipNozzle>

          <TooltipNozzle content="Lihat log rekapitulasi presensi, filter tanggal/status, dan unduh CSV Excel" position="top">
            <button
              id="admin-tab-rekap"
              onClick={() => setActiveTab('rekap')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all ${
                activeTab === 'rekap' ? 'bg-[#0EA5E9] text-white shadow-md shadow-sky-200 scale-[1.02]' : 'text-slate-600 hover:text-[#0EA5E9] hover:bg-white'
              }`}
            >
              Laporan Rekap
            </button>
          </TooltipNozzle>

          <TooltipNozzle content="Atur jam operasional, toleransi keterlambatan, dan template pesan WhatsApp" position="top">
            <button
              id="admin-tab-settings"
              onClick={() => setActiveTab('pengaturan')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all ${
                activeTab === 'pengaturan' ? 'bg-[#0EA5E9] text-white shadow-md shadow-sky-200 scale-[1.02]' : 'text-slate-600 hover:text-[#0EA5E9] hover:bg-white'
              }`}
            >
              Pengaturan Jam & WA
            </button>
          </TooltipNozzle>
        </div>
      </div>

      {/* TAB 1: DASHBOARD ANALYTICS */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          {/* Main Key Figures */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <TooltipNozzle content="Total seluruh murid terdaftar dalam database sekolah" position="top" className="w-full">
              <div className="bg-white border-2 border-sky-100 p-5 rounded-3xl shadow-sm w-full">
                <div className="flex items-center justify-between text-slate-500 mb-2">
                  <span className="text-xs font-bold uppercase">Total Murid Terdaftar</span>
                  <GraduationCap className="w-5 h-5 text-[#0EA5E9]" />
                </div>
                <p className="text-3xl font-black text-[#1E293B]">{students.length}</p>
                <p className="text-xs text-slate-400 mt-1 font-medium">Terbagi dalam {daftarKelas.length} Rombel Kelas</p>
              </div>
            </TooltipNozzle>

            <TooltipNozzle content="Jumlah murid yang berhasil scan presensi sebelum jam masuk" position="top" className="w-full">
              <div className="bg-white border-2 border-emerald-100 p-5 rounded-3xl shadow-sm w-full">
                <div className="flex items-center justify-between text-emerald-600 mb-2">
                  <span className="text-xs font-bold uppercase">Hadir Tepat Waktu</span>
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <p className="text-3xl font-black text-emerald-700">{hadirCount}</p>
                <p className="text-xs text-emerald-600 mt-1 font-medium">≤ {settings.jamMasuk} WIB</p>
              </div>
            </TooltipNozzle>

            <TooltipNozzle content="Jumlah murid yang scan presensi setelah batas jam masuk" position="top" className="w-full">
              <div className="bg-white border-2 border-amber-100 p-5 rounded-3xl shadow-sm w-full">
                <div className="flex items-center justify-between text-amber-600 mb-2">
                  <span className="text-xs font-bold uppercase">Terlambat Hari Ini</span>
                  <Clock className="w-5 h-5" />
                </div>
                <p className="text-3xl font-black text-amber-700">{terlambatCount}</p>
                <p className="text-xs text-amber-600 mt-1 font-medium">Notifikasi WA otomatis</p>
              </div>
            </TooltipNozzle>

            <TooltipNozzle content="Persentase tingkat kehadiran seluruh murid hari ini" position="top" className="w-full">
              <div className="bg-white border-2 border-sky-100 p-5 rounded-3xl shadow-sm w-full">
                <div className="flex items-center justify-between text-[#0EA5E9] mb-2">
                  <span className="text-xs font-bold uppercase">Persentase Kehadiran</span>
                  <TrendingUp className="w-5 h-5" />
                </div>
                <p className="text-3xl font-black text-[#0EA5E9]">{persentaseHadir}%</p>
                <p className="text-xs text-slate-400 mt-1 font-medium">{hadirCount + terlambatCount} dari {totalStudents} Murid</p>
              </div>
            </TooltipNozzle>
          </div>

          {/* Per-Class Breakdown Grid */}
          <div className="bg-white border-2 border-blue-100 rounded-[32px] p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-black text-[#1E293B]">
                  Rekapitulasi Kehadiran Per Kelas ({rekapDate})
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Rincian presensi murid per rombel kelas beserta nama wali kelas yang bertugas.
                </p>
              </div>
              <TooltipNozzle content="Buka menu kelola kelas untuk tambah/edit rombel dan nama wali kelas" position="left">
                <button
                  onClick={() => setActiveTab('kelas')}
                  className="text-xs font-bold text-[#0EA5E9] hover:underline flex items-center space-x-1"
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>Kelola Kelas ({daftarKelas.length})</span>
                </button>
              </TooltipNozzle>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {daftarKelas.map(kelas => {
                const kStudents = students.filter(s => s.kelas === kelas);
                const kTotal = kStudents.length || 1;
                const kRecords = todayRecords.filter(r => r.kelas === kelas);
                const kHadir = kRecords.filter(r => r.status === 'hadir').length;
                const kTerlambat = kRecords.filter(r => r.status === 'terlambat').length;
                const kSakitIzin = kRecords.filter(r => r.status === 'sakit' || r.status === 'izin').length;
                const kMasuk = kHadir + kTerlambat;
                const kPercent = Math.round((kMasuk / kTotal) * 100);

                const currentWaliName = waliKelasMap[kelas] || teachers.find(t => t.waliKelas === kelas)?.nama || 'Belum diatur';

                return (
                  <div key={kelas} className="p-4 rounded-3xl bg-slate-50 border-2 border-slate-200/80 space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-black text-[#1E293B] text-base">Kelas {kelas}</h4>
                        <p className="text-[11px] text-slate-500 font-medium">Wali: <strong className="text-[#1E293B]">{currentWaliName}</strong></p>
                      </div>
                      <span className="px-3 py-1 rounded-full text-xs font-black bg-sky-100 text-[#0EA5E9] border border-sky-300">
                        {kPercent}% Hadir
                      </span>
                    </div>

                    {/* Progress bar */}
                    <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full"
                        style={{ width: `${kPercent}%` }}
                      />
                    </div>

                    <div className="grid grid-cols-3 text-center text-xs pt-1.5 border-t border-slate-200">
                      <div>
                        <span className="text-slate-400 text-[10px] font-bold">Hadir</span>
                        <p className="font-black text-emerald-700">{kHadir}</p>
                      </div>
                      <div>
                        <span className="text-slate-400 text-[10px] font-bold">Terlambat</span>
                        <p className="font-black text-amber-700">{kTerlambat}</p>
                      </div>
                      <div>
                        <span className="text-slate-400 text-[10px] font-bold">Izin/Sakit</span>
                        <p className="font-black text-[#0EA5E9]">{kSakitIzin}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick Management Banners */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-gradient-to-br from-sky-50 to-blue-50 border-2 border-sky-200 rounded-3xl p-5 flex items-start justify-between gap-4">
              <div className="space-y-1">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-[#0EA5E9] text-white">
                  Identitas Sekolah
                </span>
                <h4 className="text-base font-black text-[#1E293B] pt-1">
                  Atur Logo & Profil Lembaga
                </h4>
                <p className="text-xs text-slate-500">
                  Ubah nama sekolah, upload logo, lengkapi data NPSN, alamat, serta data Kepala Sekolah.
                </p>
                <div className="pt-2">
                  <TooltipNozzle content="Buka halaman konfigurasi profil sekolah dan kepala sekolah" position="top">
                    <button
                      onClick={() => setActiveTab('profil_sekolah')}
                      className="px-4 py-2 bg-[#0EA5E9] hover:bg-sky-600 text-white font-bold rounded-xl text-xs flex items-center space-x-1.5 shadow-md shadow-sky-200 transition-all"
                    >
                      <School className="w-3.5 h-3.5" />
                      <span>Buka Profil Sekolah</span>
                    </button>
                  </TooltipNozzle>
                </div>
              </div>
              <div className="w-12 h-12 rounded-2xl bg-white border border-sky-200 flex items-center justify-center text-[#0EA5E9] shadow-sm shrink-0">
                <School className="w-6 h-6" />
              </div>
            </div>

            <div className="bg-gradient-to-br from-emerald-50 to-teal-50 border-2 border-emerald-200 rounded-3xl p-5 flex items-start justify-between gap-4">
              <div className="space-y-1">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-[#10B981] text-white">
                  Rombongan Belajar
                </span>
                <h4 className="text-base font-black text-[#1E293B] pt-1">
                  Tambah & Kelola Daftar Kelas & Wali
                </h4>
                <p className="text-xs text-slate-500">
                  Tambah rombel kelas baru, input nama wali kelas manual, atau hapus kelas yang sudah tidak aktif.
                </p>
                <div className="pt-2">
                  <TooltipNozzle content="Kelola rombel kelas dan tentukan nama wali kelas secara bebas" position="top">
                    <button
                      onClick={() => setActiveTab('kelas')}
                      className="px-4 py-2 bg-[#10B981] hover:bg-emerald-600 text-white font-bold rounded-xl text-xs flex items-center space-x-1.5 shadow-md shadow-emerald-200 transition-all"
                    >
                      <Layers className="w-3.5 h-3.5" />
                      <span>Kelola Daftar Kelas & Wali</span>
                    </button>
                  </TooltipNozzle>
                </div>
              </div>
              <div className="w-12 h-12 rounded-2xl bg-white border border-emerald-200 flex items-center justify-center text-[#10B981] shadow-sm shrink-0">
                <Layers className="w-6 h-6" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB KELOLA KELAS & WALI KELAS MANUAL */}
      {activeTab === 'kelas' && (
        <div className="bg-white border-2 border-blue-100 rounded-[32px] p-5 sm:p-6 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-base font-black text-[#1E293B]">
                  Kelola Daftar Rombongan Belajar & Wali Kelas Manual
                </h3>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-sky-100 text-[#0EA5E9]">
                  {daftarKelas.length} Kelas Aktif
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                Anda dapat menambah rombel kelas baru, menginput nama wali kelas secara manual, atau menghapus kelas yang tidak digunakan.
              </p>
            </div>
          </div>

          {/* Add Class Form with Manual Wali Kelas Input */}
          <form onSubmit={handleAddKelas} className="p-5 rounded-3xl bg-slate-50 border-2 border-slate-200/80 space-y-3">
            <h4 className="text-xs font-black uppercase text-[#1E293B] tracking-wider flex items-center space-x-1.5">
              <Plus className="w-4 h-4 text-[#0EA5E9]" />
              <span>Tambah Rombel Kelas & Tentukan Nama Wali Kelas</span>
            </h4>
            
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
              <div className="sm:col-span-4">
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Nama Rombel Kelas:</label>
                <input
                  id="input-tambah-kelas"
                  type="text"
                  placeholder="Contoh: 7C, 8D, 9E, 10-IPA-1..."
                  value={newKelasInput}
                  onChange={e => {
                    setNewKelasInput(e.target.value);
                    setKelasAddError(null);
                  }}
                  className="w-full px-4 py-2.5 bg-white border-2 border-slate-200 rounded-2xl text-xs text-[#1E293B] font-black placeholder-slate-400 focus:outline-none focus:border-[#0EA5E9]"
                />
              </div>

              <div className="sm:col-span-5">
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Nama Wali Kelas (Bisa Ketik Manual):</label>
                <input
                  id="input-wali-kelas-manual"
                  type="text"
                  placeholder="Contoh: Dra. Hj. Nurjanah, M.Pd. (Bisa ketik bebas)"
                  value={newWaliInput}
                  onChange={e => setNewWaliInput(e.target.value)}
                  className="w-full px-4 py-2.5 bg-white border-2 border-slate-200 rounded-2xl text-xs text-[#1E293B] font-medium placeholder-slate-400 focus:outline-none focus:border-[#0EA5E9]"
                />
              </div>

              <div className="sm:col-span-3 flex items-end">
                <TooltipNozzle content="Tambahkan rombel kelas baru ke sistem sekolah" position="top" className="w-full">
                  <button
                    id="btn-tambah-kelas"
                    type="submit"
                    className="w-full py-2.5 bg-[#0EA5E9] hover:bg-sky-600 text-white font-black rounded-2xl text-xs flex items-center justify-center space-x-2 shadow-md shadow-sky-200 transition-all shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Tambah Kelas</span>
                  </button>
                </TooltipNozzle>
              </div>
            </div>

            {kelasAddError && (
              <p className="text-xs text-rose-600 font-bold flex items-center space-x-1">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                <span>{kelasAddError}</span>
              </p>
            )}
          </form>

          {/* Class List Cards */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Daftar Seluruh Kelas Terdaftar & Wali Kelas:
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {daftarKelas.map(kelas => {
                const kStudents = students.filter(s => s.kelas === kelas);
                const currentWaliName = waliKelasMap[kelas] || teachers.find(t => t.waliKelas === kelas)?.nama || 'Belum diatur';

                return (
                  <div
                    key={kelas}
                    className="p-5 rounded-3xl bg-white border-2 border-slate-200 hover:border-sky-300 transition-all shadow-xs flex flex-col justify-between space-y-3"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-2xl bg-sky-100 text-[#0EA5E9] font-black flex items-center justify-center text-sm shadow-inner">
                          {kelas.slice(0, 3)}
                        </div>
                        <div>
                          <h5 className="font-black text-[#1E293B] text-base">Kelas {kelas}</h5>
                          <p className="text-[11px] text-slate-500 font-medium">
                            {kStudents.length} Murid Terdaftar
                          </p>
                        </div>
                      </div>

                      <TooltipNozzle content={`Hapus Kelas ${kelas} dari daftar`} position="left">
                        <button
                          onClick={() => handleDeleteKelas(kelas)}
                          className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </TooltipNozzle>
                    </div>

                    <div className="p-2.5 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold text-slate-400 uppercase">Wali Kelas:</span>
                        <TooltipNozzle content="Ketik / edit nama wali kelas untuk kelas ini secara manual" position="top">
                          <button
                            onClick={() => handleOpenWaliModal(kelas)}
                            className="text-[10px] font-bold text-[#0EA5E9] hover:underline flex items-center space-x-1"
                          >
                            <Edit3 className="w-3 h-3" />
                            <span>Edit Manual</span>
                          </button>
                        </TooltipNozzle>
                      </div>
                      <p className="font-bold text-[#1E293B] text-xs truncate" title={currentWaliName}>
                        {currentWaliName}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                      <TooltipNozzle content={`Lihat seluruh murid terdaftar di Kelas ${kelas}`} position="top">
                        <button
                          onClick={() => {
                            setSelectedClassFilter(kelas);
                            setActiveTab('murid');
                          }}
                          className="text-[11px] font-bold text-[#0EA5E9] hover:underline"
                        >
                          Lihat Murid ({kStudents.length}) →
                        </button>
                      </TooltipNozzle>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: MANAJEMEN MURID (REPLACES SISWA) */}
      {activeTab === 'murid' && (
        <div className="bg-white border-2 border-blue-100 rounded-[32px] p-5 sm:p-6 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-black text-[#1E293B]">
                Master Data Murid Terdaftar
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Hanya murid yang terdaftar dalam daftar ini yang dapat melakukan scan presensi barcode.
              </p>
            </div>

            <TooltipNozzle content="Daftarkan murid baru lengkap dengan NISN dan nomor WhatsApp orang tua" position="left">
              <button
                id="admin-add-student-btn"
                onClick={() => handleOpenStudentModal()}
                className="px-4 py-2 bg-[#0EA5E9] hover:bg-sky-600 text-white font-bold rounded-2xl text-xs flex items-center space-x-1.5 shadow-md shadow-sky-200 transition-all"
              >
                <UserPlus className="w-4 h-4" />
                <span>Tambah Murid Baru</span>
              </button>
            </TooltipNozzle>
          </div>

          {/* Search & Filter Bar */}
          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari berdasarkan Nama Murid atau NISN..."
                value={searchStudent}
                onChange={e => setSearchStudent(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-xs text-[#1E293B] focus:outline-none focus:border-[#0EA5E9] font-medium"
              />
            </div>

            <div className="w-full sm:w-48">
              <select
                value={selectedClassFilter}
                onChange={e => setSelectedClassFilter(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-xs text-[#1E293B] font-bold focus:outline-none focus:border-[#0EA5E9]"
              >
                <option value="all">Semua Kelas ({students.length})</option>
                {daftarKelas.map(k => (
                  <option key={k} value={k}>Kelas {k}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Student Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider text-[11px]">
                  <th className="py-3 px-3">Murid</th>
                  <th className="py-3 px-3">NISN</th>
                  <th className="py-3 px-3">Kelas</th>
                  <th className="py-3 px-3">Orang Tua / Wali</th>
                  <th className="py-3 px-3">WhatsApp Ortu</th>
                  <th className="py-3 px-3 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredStudentsList.map(s => (
                  <tr key={s.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-9 h-9 rounded-xl overflow-hidden bg-slate-100 border border-slate-200 shrink-0">
                          {s.fotoUrl ? (
                            <img src={s.fotoUrl} alt={s.nama} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center font-bold text-slate-400">
                              {s.nama.slice(0, 2).toUpperCase()}
                            </div>
                          )}
                        </div>
                        <div>
                          <span className="font-bold text-[#1E293B] block">{s.nama}</span>
                          <span className="text-[10px] text-slate-400">{s.jenisKelamin === 'L' ? 'Laki-laki' : 'Perempuan'}</span>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3 font-mono font-bold text-[#0EA5E9]">{s.nisn}</td>
                    <td className="py-3 px-3">
                      <span className="px-2.5 py-0.5 rounded-full font-bold bg-sky-100 text-[#0EA5E9] border border-sky-300">
                        {s.kelas}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-700 font-medium">{s.namaOrangTua}</td>
                    <td className="py-3 px-3">
                      <a
                        href={`https://wa.me/${s.noHpOrangTua.replace(/[^0-9]/g, '')}`}
                        target="_blank"
                        rel="noreferrer"
                        className="text-emerald-700 font-bold hover:underline flex items-center space-x-1"
                      >
                        <Phone className="w-3 h-3" />
                        <span>+{s.noHpOrangTua}</span>
                      </a>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <div className="flex items-center justify-end space-x-1.5">
                        <TooltipNozzle content={`Edit data murid ${s.nama}`} position="left">
                          <button
                            onClick={() => handleOpenStudentModal(s)}
                            className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition-colors"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                        </TooltipNozzle>
                        <TooltipNozzle content={`Hapus murid ${s.nama}`} position="left">
                          <button
                            onClick={() => handleDeleteStudent(s.id, s.nama)}
                            className="p-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </TooltipNozzle>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: GURU & WALI KELAS */}
      {activeTab === 'guru' && (
        <div className="bg-white border-2 border-blue-100 rounded-[32px] p-5 sm:p-6 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-black text-[#1E293B]">
                Master Data Dewan Guru & Wali Kelas
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Guru yang ditugaskan sebagai Wali Kelas dapat mengelola absensi kelas dan melihat bukti foto scan murid.
              </p>
            </div>

            <TooltipNozzle content="Tambah akun guru atau wali kelas baru ke sistem sekolah" position="left">
              <button
                id="admin-add-teacher-btn"
                onClick={() => handleOpenTeacherModal()}
                className="px-4 py-2 bg-[#0EA5E9] hover:bg-sky-600 text-white font-bold rounded-2xl text-xs flex items-center space-x-1.5 shadow-md shadow-sky-200 transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>Tambah Guru / Wali Baru</span>
              </button>
            </TooltipNozzle>
          </div>

          {/* Teacher Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
            {teachers.map(g => (
              <div
                key={g.id}
                className="p-5 rounded-3xl bg-slate-50 border-2 border-slate-200/80 flex flex-col justify-between space-y-4 hover:border-sky-300 transition-colors shadow-xs"
              >
                <div className="flex items-start space-x-3.5">
                  <div className="w-12 h-12 rounded-2xl overflow-hidden bg-white border border-slate-200 shadow-sm shrink-0">
                    {g.fotoUrl ? (
                      <img src={g.fotoUrl} alt={g.nama} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center font-black text-[#0EA5E9]">
                        {g.nama.slice(0, 2).toUpperCase()}
                      </div>
                    )}
                  </div>
                  <div>
                    <h4 className="font-black text-[#1E293B] text-sm leading-snug">{g.nama}</h4>
                    <p className="text-[11px] text-slate-500 font-mono mt-0.5">NIP: {g.nip}</p>
                    <span className="inline-block mt-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-sky-100 text-[#0EA5E9] border border-sky-300">
                      Wali Kelas {g.waliKelas || '-'}
                    </span>
                  </div>
                </div>

                <div className="text-xs text-slate-600 space-y-1 border-t border-slate-200 pt-3">
                  <p>Mata Pelajaran: <strong className="text-[#1E293B]">{g.mataPelajaran || '-'}</strong></p>
                  <p>No. WhatsApp: <strong className="text-emerald-700 font-mono">+{g.noHp}</strong></p>
                </div>

                <div className="flex justify-end space-x-2 pt-2 border-t border-slate-200">
                  <TooltipNozzle content={`Edit data guru ${g.nama}`} position="top">
                    <button
                      onClick={() => handleOpenTeacherModal(g)}
                      className="px-3.5 py-1.5 bg-white hover:bg-slate-100 rounded-xl text-xs text-slate-700 font-bold border border-slate-200 transition-colors"
                    >
                      Edit
                    </button>
                  </TooltipNozzle>
                  <TooltipNozzle content={`Hapus guru ${g.nama}`} position="top">
                    <button
                      onClick={() => handleDeleteTeacher(g.id, g.nama)}
                      className="px-3.5 py-1.5 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-xl text-xs text-rose-600 font-bold transition-colors"
                    >
                      Hapus
                    </button>
                  </TooltipNozzle>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: LAPORAN REKAP PRESENSI */}
      {activeTab === 'rekap' && (
        <div className="bg-white border-2 border-blue-100 rounded-[32px] p-5 sm:p-6 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-black text-[#1E293B]">
                Laporan Rekapitulasi Presensi Seluruh Sekolah
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Log kehadiran resmi dengan pencatatan waktu otomatis real-time dan bukti foto tangkapan scan.
              </p>
            </div>

            <div className="flex items-center space-x-2">
              <TooltipNozzle content="Download file laporan presensi dalam format CSV Excel" position="bottom">
                <button
                  onClick={handleExportCSV}
                  className="px-4 py-2 rounded-2xl bg-slate-100 hover:bg-slate-200 text-[#1E293B] text-xs font-bold border border-slate-200 flex items-center space-x-1.5 transition-colors shadow-sm"
                >
                  <Download className="w-3.5 h-3.5 text-[#0EA5E9]" />
                  <span>Export CSV Excel</span>
                </button>
              </TooltipNozzle>
              <TooltipNozzle content="Cetak atau simpan sebagai PDF laporan presensi" position="bottom">
                <button
                  onClick={() => window.print()}
                  className="p-2.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition-colors"
                >
                  <Printer className="w-4 h-4" />
                </button>
              </TooltipNozzle>
            </div>
          </div>

          {/* Filter Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">Tanggal Presensi:</label>
              <input
                type="date"
                value={rekapDate}
                onChange={e => setRekapDate(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-xs text-[#1E293B] font-bold focus:outline-none focus:border-[#0EA5E9]"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">Filter Kelas:</label>
              <select
                value={rekapClassFilter}
                onChange={e => setRekapClassFilter(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-xs text-[#1E293B] font-bold focus:outline-none focus:border-[#0EA5E9]"
              >
                <option value="all">Semua Kelas</option>
                {daftarKelas.map(k => (
                  <option key={k} value={k}>Kelas {k}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">Filter Status:</label>
              <select
                value={rekapStatusFilter}
                onChange={e => setRekapStatusFilter(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-xs text-[#1E293B] font-bold focus:outline-none focus:border-[#0EA5E9]"
              >
                <option value="all">Semua Status</option>
                <option value="hadir">Hadir Tepat Waktu</option>
                <option value="terlambat">Terlambat</option>
                <option value="sakit">Sakit</option>
                <option value="izin">Izin</option>
                <option value="alpa">Alpa</option>
              </select>
            </div>
          </div>

          {/* Records Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider text-[11px]">
                  <th className="py-3 px-3">Tanggal & Waktu</th>
                  <th className="py-3 px-3">Nama Murid / NISN</th>
                  <th className="py-3 px-3">Kelas</th>
                  <th className="py-3 px-3">Status</th>
                  <th className="py-3 px-3">Bukti Foto Scan</th>
                  <th className="py-3 px-3">Notifikasi WA</th>
                  <th className="py-3 px-3 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredRekapRecords.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-8 text-slate-400 font-medium">
                      Tidak ada catatan presensi untuk filter yang dipilih.
                    </td>
                  </tr>
                ) : (
                  filteredRekapRecords.map(r => {
                    const student = students.find(s => s.id === r.siswaId);

                    return (
                      <tr key={r.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-3">
                          <span className="font-bold text-[#1E293B] block">{r.tanggal}</span>
                          <span className="font-mono text-emerald-700 font-bold text-[11px]">{r.waktuKedatangan} WIB</span>
                        </td>
                        <td className="py-3 px-3">
                          <span className="font-bold text-[#1E293B] block">{r.namaSiswa}</span>
                          <span className="font-mono text-slate-400 text-[10px]">NISN: {r.nisn}</span>
                        </td>
                        <td className="py-3 px-3">
                          <span className="px-2.5 py-0.5 rounded-full font-bold bg-sky-100 text-[#0EA5E9] border border-sky-300">
                            {r.kelas}
                          </span>
                        </td>
                        <td className="py-3 px-3">
                          <span className={`px-2.5 py-1 rounded-full font-bold capitalize ${
                            r.status === 'hadir' ? 'bg-emerald-100 text-emerald-800' :
                            r.status === 'terlambat' ? 'bg-amber-100 text-amber-800' :
                            r.status === 'sakit' ? 'bg-blue-100 text-blue-800' :
                            r.status === 'izin' ? 'bg-purple-100 text-purple-800' :
                            'bg-rose-100 text-rose-800'
                          }`}>
                            {r.status}
                          </span>
                          {r.menitKeterlambatan > 0 && (
                            <span className="text-amber-700 ml-1.5 font-bold text-[10px]">
                              (+{r.menitKeterlambatan} mnt)
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-3">
                          {r.fotoBuktiScan ? (
                            <TooltipNozzle content="Klik untuk melihat bukti foto tangkapan kamera murid secara besar" position="top">
                              <button
                                onClick={() => setPhotoZoomModal({
                                  isOpen: true,
                                  photoUrl: r.fotoBuktiScan!,
                                  title: `Bukti Foto Scan: ${r.namaSiswa}`,
                                  subtitle: `${r.tanggal} pukul ${r.waktuKedatangan} WIB (${r.status.toUpperCase()})`,
                                })}
                                className="flex items-center space-x-1.5 p-1 bg-sky-50 hover:bg-sky-100 rounded-xl border border-sky-200 transition-all group"
                              >
                                <div className="w-9 h-7 rounded-lg overflow-hidden border border-sky-300 bg-slate-900 shrink-0">
                                  <img
                                    src={r.fotoBuktiScan}
                                    alt="Foto"
                                    className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                                  />
                                </div>
                                <span className="text-[10px] font-black text-[#0EA5E9] group-hover:underline">
                                  Lihat Foto
                                </span>
                              </button>
                            </TooltipNozzle>
                          ) : (
                            <span className="text-[11px] text-slate-400 italic">Scan Barcode Saja</span>
                          )}
                        </td>
                        <td className="py-3 px-3">
                          {student && (
                            <TooltipNozzle content={`Kirim atau lihat pesan WhatsApp resmi ke wali murid (${student.namaOrangTua})`} position="top">
                              <button
                                onClick={() => setActiveWaRecord({ record: r, student })}
                                className={`px-2.5 py-1 rounded-xl text-[11px] font-bold flex items-center space-x-1 border transition-colors ${
                                  r.waTerkirim
                                    ? 'bg-emerald-50 text-emerald-700 border-emerald-300 hover:bg-emerald-100'
                                    : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                                }`}
                              >
                                <MessageSquare className="w-3 h-3 text-emerald-600" />
                                <span>{r.waTerkirim ? 'Terkirim' : 'Kirim WA'}</span>
                              </button>
                            </TooltipNozzle>
                          )}
                        </td>
                        <td className="py-3 px-3 text-right">
                          <TooltipNozzle content="Hapus log catatan presensi ini dari database" position="left">
                            <button
                              onClick={() => handleDeletePresensi(r.id, r.namaSiswa, r.tanggal)}
                              className="p-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </TooltipNozzle>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: PENGATURAN JAM & WA */}
      {activeTab === 'pengaturan' && (
        <div className="bg-white border-2 border-blue-100 rounded-[32px] p-5 sm:p-6 shadow-sm space-y-6">
          <div>
            <h3 className="text-base font-black text-[#1E293B]">
              Pengaturan Jam Operasional Presensi & Otomasi WhatsApp
            </h3>
            <p className="text-xs text-slate-500 font-medium">
              Konfigurasi jam masuk, toleransi keterlambatan, barcode anti-cheat, dan format pesan WhatsApp resmi ke orang tua.
            </p>
          </div>

          {saveSuccessNotice && (
            <div className="p-4 rounded-2xl bg-emerald-50 border-2 border-emerald-200 text-emerald-900 text-xs font-bold flex items-center space-x-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Seluruh pengaturan presensi dan pesan WhatsApp berhasil disimpan!</span>
            </div>
          )}

          <form onSubmit={handleSaveSettings} className="space-y-5 text-xs">
            {/* Operational Times */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-slate-600 font-bold mb-1">
                  Batas Jam Masuk Pagi:
                </label>
                <input
                  type="time"
                  value={settingsForm.jamMasuk}
                  onChange={e => setSettingsForm({ ...settingsForm, jamMasuk: e.target.value })}
                  className="w-full px-3.5 py-2 bg-white border-2 border-slate-200 rounded-2xl text-[#1E293B] font-black focus:outline-none focus:border-[#0EA5E9]"
                />
                <span className="text-[10px] text-slate-400 font-medium">Murid yang hadir setelah jam ini berstatus Terlambat.</span>
              </div>

              <div>
                <label className="block text-slate-600 font-bold mb-1">
                  Toleransi Terlambat (Menit):
                </label>
                <input
                  type="number"
                  value={settingsForm.toleransiTerlambatMenit}
                  onChange={e => setSettingsForm({ ...settingsForm, toleransiTerlambatMenit: Number(e.target.value) })}
                  className="w-full px-3.5 py-2 bg-white border-2 border-slate-200 rounded-2xl text-[#1E293B] font-black focus:outline-none focus:border-[#0EA5E9]"
                />
                <span className="text-[10px] text-slate-400 font-medium">Jendela waktu kedatangan sebelum gerbang ditutup.</span>
              </div>

              <div>
                <label className="block text-slate-600 font-bold mb-1">
                  Durasi Rotasi Barcode Dinamis (Detik):
                </label>
                <input
                  type="number"
                  value={settingsForm.durasiQrDetik || 20}
                  onChange={e => setSettingsForm({ ...settingsForm, durasiQrDetik: Number(e.target.value) })}
                  className="w-full px-3.5 py-2 bg-white border-2 border-slate-200 rounded-2xl text-[#1E293B] font-black focus:outline-none focus:border-[#0EA5E9]"
                />
                <span className="text-[10px] text-slate-400 font-medium">Barcode berganti otomatis agar link tidak tersimpan.</span>
              </div>
            </div>

            {/* Automation & Photo Settings */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-5 rounded-3xl bg-sky-50/60 border-2 border-sky-200">
              <label className="flex items-start space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settingsForm.autoKirimWA ?? true}
                  onChange={e => setSettingsForm({ ...settingsForm, autoKirimWA: e.target.checked })}
                  className="mt-1 w-4 h-4 rounded text-[#0EA5E9] focus:ring-[#0EA5E9]"
                />
                <div>
                  <span className="font-bold text-[#1E293B] text-xs block">
                    Kirim Pesan WhatsApp Otomatis ke Orang Tua
                  </span>
                  <span className="text-[11px] text-slate-500 block mt-0.5">
                    Ketika murid berhasil scan, aplikasi otomatis menyiapkan notifikasi WA langsung ke nomor HP wali murid.
                  </span>
                </div>
              </label>

              <label className="flex items-start space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settingsForm.wajibFotoWajahScan ?? true}
                  onChange={e => setSettingsForm({ ...settingsForm, wajibFotoWajahScan: e.target.checked })}
                  className="mt-1 w-4 h-4 rounded text-[#0EA5E9] focus:ring-[#0EA5E9]"
                />
                <div>
                  <span className="font-bold text-[#1E293B] text-xs block">
                    Aktifkan Tangkapan Wajah (Snapshot) Saat Scan
                  </span>
                  <span className="text-[11px] text-slate-500 block mt-0.5">
                    Kamera murid menangkap frame wajah saat scan presensi sebagai bukti otentik kehadiran / keterlambatan.
                  </span>
                </div>
              </label>
            </div>

            {/* WhatsApp Message Template */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="block text-slate-600 font-bold">
                  Template Pesan WhatsApp Hadir Tepat Waktu:
                </label>
                <span className="text-[11px] text-slate-400 font-medium">
                  Variabel: {'{NAMA}'}, {'{NISN}'}, {'{KELAS}'}, {'{STATUS}'}, {'{WAKTU}'}, {'{TANGGAL}'}, {'{NAMA_ORTU}'}, {'{SEKOLAH}'}
                </span>
              </div>
              <textarea
                rows={7}
                value={settingsForm.templatePesanWA}
                onChange={e => setSettingsForm({ ...settingsForm, templatePesanWA: e.target.value })}
                className="w-full p-4 bg-slate-50 border-2 border-slate-200 rounded-3xl text-[#1E293B] font-mono text-xs focus:outline-none focus:border-[#0EA5E9] leading-relaxed"
              />
            </div>

            <div className="space-y-3">
              <label className="block text-slate-600 font-bold">
                Template Pesan WhatsApp Keterlambatan:
              </label>
              <textarea
                rows={6}
                value={settingsForm.templatePesanTerlambatWA}
                onChange={e => setSettingsForm({ ...settingsForm, templatePesanTerlambatWA: e.target.value })}
                className="w-full p-4 bg-slate-50 border-2 border-slate-200 rounded-3xl text-[#1E293B] font-mono text-xs focus:outline-none focus:border-[#0EA5E9] leading-relaxed"
              />
            </div>

            {/* Bottom Form Actions */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-100">
              <TooltipNozzle content="Kembalikan seluruh data database murid dan sekolah ke sampel awal" position="top">
                <button
                  type="button"
                  onClick={handleResetAllData}
                  className="text-xs font-bold text-slate-500 hover:text-rose-600 flex items-center space-x-1.5 transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset Data Uji Coba ke Semula</span>
                </button>
              </TooltipNozzle>

              <TooltipNozzle content="Simpan seluruh perubahan jam operasional dan template WhatsApp" position="top">
                <button
                  id="admin-save-settings-btn"
                  type="submit"
                  className="px-6 py-3 bg-[#0EA5E9] hover:bg-sky-600 text-white font-black rounded-2xl text-xs flex items-center space-x-2 shadow-lg shadow-sky-200 transition-all"
                >
                  <Save className="w-4 h-4" />
                  <span>Simpan Seluruh Pengaturan</span>
                </button>
              </TooltipNozzle>
            </div>
          </form>
        </div>
      )}

      {/* TAB PROFIL SEKOLAH */}
      {activeTab === 'profil_sekolah' && (
        <ProfilSekolahTab
          settings={settings}
          onSettingsUpdated={(newSettings) => {
            onSettingsUpdated(newSettings);
            setSettingsForm(newSettings);
          }}
        />
      )}

      {/* STUDENT ADD/EDIT MODAL */}
      {studentModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white border-2 border-blue-100 w-full max-w-lg rounded-[32px] p-6 shadow-2xl space-y-4 text-[#1E293B]">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-black text-[#1E293B]">
                {editingStudent ? 'Edit Data Murid' : 'Daftarkan Murid Baru'}
              </h3>
              <button onClick={() => setStudentModalOpen(false)} className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveStudent} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-bold mb-1">NISN Murid:</label>
                  <input
                    type="text"
                    required
                    value={formNisn}
                    onChange={e => setFormNisn(e.target.value)}
                    placeholder="10 digit NISN..."
                    className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-mono font-bold focus:outline-none focus:border-[#0EA5E9]"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-bold mb-1">Kelas:</label>
                  <select
                    value={formKelas}
                    onChange={e => setFormKelas(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-bold focus:outline-none focus:border-[#0EA5E9]"
                  >
                    {daftarKelas.map(k => (
                      <option key={k} value={k}>Kelas {k}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-bold mb-1">Nama Lengkap Murid:</label>
                <input
                  type="text"
                  required
                  value={formNama}
                  onChange={e => setFormNama(e.target.value)}
                  placeholder="Contoh: Muhammad Rayhan..."
                  className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-bold focus:outline-none focus:border-[#0EA5E9]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-bold mb-1">Jenis Kelamin:</label>
                  <select
                    value={formJK}
                    onChange={e => setFormJK(e.target.value as 'L' | 'P')}
                    className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-bold focus:outline-none focus:border-[#0EA5E9]"
                  >
                    <option value="L">Laki-laki (L)</option>
                    <option value="P">Perempuan (P)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-600 font-bold mb-1">Nama Orang Tua / Wali:</label>
                  <input
                    type="text"
                    required
                    value={formNamaOrtu}
                    onChange={e => setFormNamaOrtu(e.target.value)}
                    placeholder="Nama Bapak/Ibu..."
                    className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-bold focus:outline-none focus:border-[#0EA5E9]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-bold mb-1">Nomor WhatsApp Orang Tua:</label>
                <input
                  type="text"
                  required
                  value={formNoHpOrtu}
                  onChange={e => setFormNoHpOrtu(e.target.value)}
                  placeholder="Contoh: 081288334455..."
                  className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-mono font-bold focus:outline-none focus:border-[#0EA5E9]"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-bold mb-1">Alamat Domisili:</label>
                <input
                  type="text"
                  value={formAlamat}
                  onChange={e => setFormAlamat(e.target.value)}
                  placeholder="Alamat tempat tinggal murid..."
                  className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-medium focus:outline-none focus:border-[#0EA5E9]"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setStudentModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-colors"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#0EA5E9] hover:bg-sky-600 text-white font-bold rounded-xl shadow-md shadow-sky-200 transition-all"
                >
                  Simpan Data Murid
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MANUAL WALI KELAS EDIT MODAL */}
      {waliModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white border-2 border-blue-100 w-full max-w-md rounded-[32px] p-6 shadow-2xl space-y-4 text-[#1E293B]">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-black text-[#1E293B]">
                  Atur Nama Wali Kelas {waliModal.kelas}
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Ketik nama wali kelas secara bebas atau pilih dari daftar guru.
                </p>
              </div>
              <button
                onClick={() => setWaliModal({ isOpen: false, kelas: '', namaWali: '' })}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveWaliModal} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Nama Lengkap & Gelar Wali Kelas:
                </label>
                <input
                  type="text"
                  required
                  value={waliModal.namaWali}
                  onChange={e => setWaliModal({ ...waliModal, namaWali: e.target.value })}
                  placeholder="Contoh: Dra. Hj. Siti Rahmawati, M.Pd."
                  className="w-full px-4 py-2.5 bg-slate-50 border-2 border-slate-200 rounded-2xl text-xs text-[#1E293B] font-bold focus:outline-none focus:border-[#0EA5E9]"
                />
              </div>

              {/* Quick Select from existing teachers */}
              {teachers.length > 0 && (
                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">
                    Atau Pilih Cepat Dari Daftar Dewan Guru:
                  </label>
                  <select
                    onChange={e => {
                      if (e.target.value) {
                        setWaliModal({ ...waliModal, namaWali: e.target.value });
                      }
                    }}
                    className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-xs text-[#1E293B] font-medium focus:outline-none focus:border-[#0EA5E9]"
                  >
                    <option value="">-- Pilih Guru Terdaftar --</option>
                    {teachers.map(t => (
                      <option key={t.id} value={t.nama}>
                        {t.nama} ({t.mataPelajaran})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="flex justify-end space-x-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setWaliModal({ isOpen: false, kelas: '', namaWali: '' })}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-colors"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#0EA5E9] hover:bg-sky-600 text-white font-black rounded-xl shadow-md shadow-sky-200 transition-all"
                >
                  Simpan Nama Wali
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* TEACHER ADD/EDIT MODAL */}
      {teacherModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white border-2 border-blue-100 w-full max-w-lg rounded-[32px] p-6 shadow-2xl space-y-4 text-[#1E293B]">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-black text-[#1E293B]">
                {editingTeacher ? 'Edit Data Guru' : 'Tambah Guru Baru'}
              </h3>
              <button onClick={() => setTeacherModalOpen(false)} className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveTeacher} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-bold mb-1">NIP / Identitas:</label>
                  <input
                    type="text"
                    required
                    value={formGuruNip}
                    onChange={e => setFormGuruNip(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-mono font-bold focus:outline-none focus:border-[#0EA5E9]"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-bold mb-1">Tugas Wali Kelas:</label>
                  <select
                    value={formGuruWali}
                    onChange={e => setFormGuruWali(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-bold focus:outline-none focus:border-[#0EA5E9]"
                  >
                    <option value="none">Bukan Wali Kelas</option>
                    {daftarKelas.map(k => (
                      <option key={k} value={k}>Kelas {k}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-bold mb-1">Nama Lengkap & Gelar:</label>
                <input
                  type="text"
                  required
                  value={formGuruNama}
                  onChange={e => setFormGuruNama(e.target.value)}
                  placeholder="Contoh: Drs. Rudi Hartono, M.Pd."
                  className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-bold focus:outline-none focus:border-[#0EA5E9]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-bold mb-1">Mata Pelajaran:</label>
                  <input
                    type="text"
                    value={formGuruMapel}
                    onChange={e => setFormGuruMapel(e.target.value)}
                    placeholder="Matematika, IPA, dll..."
                    className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-bold focus:outline-none focus:border-[#0EA5E9]"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-bold mb-1">Nomor WhatsApp:</label>
                  <input
                    type="text"
                    required
                    value={formGuruNoHp}
                    onChange={e => setFormGuruNoHp(e.target.value)}
                    placeholder="081288..."
                    className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-mono font-bold focus:outline-none focus:border-[#0EA5E9]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-bold mb-1">Email Resmi:</label>
                <input
                  type="email"
                  value={formGuruEmail}
                  onChange={e => setFormGuruEmail(e.target.value)}
                  placeholder="nama@sekolah.sch.id"
                  className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-medium focus:outline-none focus:border-[#0EA5E9]"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setTeacherModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-colors"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#0EA5E9] hover:bg-sky-600 text-white font-bold rounded-xl shadow-md shadow-sky-200 transition-all"
                >
                  Simpan Data Guru
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE MODAL */}
      <ConfirmDeleteModal
        isOpen={deleteModal.isOpen}
        onClose={() => setDeleteModal({ ...deleteModal, isOpen: false })}
        onConfirm={deleteModal.onConfirm}
        title={deleteModal.title}
        itemName={deleteModal.itemName}
        itemType={deleteModal.itemType}
        description={deleteModal.description}
        isDangerAll={deleteModal.isDangerAll}
        confirmButtonText={deleteModal.confirmButtonText}
      />

      {/* PHOTO ZOOM MODAL */}
      {photoZoomModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="bg-white border-2 border-blue-100 w-full max-w-lg rounded-[36px] overflow-hidden shadow-2xl flex flex-col text-[#1E293B]">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-white">
              <div className="flex items-center space-x-2.5">
                <Camera className="w-5 h-5 text-[#0EA5E9]" />
                <div>
                  <h3 className="font-black text-[#1E293B] text-sm leading-tight">{photoZoomModal.title}</h3>
                  <p className="text-[11px] text-slate-500 font-medium">{photoZoomModal.subtitle}</p>
                </div>
              </div>
              <button
                onClick={() => setPhotoZoomModal({ ...photoZoomModal, isOpen: false })}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 bg-slate-900 flex items-center justify-center min-h-[320px]">
              <img
                src={photoZoomModal.photoUrl}
                alt="Foto Tangkapan Wajah"
                className="max-h-[420px] max-w-full rounded-2xl shadow-xl object-contain border border-slate-700"
              />
            </div>

            <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span className="font-bold text-emerald-700 flex items-center space-x-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Foto Otentik Terekam Kamera</span>
              </span>
              <button
                onClick={() => setPhotoZoomModal({ ...photoZoomModal, isOpen: false })}
                className="px-4 py-1.5 bg-[#0EA5E9] hover:bg-sky-600 text-white font-bold rounded-xl text-xs transition-colors shadow-sm"
              >
                Tutup Preview
              </button>
            </div>
          </div>
        </div>
      )}

      {/* WHATSAPP MODAL PREVIEW */}
      {activeWaRecord && (
        <WhatsAppPreviewModal
          isOpen={!!activeWaRecord}
          onClose={() => setActiveWaRecord(null)}
          record={activeWaRecord.record}
          siswa={activeWaRecord.student}
          settings={settings}
        />
      )}
    </div>
  );
};
