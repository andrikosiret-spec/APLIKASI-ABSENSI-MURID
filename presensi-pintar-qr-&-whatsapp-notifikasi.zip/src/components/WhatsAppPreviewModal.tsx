import React, { useState } from 'react';
import { 
  X, 
  Send, 
  Copy, 
  Check, 
  Phone, 
  User, 
  Clock, 
  Calendar, 
  MessageSquare, 
  ShieldCheck,
  ExternalLink
} from 'lucide-react';
import { PresensiRecord, Siswa, PengaturanSekolah } from '../types';
import { generateWhatsAppMessage, createWhatsAppDirectUrl, formatPhoneNumberForWhatsApp } from '../services/whatsapp';
import { markWhatsAppSent } from '../services/storage';
import { TooltipNozzle } from './TooltipNozzle';

interface WhatsAppPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  record: PresensiRecord;
  siswa: Siswa;
  settings: PengaturanSekolah;
  onSuccessSent?: () => void;
}

export const WhatsAppPreviewModal: React.FC<WhatsAppPreviewModalProps> = ({
  isOpen,
  onClose,
  record,
  siswa,
  settings,
  onSuccessSent,
}) => {
  const [copied, setCopied] = useState<boolean>(false);
  const [isSending, setIsSending] = useState<boolean>(false);

  if (!isOpen) return null;

  const rawMessage = generateWhatsAppMessage(record, siswa, settings);
  const targetPhoneFormatted = formatPhoneNumberForWhatsApp(siswa.noHpOrangTua);
  const directUrl = createWhatsAppDirectUrl(siswa.noHpOrangTua, rawMessage);

  const handleCopy = () => {
    navigator.clipboard.writeText(rawMessage);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSendWhatsApp = () => {
    setIsSending(true);
    markWhatsAppSent(record.id, `${siswa.noHpOrangTua} (${siswa.namaOrangTua})`);
    
    // Open WhatsApp Web / WhatsApp App
    window.open(directUrl, '_blank');
    
    setTimeout(() => {
      setIsSending(false);
      if (onSuccessSent) onSuccessSent();
      onClose();
    }, 800);
  };

  // Convert WhatsApp markdown (*bold*, _italic_) to visual preview HTML
  const formatPreviewHtml = (text: string) => {
    const lines = text.split('\n');
    return lines.map((line, idx) => {
      let formatted = line.replace(/\*(.*?)\*/g, '<strong class="font-black text-[#1E293B]">$1</strong>');
      formatted = formatted.replace(/_(.*?)_/g, '<em class="italic text-slate-600">$1</em>');
      return (
        <p key={idx} className="min-h-[1.2rem] text-xs text-slate-800 leading-relaxed" dangerouslySetInnerHTML={{ __html: formatted || '&nbsp;' }} />
      );
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white border-2 border-blue-100 w-full max-w-lg rounded-[32px] overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="px-6 py-4 bg-[#10B981] border-b border-emerald-600 flex items-center justify-between text-white">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center text-white shadow-inner">
              <MessageSquare className="w-5 h-5 fill-current" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-base font-black text-white leading-tight">
                  Kirim Notifikasi WhatsApp Orang Tua
                </h3>
              </div>
              <p className="text-xs text-emerald-100 font-medium">
                Pesan resmi kedatangan murid terformat otomatis
              </p>
            </div>
          </div>
          <button
            id="close-wa-preview-modal"
            onClick={onClose}
            className="p-2 rounded-xl text-white hover:bg-white/20 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Recipient Card */}
        <div className="p-4 bg-slate-50 border-b border-slate-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-2xl bg-sky-100 text-[#0EA5E9] flex items-center justify-center font-bold">
              <User className="w-4 h-4" />
            </div>
            <div>
              <p className="font-bold text-[#1E293B] text-sm">{siswa.namaOrangTua}</p>
              <p className="text-slate-500 font-medium">
                Orang Tua / Wali dari <strong className="text-[#1E293B]">{siswa.nama}</strong> ({siswa.kelas})
              </p>
            </div>
          </div>

          <TooltipNozzle content="Nomor WhatsApp orang tua murid yang telah terdaftar" position="left">
            <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 font-mono font-bold">
              <Phone className="w-3.5 h-3.5" />
              <span>+{targetPhoneFormatted}</span>
            </div>
          </TooltipNozzle>
        </div>

        {/* WhatsApp Chat Balloon Mockup */}
        <div className="p-4 sm:p-6 overflow-y-auto bg-slate-100 flex-1 flex flex-col justify-center">
          <div className="text-center mb-3">
            <span className="text-[11px] font-bold text-slate-500 bg-white px-3 py-1 rounded-full border border-slate-200 shadow-xs">
              Pratinjau Pesan WhatsApp Orang Tua
            </span>
          </div>

          <div className="bg-[#E7F8E8] border border-emerald-200 rounded-3xl rounded-tr-none p-4 sm:p-5 shadow-md max-w-md mx-auto w-full relative">
            <div className="space-y-1">
              {formatPreviewHtml(rawMessage)}
            </div>

            <div className="mt-3 pt-2 border-t border-emerald-200/80 flex items-center justify-between text-[10px] text-slate-500 font-bold">
              <span>Status: Siap Dikirim</span>
              <div className="flex items-center space-x-1 text-emerald-700 font-black">
                <span>{record.waktuKedatangan} WIB</span>
                <Check className="w-3.5 h-3.5 stroke-[3]" />
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-white border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3">
          <TooltipNozzle content="Salin draf teks pesan untuk dikirim via aplikasi chat lain" position="top">
            <button
              id="wa-copy-text-btn"
              type="button"
              onClick={handleCopy}
              className="w-full sm:w-auto px-4 py-2.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-[#1E293B] text-xs font-bold flex items-center justify-center space-x-1.5 transition-colors border border-slate-200"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-slate-500" />}
              <span>{copied ? 'Teks Tersalin!' : 'Salin Teks Pesan'}</span>
            </button>
          </TooltipNozzle>

          <div className="flex items-center space-x-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold transition-colors"
            >
              Tutup
            </button>
            <TooltipNozzle content="Buka WhatsApp Web / Aplikasi WhatsApp resmi untuk langsung mengirim pesan" position="top">
              <button
                id="wa-send-direct-btn"
                type="button"
                onClick={handleSendWhatsApp}
                disabled={isSending}
                className="flex-1 sm:flex-initial px-5 py-2.5 rounded-2xl bg-[#10B981] hover:bg-emerald-600 text-white text-xs font-black flex items-center justify-center space-x-2 shadow-md shadow-emerald-200 transition-all"
              >
                <Send className="w-4 h-4" />
                <span>{isSending ? 'Membuka WA...' : 'Kirim ke WhatsApp'}</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-80" />
              </button>
            </TooltipNozzle>
          </div>
        </div>
      </div>
    </div>
  );
};
