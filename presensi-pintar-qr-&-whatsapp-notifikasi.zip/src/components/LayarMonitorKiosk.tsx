import React, { useState, useEffect, useRef } from 'react';
import { 
  QrCode, 
  Clock, 
  ShieldCheck, 
  RefreshCw, 
  CheckCircle2, 
  AlertTriangle, 
  Send, 
  Users, 
  Sparkles, 
  Maximize, 
  Volume2, 
  VolumeX, 
  School, 
  ArrowRight, 
  TrendingUp, 
  Zap 
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { PengaturanSekolah, PresensiRecord, Siswa } from '../types';
import { generateDynamicToken, generateQRCodeDataURL } from '../services/qrSecurity';
import { 
  getPresensiRecords, 
  getSiswaList, 
  subscribeToDataChanges 
} from '../services/storage';
import { TooltipNozzle } from './TooltipNozzle';

interface LayarMonitorKioskProps {
  settings: PengaturanSekolah;
  onOpenStudentScanner?: () => void;
}

export const LayarMonitorKiosk: React.FC<LayarMonitorKioskProps> = ({
  settings,
  onOpenStudentScanner,
}) => {
  const [token, setToken] = useState<string>('');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [countdown, setCountdown] = useState<number>(settings.durasiQrDetik || 20);
  const [currentTimeStr, setCurrentTimeStr] = useState<string>('');
  const [currentDateStr, setCurrentDateStr] = useState<string>('');
  const [recentRecords, setRecentRecords] = useState<PresensiRecord[]>([]);
  const [allStudents, setAllStudents] = useState<Siswa[]>([]);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [latestAttendee, setLatestAttendee] = useState<PresensiRecord | null>(null);

  const prevRecordCountRef = useRef<number>(0);

  const getTodayISO = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };

  // Generate dynamic rotating token
  const refreshDynamicQR = async () => {
    const newToken = generateDynamicToken(settings.secretTokenSalt);
    setToken(newToken.token);
    const dataUrl = await generateQRCodeDataURL(newToken.token, 420);
    setQrDataUrl(dataUrl);
    setCountdown(settings.durasiQrDetik || 20);
  };

  // Load records and students
  const loadData = () => {
    const today = getTodayISO();
    const students = getSiswaList();
    setAllStudents(students);

    const records = getPresensiRecords();
    const todayRecords = records.filter(r => r.tanggal === today);
    setRecentRecords(todayRecords);

    // If new record detected in real-time, play confetti
    if (todayRecords.length > prevRecordCountRef.current && prevRecordCountRef.current !== 0) {
      const newest = todayRecords[0];
      setLatestAttendee(newest);
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
      });
    }
    prevRecordCountRef.current = todayRecords.length;
  };

  useEffect(() => {
    refreshDynamicQR();
    loadData();

    const unsub = subscribeToDataChanges(loadData);
    return () => unsub();
  }, [settings.secretTokenSalt, settings.durasiQrDetik]);

  // Main countdown ticker & clock
  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      setCurrentTimeStr(
        now.toLocaleTimeString('id-ID', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }) + ' WIB'
      );
      setCurrentDateStr(
        now.toLocaleDateString('id-ID', {
          weekday: 'long',
          day: 'numeric',
          month: 'long',
          year: 'numeric',
        })
      );

      setCountdown(prev => {
        if (prev <= 1) {
          refreshDynamicQR();
          return settings.durasiQrDetik || 20;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [settings.secretTokenSalt, settings.durasiQrDetik]);

  // Fullscreen toggle
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const totalMurid = allStudents.length;
  const totalHadir = recentRecords.filter(r => r.status === 'hadir').length;
  const totalTerlambat = recentRecords.filter(r => r.status === 'terlambat').length;
  const totalPresensi = totalHadir + totalTerlambat;
  const totalBelum = Math.max(0, totalMurid - totalPresensi);
  const attendancePercentage = totalMurid > 0 ? Math.round((totalPresensi / totalMurid) * 100) : 0;

  const qrDuration = settings.durasiQrDetik || 20;
  const progressPercent = ((qrDuration - countdown) / qrDuration) * 100;

  return (
    <div className="w-full min-h-[calc(100vh-4.5rem)] bg-[#F0F9FF] p-4 sm:p-6 lg:p-8 flex flex-col justify-between">
      
      {/* Top Banner: School Branding & Live Clock */}
      <div className="bg-white border-2 border-blue-100 rounded-[32px] p-5 sm:p-6 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4 mb-6">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 rounded-[22px] bg-[#0EA5E9] flex items-center justify-center text-white shadow-lg shadow-sky-200 overflow-hidden p-1.5 shrink-0 border-2 border-white">
            {settings.logoSekolah ? (
              <img
                src={settings.logoSekolah}
                alt={settings.namaSekolah}
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain rounded-xl bg-white"
                onError={(e) => {
                  (e.currentTarget as HTMLElement).style.display = 'none';
                }}
              />
            ) : (
              <School className="w-9 h-9 stroke-[2.5]" />
            )}
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-xl sm:text-2xl font-black text-[#1E293B] tracking-tight">
                {settings.namaSekolah}
              </h1>
              <span className="px-3 py-0.5 rounded-full text-xs font-black bg-emerald-100 text-emerald-700 border border-emerald-300">
                LIVE MONITOR GERBANG
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 font-medium mt-0.5">
              {settings.alamatSekolah ? `${settings.alamatSekolah} • ` : ''}Arahkan kamera HP murid ke barcode dinamis di bawah untuk melakukan presensi mandiri
            </p>
          </div>
        </div>

        {/* Digital Clock and Action Controls */}
        <div className="flex items-center space-x-3">
          <TooltipNozzle content="Waktu server otomatis Indonesia (WIB) yang dijadikan acuan keterlambatan" position="bottom">
            <div className="bg-sky-50 border-2 border-sky-100 px-5 py-2.5 rounded-2xl text-center">
              <p className="text-xs font-bold text-[#0EA5E9] uppercase tracking-wider">
                {currentDateStr || 'Memuat Waktu...'}
              </p>
              <p className="text-2xl sm:text-3xl font-mono font-black text-[#1E293B] tracking-tight">
                {currentTimeStr || '--:--:-- WIB'}
              </p>
            </div>
          </TooltipNozzle>

          <TooltipNozzle content="Mode Layar Penuh untuk proyektor gerbang atau Smart TV" position="left">
            <button
              id="kiosk-fullscreen-btn"
              onClick={toggleFullscreen}
              className="p-3 bg-white hover:bg-slate-50 border-2 border-slate-200 rounded-2xl text-slate-600 hover:text-[#0EA5E9] transition-all shadow-sm"
            >
              <Maximize className="w-5 h-5" />
            </button>
          </TooltipNozzle>
        </div>
      </div>

      {/* Main Grid: Barcode Box & Real-time Attendance */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1 items-start">
        
        {/* Left / Center Panel: High-Impact QR Barcode Display */}
        <div className="lg:col-span-7 flex flex-col items-center justify-center">
          <div className="w-full bg-white rounded-[40px] shadow-xl border-b-8 border-sky-200 border-2 border-sky-100 p-6 sm:p-8 text-center relative overflow-hidden">
            
            {/* Top Badge: Rotation Indicator */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                </span>
                <span className="text-xs font-black text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                  Barcode Aktif & Terenkripsi
                </span>
              </div>

              <div className="flex items-center space-x-1.5 text-xs font-bold text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
                <Clock className="w-3.5 h-3.5 text-[#0EA5E9]" />
                <span>Jam Masuk: <strong className="text-[#1E293B]">{settings.jamMasuk} WIB</strong></span>
              </div>
            </div>

            {/* QR Code Canvas Box */}
            <div className="p-6 bg-slate-50 rounded-[36px] border-4 border-dashed border-sky-300 flex items-center justify-center relative mx-auto max-w-sm sm:max-w-md">
              {qrDataUrl ? (
                <div className="relative group">
                  <img
                    src={qrDataUrl}
                    alt="Dynamic Attendance QR Barcode"
                    className="w-64 h-64 sm:w-76 sm:h-76 object-contain rounded-2xl shadow-md border-4 border-white transition-all transform group-hover:scale-[1.01]"
                  />
                  {/* Subtle Center School Emblem */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-12 h-12 bg-white rounded-xl shadow-lg border-2 border-[#0EA5E9] flex items-center justify-center text-[#0EA5E9] font-black text-xs">
                      PK
                    </div>
                  </div>
                </div>
              ) : (
                <div className="w-64 h-64 sm:w-76 sm:h-76 flex flex-col items-center justify-center text-slate-400">
                  <RefreshCw className="w-10 h-10 animate-spin text-[#0EA5E9] mb-2" />
                  <span className="text-xs font-semibold">Menghasilkan Barcode...</span>
                </div>
              )}
            </div>

            {/* Rotating countdown bar */}
            <div className="mt-5 max-w-md mx-auto">
              <div className="flex items-center justify-between text-xs font-bold mb-1.5">
                <span className="text-slate-500 flex items-center space-x-1.5">
                  <RefreshCw className={`w-3.5 h-3.5 text-[#0EA5E9] ${countdown <= 3 ? 'animate-spin' : ''}`} />
                  <span>Barcode Berputar Otomatis:</span>
                </span>
                <span className={`font-mono text-sm px-2.5 py-0.5 rounded-full ${
                  countdown <= 5 ? 'bg-rose-100 text-rose-600 animate-pulse font-black' : 'bg-sky-100 text-[#0EA5E9]'
                }`}>
                  {countdown} Detik
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden p-0.5 border border-slate-200">
                <div 
                  className={`h-full rounded-full transition-all duration-1000 ${
                    countdown <= 5 ? 'bg-[#F43F5E]' : 'bg-[#0EA5E9]'
                  }`}
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>

            {/* Anti-cheat and Security note */}
            <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-center gap-4 text-xs text-slate-500">
              <div className="flex items-center space-x-1.5 text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-xl">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span className="font-bold">Anti-Titip Absen</span>
              </div>
              <div className="flex items-center space-x-1.5 text-sky-700 bg-sky-50 px-2.5 py-1 rounded-xl">
                <Clock className="w-3.5 h-3.5" />
                <span className="font-bold">Waktu Otomatis & Terkunci</span>
              </div>
              <div className="flex items-center space-x-1.5 text-purple-700 bg-purple-50 px-2.5 py-1 rounded-xl">
                <Send className="w-3.5 h-3.5" />
                <span className="font-bold">Auto Notifikasi WhatsApp</span>
              </div>
            </div>

            {/* Direct Quick Test Button for Student Mobile */}
            {onOpenStudentScanner && (
              <div className="mt-4">
                <TooltipNozzle content="Buka scanner kamera murid untuk menguji alur presensi secara langsung" position="top">
                  <button
                    id="kiosk-test-siswa-btn"
                    onClick={onOpenStudentScanner}
                    className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-[#0EA5E9] to-sky-600 hover:from-sky-500 hover:to-sky-600 text-white font-black text-xs sm:text-sm flex items-center justify-center space-x-2 shadow-lg shadow-sky-200 transition-all transform hover:-translate-y-0.5"
                  >
                    <QrCode className="w-4 h-4" />
                    <span>Uji Coba Scan Menggunakan HP Murid (Buka Kamera)</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </TooltipNozzle>
              </div>
            )}
          </div>
        </div>

        {/* Right Panel: Attendance Stats & Live Real-time Feed */}
        <div className="lg:col-span-5 space-y-5">
          
          {/* Stat Cards Matrix */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <TooltipNozzle content="Jumlah murid yang scan barcode sebelum jam masuk" position="top" className="w-full">
              <div className="bg-white border-2 border-emerald-100 rounded-3xl p-3.5 shadow-sm w-full">
                <p className="text-[11px] font-bold text-emerald-600 uppercase">Tepat Waktu</p>
                <p className="text-2xl font-black text-emerald-700 mt-0.5">{totalHadir}</p>
                <span className="text-[10px] text-slate-400 font-medium">Murid hadir</span>
              </div>
            </TooltipNozzle>

            <TooltipNozzle content="Jumlah murid yang scan setelah jam masuk" position="top" className="w-full">
              <div className="bg-white border-2 border-amber-100 rounded-3xl p-3.5 shadow-sm w-full">
                <p className="text-[11px] font-bold text-amber-600 uppercase">Terlambat</p>
                <p className="text-2xl font-black text-amber-700 mt-0.5">{totalTerlambat}</p>
                <span className="text-[10px] text-slate-400 font-medium">&gt; {settings.jamMasuk}</span>
              </div>
            </TooltipNozzle>

            <TooltipNozzle content="Jumlah murid yang belum melakukan scan presensi" position="top" className="w-full">
              <div className="bg-white border-2 border-rose-100 rounded-3xl p-3.5 shadow-sm w-full">
                <p className="text-[11px] font-bold text-rose-600 uppercase">Belum Hadir</p>
                <p className="text-2xl font-black text-rose-700 mt-0.5">{totalBelum}</p>
                <span className="text-[10px] text-slate-400 font-medium">Murid terdaftar</span>
              </div>
            </TooltipNozzle>

            <TooltipNozzle content="Persentase total murid yang hadir hari ini" position="top" className="w-full">
              <div className="bg-white border-2 border-sky-100 rounded-3xl p-3.5 shadow-sm w-full">
                <p className="text-[11px] font-bold text-[#0EA5E9] uppercase">Kehadiran</p>
                <p className="text-2xl font-black text-[#0EA5E9] mt-0.5">{attendancePercentage}%</p>
                <span className="text-[10px] text-slate-400 font-medium">Dari {totalMurid} total</span>
              </div>
            </TooltipNozzle>
          </div>

          {/* Real-time Attendance Feed List */}
          <div className="bg-white border-2 border-blue-100 rounded-[32px] p-5 sm:p-6 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-3">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-xl bg-sky-100 text-[#0EA5E9] flex items-center justify-center font-black text-xs">
                  <TrendingUp className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-sm text-[#1E293B]">Aktivitas Presensi Terkini</h3>
                  <p className="text-[11px] text-slate-400">Live sinkronisasi gerbang sekolah</p>
                </div>
              </div>
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-600">
                {recentRecords.length} Masuk
              </span>
            </div>

            {recentRecords.length === 0 ? (
              <div className="text-center py-10 text-slate-400">
                <Users className="w-10 h-10 mx-auto mb-2 opacity-40 text-[#0EA5E9]" />
                <p className="text-xs font-bold text-slate-600">Belum ada murid yang melakukan presensi hari ini.</p>
                <p className="text-[11px] text-slate-400 mt-0.5">Barcode di samping siap di-scan melalui perangkat murid.</p>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[340px] overflow-y-auto pr-1">
                {recentRecords.slice(0, 10).map((record) => (
                  <div
                    key={record.id}
                    className="p-3 bg-slate-50 hover:bg-sky-50/60 border border-slate-100 rounded-2xl flex items-center justify-between gap-3 transition-all"
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs shadow-sm ${
                        record.status === 'hadir'
                          ? 'bg-emerald-100 text-emerald-700'
                          : 'bg-amber-100 text-amber-700'
                      }`}>
                        {record.status === 'hadir' ? 'HD' : 'TL'}
                      </div>
                      <div>
                        <p className="text-xs font-black text-[#1E293B] leading-tight">
                          {record.namaSiswa}
                        </p>
                        <p className="text-[11px] text-slate-500">
                          Kelas <strong className="text-slate-700">{record.kelas}</strong> • NISN: <span className="font-mono">{record.nisn}</span>
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <p className="font-mono text-xs font-black text-emerald-700">
                        {record.waktuKedatangan} WIB
                      </p>
                      <div className="flex items-center justify-end space-x-1 mt-0.5">
                        {record.waTerkirim ? (
                          <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full flex items-center space-x-1">
                            <Send className="w-2.5 h-2.5" />
                            <span>WA Terkirim</span>
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold text-sky-700 bg-sky-100 px-2 py-0.5 rounded-full">
                            Tercatat
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* WhatsApp Direct Integration status banner */}
          <div className="bg-[#1E293B] text-white p-4 rounded-3xl shadow-md flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-500 text-white flex items-center justify-center shadow-md shadow-emerald-500/20">
                <Send className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">Layanan WhatsApp Orang Tua Aktif</h4>
                <p className="text-[11px] text-slate-300">Setiap scan otomatis mencantumkan nama murid, jam tepat, dan konfirmasi.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
