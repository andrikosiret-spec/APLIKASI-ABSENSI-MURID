import React, { useState, useEffect } from 'react';
import { 
  QrCode, 
  Users, 
  GraduationCap, 
  ShieldCheck, 
  Tv, 
  Clock, 
  LogOut, 
  Sparkles,
  School,
  ChevronDown,
  UserCheck
} from 'lucide-react';
import { UserAccount, PengaturanSekolah } from '../types';
import { getAllAvailableUsers, getCurrentUser, setCurrentUser } from '../services/storage';
import { TooltipNozzle } from './TooltipNozzle';

interface NavbarProps {
  currentUser: UserAccount;
  onUserChange: (user: UserAccount) => void;
  activeView: string;
  setActiveView: (view: string) => void;
  settings: PengaturanSekolah;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  onUserChange,
  activeView,
  setActiveView,
  settings,
}) => {
  const [currentTime, setCurrentTime] = useState<string>('');
  const [currentDate, setCurrentDate] = useState<string>('');
  const [dropdownOpen, setDropdownOpen] = useState<boolean>(false);
  const allUsers = getAllAvailableUsers();

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('id-ID', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }) + ' WIB'
      );
      setCurrentDate(
        now.toLocaleDateString('id-ID', {
          weekday: 'short',
          day: 'numeric',
          month: 'short',
          year: 'numeric',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleSelectUser = (u: UserAccount) => {
    setCurrentUser(u);
    onUserChange(u);
    setDropdownOpen(false);
    // Auto switch active view according to role
    if (u.role === 'kiosk') {
      setActiveView('kiosk');
    } else if (u.role === 'siswa') {
      setActiveView('siswa');
    } else if (u.role === 'guru') {
      setActiveView('guru');
    } else {
      setActiveView('admin');
    }
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'admin':
        return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700 border border-emerald-300">Admin Utama</span>;
      case 'guru':
        return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-700 border border-sky-300">Wali Kelas</span>;
      case 'siswa':
        return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-700 border border-purple-300">Portal Murid</span>;
      case 'kiosk':
        return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-700 border border-amber-300">Layar Monitor</span>;
      default:
        return null;
    }
  };

  return (
    <header className="bg-[#0EA5E9] text-white sticky top-0 z-40 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18 py-2">
          
          {/* Logo & School Name */}
          <div className="flex items-center space-x-3.5">
            <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-inner shrink-0 overflow-hidden p-1 border-2 border-white/40">
              {settings.logoSekolah ? (
                <img
                  src={settings.logoSekolah}
                  alt={settings.namaSekolah}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain rounded-xl"
                  onError={(e) => {
                    // Fallback to default icon if broken
                    (e.currentTarget as HTMLElement).style.display = 'none';
                    const parent = e.currentTarget.parentElement;
                    if (parent && !parent.querySelector('.logo-fallback')) {
                      const fallback = document.createElement('div');
                      fallback.className = 'w-full h-full bg-[#F43F5E] rounded-xl flex items-center justify-center text-white font-black text-xs logo-fallback';
                      fallback.innerText = settings.namaSekolah.charAt(0) || 'S';
                      parent.appendChild(fallback);
                    }
                  }}
                />
              ) : (
                <div className="w-full h-full bg-[#F43F5E] rounded-xl flex items-center justify-center text-white shadow-sm">
                  <School className="w-5 h-5 text-white stroke-[2.5]" />
                </div>
              )}
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-base sm:text-lg tracking-tight text-white leading-none">
                  {settings.namaSekolah}
                </span>
                <span className="hidden md:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-white/20 text-white border border-white/30 backdrop-blur-xs">
                  {settings.npsn ? `NPSN: ${settings.npsn}` : 'v2.0 WA Smart'}
                </span>
              </div>
              <p className="text-xs text-blue-100 font-medium mt-0.5 hidden sm:block">
                {settings.mottoVisi || 'Sistem Presensi Barcode Dinamis & Notifikasi WhatsApp Real-Time'}
              </p>
            </div>
          </div>

          {/* Center Navigation Tabs */}
          <div className="hidden lg:flex items-center space-x-1.5 bg-sky-700/40 backdrop-blur-sm p-1.5 rounded-2xl border border-sky-400/30">
            {currentUser.role === 'admin' && (
              <>
                <TooltipNozzle content="Buka Panel Administrator untuk kelola murid, wali kelas, dan pengaturan sekolah" position="bottom">
                  <button
                    id="nav-admin-btn"
                    onClick={() => setActiveView('admin')}
                    className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all ${
                      activeView === 'admin'
                        ? 'bg-white text-[#0EA5E9] shadow-md shadow-sky-900/10 scale-[1.02]'
                        : 'text-white/90 hover:text-white hover:bg-white/15'
                    }`}
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>Panel Admin</span>
                  </button>
                </TooltipNozzle>

                <TooltipNozzle content="Buka Presensi Rombel Kelas untuk cek data kehadiran murid hari ini" position="bottom">
                  <button
                    id="nav-guru-tab"
                    onClick={() => setActiveView('guru')}
                    className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all ${
                      activeView === 'guru'
                        ? 'bg-white text-[#0EA5E9] shadow-md shadow-sky-900/10 scale-[1.02]'
                        : 'text-white/90 hover:text-white hover:bg-white/15'
                    }`}
                  >
                    <Users className="w-4 h-4" />
                    <span>Presensi Kelas</span>
                  </button>
                </TooltipNozzle>
              </>
            )}

            {(currentUser.role === 'guru' || currentUser.role === 'admin') && (
              <TooltipNozzle content={`Akses presensi langsung kelas binaan ${currentUser.kelasAkses || 'Wali'}`} position="bottom">
                <button
                  id="nav-guru-direct-btn"
                  onClick={() => setActiveView('guru')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all ${
                    activeView === 'guru' && currentUser.role === 'guru'
                      ? 'bg-white text-[#0EA5E9] shadow-md shadow-sky-900/10 scale-[1.02]'
                      : 'text-white/90 hover:text-white hover:bg-white/15'
                  }`}
                >
                  <Users className="w-4 h-4" />
                  <span>Kelas {currentUser.kelasAkses || 'Wali'}</span>
                </button>
              </TooltipNozzle>
            )}

            <TooltipNozzle content="Buka scanner kamera murid untuk melakukan scan barcode kehadiran mandiri" position="bottom">
              <button
                id="nav-siswa-btn"
                onClick={() => setActiveView('siswa')}
                className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all ${
                  activeView === 'siswa'
                    ? 'bg-white text-[#0EA5E9] shadow-md shadow-sky-900/10 scale-[1.02]'
                    : 'text-white/90 hover:text-white hover:bg-white/15'
                }`}
              >
                <GraduationCap className="w-4 h-4" />
                <span>Scan Murid</span>
              </button>
            </TooltipNozzle>

            <TooltipNozzle content="Tampilkan layar monitor gerbang dengan QR dinamis dan audio penyambutan" position="bottom">
              <button
                id="nav-kiosk-btn"
                onClick={() => setActiveView('kiosk')}
                className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all ${
                  activeView === 'kiosk'
                    ? 'bg-[#F43F5E] text-white shadow-lg shadow-rose-900/20 scale-[1.02]'
                    : 'text-white/90 hover:text-white hover:bg-white/15'
                }`}
              >
                <Tv className="w-4 h-4" />
                <span>Layar Monitor Gerbang</span>
              </button>
            </TooltipNozzle>
          </div>

          {/* Right Side: Live Clock & Account Selector */}
          <div className="flex items-center space-x-3">
            {/* Live Clock Ticker */}
            <TooltipNozzle content="Waktu server otomatis Indonesia (WIB) sinkron dengan jam presensi" position="bottom">
              <div className="hidden sm:flex flex-col items-end px-3 py-1 bg-white/15 backdrop-blur-sm border border-white/25 rounded-2xl">
                <div className="flex items-center space-x-1.5 text-white font-mono font-black text-xs tracking-wider">
                  <Clock className="w-3.5 h-3.5 text-yellow-300 animate-pulse" />
                  <span>{currentTime}</span>
                </div>
                <span className="text-[10px] text-blue-100 font-medium">{currentDate}</span>
              </div>
            </TooltipNozzle>

            {/* Quick Switch User Dropdown */}
            <div className="relative">
              <TooltipNozzle content="Klik untuk beralih peran: Admin, Wali Kelas, Murid, atau Layar Monitor" position="left">
                <button
                  id="role-selector-btn"
                  onClick={() => setDropdownOpen(!dropdownOpen)}
                  className="flex items-center space-x-2.5 bg-white/15 hover:bg-white/25 border border-white/30 text-white px-3 py-1.5 rounded-2xl transition-all shadow-sm"
                >
                  <div className="w-8 h-8 rounded-full bg-white text-[#0EA5E9] font-black text-xs flex items-center justify-center shadow-inner border-2 border-white">
                    {currentUser.role === 'admin' ? 'AD' : currentUser.role === 'guru' ? 'GU' : currentUser.role === 'siswa' ? 'MR' : 'KS'}
                  </div>
                  <div className="text-left hidden sm:block">
                    <p className="text-xs font-bold leading-tight text-white line-clamp-1 max-w-[130px]">
                      {currentUser.nama}
                    </p>
                    <p className="text-[10px] text-blue-100 font-semibold uppercase tracking-wider">
                      {currentUser.role === 'guru' ? `Wali ${currentUser.kelasAkses || ''}` : currentUser.role === 'siswa' ? 'Murid' : currentUser.role}
                    </p>
                  </div>
                  <ChevronDown className="w-4 h-4 text-blue-100" />
                </button>
              </TooltipNozzle>

              {dropdownOpen && (
                <div 
                  className="absolute right-0 mt-2 w-76 bg-white border-2 border-blue-100 rounded-[28px] shadow-2xl py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150 text-[#1E293B]"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="px-4 py-2.5 border-b border-slate-100 bg-sky-50/70 rounded-t-[26px]">
                    <p className="text-[11px] font-black text-[#0EA5E9] uppercase tracking-wider">
                      Ganti Akun / Hak Akses Presensi
                    </p>
                    <p className="text-xs text-slate-500 font-medium">
                      Pilih peran untuk menguji alur sistem
                    </p>
                  </div>

                  <div className="max-h-72 overflow-y-auto py-1 px-2 space-y-1">
                    {allUsers.map((u) => {
                      const isSelected = u.id === currentUser.id;
                      return (
                        <button
                          key={u.id}
                          id={`switch-user-${u.id}`}
                          onClick={() => handleSelectUser(u)}
                          className={`w-full text-left px-3 py-2 rounded-2xl text-xs flex items-center justify-between transition-all ${
                            isSelected ? 'bg-sky-50 text-[#0EA5E9] font-bold border border-sky-200' : 'hover:bg-slate-50 text-slate-700'
                          }`}
                        >
                          <div className="flex items-center space-x-2.5">
                            <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-[10px] font-black shadow-sm ${
                              u.role === 'admin' ? 'bg-emerald-100 text-emerald-700' :
                              u.role === 'guru' ? 'bg-sky-100 text-sky-700' :
                              u.role === 'siswa' ? 'bg-purple-100 text-purple-700' :
                              'bg-amber-100 text-amber-700'
                            }`}>
                              {u.role.substring(0, 2).toUpperCase()}
                            </div>
                            <div>
                              <p className="font-bold leading-tight line-clamp-1">{u.nama}</p>
                              <div className="mt-0.5">{getRoleBadge(u.role)}</div>
                            </div>
                          </div>
                          {isSelected && <UserCheck className="w-4 h-4 text-[#0EA5E9]" />}
                        </button>
                      );
                    })}
                  </div>

                  <div className="p-2 border-t border-slate-100">
                    <button
                      onClick={() => {
                        setActiveView('kiosk');
                        setDropdownOpen(false);
                      }}
                      className="w-full py-2 px-3 rounded-xl text-xs font-bold bg-[#F43F5E] text-white hover:bg-rose-600 flex items-center justify-center space-x-1.5 transition-all shadow-md shadow-rose-200"
                    >
                      <Tv className="w-3.5 h-3.5" />
                      <span>Buka Layar Monitor Gerbang</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="flex lg:hidden overflow-x-auto py-2.5 gap-2 border-t border-sky-400/40 text-xs">
          {currentUser.role === 'admin' && (
            <button
              onClick={() => setActiveView('admin')}
              className={`px-3.5 py-1.5 rounded-full whitespace-nowrap font-bold transition-all ${
                activeView === 'admin' ? 'bg-white text-[#0EA5E9] shadow-sm' : 'bg-white/15 text-white'
              }`}
            >
              Panel Admin
            </button>
          )}
          {(currentUser.role === 'guru' || currentUser.role === 'admin') && (
            <button
              onClick={() => setActiveView('guru')}
              className={`px-3.5 py-1.5 rounded-full whitespace-nowrap font-bold transition-all ${
                activeView === 'guru' ? 'bg-white text-[#0EA5E9] shadow-sm' : 'bg-white/15 text-white'
              }`}
            >
              Presensi Kelas {currentUser.kelasAkses || ''}
            </button>
          )}
          <button
            onClick={() => setActiveView('siswa')}
            className={`px-3.5 py-1.5 rounded-full whitespace-nowrap font-bold transition-all ${
              activeView === 'siswa' ? 'bg-white text-[#0EA5E9] shadow-sm' : 'bg-white/15 text-white'
            }`}
          >
            Scan Murid
          </button>
          <button
            onClick={() => setActiveView('kiosk')}
            className={`px-3.5 py-1.5 rounded-full whitespace-nowrap font-bold transition-all ${
              activeView === 'kiosk' ? 'bg-[#F43F5E] text-white shadow-sm' : 'bg-white/15 text-white'
            }`}
          >
            Layar Gerbang
          </button>
        </div>
      </div>
    </header>
  );
};
