import React, { useEffect, useRef, useState } from 'react';
import jsQR from 'jsqr';
import { 
  Camera, 
  X, 
  RefreshCw, 
  AlertTriangle, 
  ShieldCheck, 
  Check, 
  Sparkles, 
  SwitchCamera, 
  Keyboard, 
  Info, 
  Zap, 
  HelpCircle,
  Eye,
  CheckCircle2
} from 'lucide-react';
import { PengaturanSekolah } from '../types';
import { TooltipNozzle } from './TooltipNozzle';

interface CameraScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScanSuccess: (scannedText: string, capturedSnapshot?: string) => void;
  title?: string;
  subtitle?: string;
  settings: PengaturanSekolah;
  allowDirectFaceSnapshot?: boolean;
}

export const CameraScannerModal: React.FC<CameraScannerModalProps> = ({
  isOpen,
  onClose,
  onScanSuccess,
  title = 'Scan Barcode & Tangkap Bukti Kehadiran Murid',
  subtitle = 'Arahkan kamera ke layar barcode proyektor sekolah atau posisikan wajah ananda',
  settings,
  allowDirectFaceSnapshot = true,
}) => {
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [manualCode, setManualCode] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [showManualInput, setShowManualInput] = useState<boolean>(false);
  const [capturedFlash, setCapturedFlash] = useState<boolean>(false);
  const [showGuide, setShowGuide] = useState<boolean>(false);
  
  // Mode selection: with snapshot proof or quick pass without snapshot
  const [modeSnapshot, setModeSnapshot] = useState<boolean>(settings.wajibFotoWajahScan ?? true);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animationFrameIdRef = useRef<number | null>(null);

  const stopCamera = () => {
    if (animationFrameIdRef.current) {
      cancelAnimationFrame(animationFrameIdRef.current);
      animationFrameIdRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
  };

  const startCamera = async () => {
    stopCamera();
    setCameraError(null);
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Perangkat atau browser ini tidak mendukung akses kamera langsung.');
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: facingMode },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        await videoRef.current.play();
        requestAnimationFrame(tickScan);
      }
    } catch (err) {
      console.warn('Camera access issue:', err);
      const errMsg = err instanceof Error ? err.message : 'Kamera tidak dapat diakses';
      setCameraError(
        `${errMsg}. Pastikan izin kamera telah diberikan di browser, atau gunakan input kode manual di bawah.`
      );
      setShowManualInput(true);
    }
  };

  // Helper to grab snapshot from current video frame
  const captureCurrentFrameSnapshot = (): string | undefined => {
    if (!modeSnapshot) return undefined;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (video && canvas && video.videoWidth > 0 && video.videoHeight > 0) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        return canvas.toDataURL('image/jpeg', 0.85);
      }
    }
    return undefined;
  };

  const tickScan = () => {
    if (isProcessing) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;

    if (video && canvas && video.readyState === video.HAVE_ENOUGH_DATA) {
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      if (ctx) {
        canvas.height = video.videoHeight;
        canvas.width = video.videoWidth;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: 'dontInvert',
        });

        if (code && code.data && code.data.trim().length > 0) {
          const snapshotPhoto = modeSnapshot ? canvas.toDataURL('image/jpeg', 0.85) : undefined;
          setIsProcessing(true);
          setCapturedFlash(true);
          stopCamera();
          setTimeout(() => {
            onScanSuccess(code.data.trim(), snapshotPhoto);
          }, 200);
          return;
        }
      }
    }

    if (isOpen) {
      animationFrameIdRef.current = requestAnimationFrame(tickScan);
    }
  };

  useEffect(() => {
    if (isOpen) {
      setIsProcessing(false);
      setCapturedFlash(false);
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, facingMode]);

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    const snapshotPhoto = captureCurrentFrameSnapshot();
    setIsProcessing(true);
    stopCamera();
    onScanSuccess(manualCode.trim(), snapshotPhoto);
  };

  const handleTakeSnapshotAndScan = () => {
    const snapshotPhoto = captureCurrentFrameSnapshot();
    setIsProcessing(true);
    setCapturedFlash(true);
    stopCamera();
    setTimeout(() => {
      onScanSuccess('FACE_SCAN_PRESENSI_BERHASIL', snapshotPhoto);
    }, 250);
  };

  const toggleCameraFacing = () => {
    setFacingMode(prev => (prev === 'environment' ? 'user' : 'environment'));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white border-2 border-blue-100 w-full max-w-xl rounded-[36px] overflow-hidden shadow-2xl flex flex-col text-[#1E293B] max-h-[95vh]">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-white">
          <div className="flex items-center space-x-3">
            <TooltipNozzle content="Kamera Pemindai Presensi Presisi Tinggi dengan Autentikasi Real-Time" badge="Info" position="bottom">
              <div className="w-11 h-11 rounded-2xl bg-[#0EA5E9] flex items-center justify-center text-white shadow-md shadow-sky-200">
                <Camera className="w-5 h-5" />
              </div>
            </TooltipNozzle>
            <div>
              <h3 className="text-base font-black text-[#1E293B] leading-tight">{title}</h3>
              <p className="text-xs text-slate-500 font-medium">{subtitle}</p>
            </div>
          </div>

          <div className="flex items-center space-x-1.5">
            <TooltipNozzle content="Klik untuk membaca panduan tata cara scan presensi langkah demi langkah" position="bottom">
              <button
                type="button"
                onClick={() => setShowGuide(!showGuide)}
                className={`p-2 rounded-xl text-xs font-bold transition-colors flex items-center space-x-1 ${
                  showGuide ? 'bg-sky-100 text-[#0EA5E9]' : 'text-slate-500 hover:bg-slate-100'
                }`}
              >
                <HelpCircle className="w-4 h-4" />
                <span className="hidden sm:inline">Panduan</span>
              </button>
            </TooltipNozzle>

            <TooltipNozzle content="Tutup jendela pemindai kamera" position="bottom">
              <button
                id="close-scanner-modal-btn"
                onClick={onClose}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </TooltipNozzle>
          </div>
        </div>

        {/* Live Operational Status & Mode Bar (Explaining Face Snapshot vs Quick Pass) */}
        <div className="px-6 py-2.5 bg-slate-50 border-b border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-bold text-slate-700">Status Operasi:</span>
            {modeSnapshot ? (
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center space-x-1">
                <Camera className="w-3 h-3" />
                <span>Tangkapan Foto Wajah Otomatis (Bukti Otentik)</span>
              </span>
            ) : (
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-100 text-amber-800 border border-amber-300 flex items-center space-x-1">
                <Zap className="w-3 h-3" />
                <span>Scan Barcode Cepat (Lewat Saja / Tanpa Foto)</span>
              </span>
            )}
          </div>

          {/* Mode Switcher Button */}
          <TooltipNozzle
            content={
              modeSnapshot
                ? "Klik untuk beralih ke Mode Cepat Lewat Saja (tanpa menyimpan foto wajah)"
                : "Klik untuk mengaktifkan Tangkapan Foto Wajah Otomatis sebagai bukti otentik presensi"
            }
            position="bottom"
          >
            <button
              type="button"
              onClick={() => setModeSnapshot(!modeSnapshot)}
              className="px-3 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-[11px] font-bold shadow-xs transition-colors"
            >
              Ubah Mode: {modeSnapshot ? 'Matikan Foto' : 'Aktifkan Foto'}
            </button>
          </TooltipNozzle>
        </div>

        {/* Expandable Tata Cara Penggunaan Guide */}
        {showGuide && (
          <div className="p-4 bg-sky-50 border-b border-sky-100 text-xs text-slate-700 space-y-2 animate-in slide-in-from-top-2 duration-150">
            <div className="flex items-center justify-between text-[#0EA5E9] font-black text-xs">
              <span className="flex items-center space-x-1.5">
                <Info className="w-4 h-4" />
                <span>Tata Cara Penggunaan Pemindai Presensi:</span>
              </span>
              <button onClick={() => setShowGuide(false)} className="text-slate-400 hover:text-slate-600 font-bold">
                Tutup
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-[11px]">
              <div className="p-2.5 bg-white rounded-2xl border border-sky-200">
                <strong className="text-[#0EA5E9] block mb-0.5">1. Posisikan Kamera</strong>
                Arahkan lensa ke barcode dinamis pada layar monitor gerbang atau barcode kartu murid.
              </div>
              <div className="p-2.5 bg-white rounded-2xl border border-sky-200">
                <strong className="text-[#0EA5E9] block mb-0.5">2. Verifikasi Wajah</strong>
                Jika mode foto aktif, posisikan wajah tepat di dalam bingkai agar sistem memotret bukti hadir.
              </div>
              <div className="p-2.5 bg-white rounded-2xl border border-sky-200">
                <strong className="text-[#0EA5E9] block mb-0.5">3. Jam & WA Terkirim</strong>
                Waktu resmi dicatat otomatis dan notifikasi WhatsApp langsung terkirim ke nomor orang tua.
              </div>
            </div>
          </div>
        )}

        {/* Video Scanner Viewport Area */}
        <div className="relative bg-slate-950 flex flex-col items-center justify-center min-h-[300px] sm:min-h-[340px] overflow-hidden">
          {capturedFlash && (
            <div className="absolute inset-0 bg-white z-20 animate-out fade-out duration-300 pointer-events-none" />
          )}

          {cameraError ? (
            <div className="p-6 text-center text-slate-300 max-w-sm">
              <AlertTriangle className="w-12 h-12 mx-auto mb-3 text-amber-400" />
              <p className="text-sm font-bold text-white mb-1">Akses Kamera Terkendala</p>
              <p className="text-xs text-slate-400 mb-4">{cameraError}</p>
              <button
                onClick={startCamera}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-2xl text-white transition-colors border border-slate-700 inline-flex items-center space-x-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Coba Hubungkan Ulang Kamera</span>
              </button>
            </div>
          ) : (
            <>
              <video
                ref={videoRef}
                className="w-full h-full max-h-[360px] object-cover"
                autoPlay
                playsInline
                muted
              />
              <canvas ref={canvasRef} className="hidden" />

              {/* Viewfinder Target Overlay with Nozzle Tooltip */}
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                <div className="w-56 h-56 border-2 border-dashed border-[#0EA5E9] rounded-3xl relative shadow-[0_0_0_9999px_rgba(0,0,0,0.48)]">
                  <div className="absolute -top-1 -left-1 w-6 h-6 border-t-4 border-l-4 border-[#0EA5E9] rounded-tl-xl" />
                  <div className="absolute -top-1 -right-1 w-6 h-6 border-t-4 border-r-4 border-[#0EA5E9] rounded-tr-xl" />
                  <div className="absolute -bottom-1 -left-1 w-6 h-6 border-b-4 border-l-4 border-[#0EA5E9] rounded-bl-xl" />
                  <div className="absolute -bottom-1 -right-1 w-6 h-6 border-b-4 border-r-4 border-[#0EA5E9] rounded-br-xl" />
                  
                  {/* Laser Scan Line Animation */}
                  <div className="w-full h-0.5 bg-gradient-to-r from-transparent via-[#0EA5E9] to-transparent absolute top-1/2 -translate-y-1/2 animate-bounce" />

                  {/* Real-Time Auto-Capture Mode Notice */}
                  <div className="absolute -bottom-11 inset-x-0 text-center">
                    <span className="px-3.5 py-1 bg-black/80 backdrop-blur-md rounded-full text-[10px] font-bold text-white tracking-wide border border-white/20 shadow-lg">
                      {modeSnapshot ? '📸 Tangkapan Snapshot Wajah Aktif' : '⚡ Mode Cepat (Hanya Barcode Lewat)'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Controls bar over video with Tooltip Nozzles */}
              <div className="absolute bottom-3 inset-x-0 flex justify-center items-center space-x-2 px-4 pointer-events-auto">
                <TooltipNozzle content="Beralih antara kamera depan untuk foto wajah atau kamera belakang" position="top">
                  <button
                    id="scanner-toggle-camera"
                    type="button"
                    onClick={toggleCameraFacing}
                    className="px-3 py-1.5 rounded-2xl bg-white/90 backdrop-blur-md text-slate-800 border border-slate-200 text-xs font-bold hover:bg-white flex items-center space-x-1.5 shadow-sm"
                  >
                    <SwitchCamera className="w-3.5 h-3.5 text-[#0EA5E9]" />
                    <span>{facingMode === 'environment' ? 'Kamera Depan' : 'Kamera Belakang'}</span>
                  </button>
                </TooltipNozzle>

                {allowDirectFaceSnapshot && (
                  <TooltipNozzle content="Tangkap foto wajah saat ini langsung sebagai bukti kehadiran" position="top">
                    <button
                      id="scanner-take-face-snapshot"
                      type="button"
                      onClick={handleTakeSnapshotAndScan}
                      className="px-4 py-1.5 rounded-2xl bg-[#0EA5E9] hover:bg-sky-600 text-white text-xs font-black flex items-center space-x-1.5 shadow-md shadow-sky-400"
                    >
                      <Camera className="w-3.5 h-3.5" />
                      <span>Ambil Foto Kehadiran</span>
                    </button>
                  </TooltipNozzle>
                )}

                <TooltipNozzle content="Input kode token QR atau NISN murid secara manual jika kamera kendala" position="top">
                  <button
                    id="scanner-toggle-manual"
                    type="button"
                    onClick={() => setShowManualInput(!showManualInput)}
                    className="px-3 py-1.5 rounded-2xl bg-white/90 backdrop-blur-md text-slate-800 border border-slate-200 text-xs font-bold hover:bg-white flex items-center space-x-1.5 shadow-sm"
                  >
                    <Keyboard className="w-3.5 h-3.5 text-[#0EA5E9]" />
                    <span>{showManualInput ? 'Tutup' : 'Manual'}</span>
                  </button>
                </TooltipNozzle>
              </div>
            </>
          )}
        </div>

        {/* Manual Fallback Input Form */}
        {showManualInput && (
          <div className="p-4 bg-slate-50 border-t border-slate-100 animate-in slide-in-from-bottom-2 duration-150">
            <form onSubmit={handleManualSubmit} className="space-y-2">
              <label className="block text-xs font-bold text-slate-700">
                Input Kode QR / NISN Murid Secara Manual:
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={manualCode}
                  onChange={e => setManualCode(e.target.value)}
                  placeholder="Contoh: 0098451201 atau token QR..."
                  className="flex-1 px-3.5 py-2 bg-white border-2 border-slate-200 rounded-2xl text-xs text-[#1E293B] placeholder-slate-400 focus:outline-none focus:border-[#0EA5E9] font-medium"
                />
                <TooltipNozzle content="Verifikasi dan simpan presensi dengan kode yang diinput" position="top">
                  <button
                    type="submit"
                    disabled={!manualCode.trim()}
                    className="px-4 py-2 bg-[#0EA5E9] hover:bg-sky-600 disabled:opacity-50 text-white rounded-2xl text-xs font-bold transition-all flex items-center space-x-1 shadow-sm"
                  >
                    <Check className="w-4 h-4" />
                    <span>Proses</span>
                  </button>
                </TooltipNozzle>
              </div>
            </form>
          </div>
        )}

        {/* Footer info with Tooltip Nozzles */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 font-medium">
          <TooltipNozzle content="Data presensi dan foto snapshot dienkripsi serta tersimpan aman di database sekolah" position="top">
            <div className="flex items-center space-x-1.5 text-emerald-700 font-bold">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>{modeSnapshot ? 'Foto Snapshot Terverifikasi Otomatis' : 'Mode Presensi Cepat Aktif'}</span>
            </div>
          </TooltipNozzle>

          <span className="font-bold text-slate-700">{settings.namaSekolah}</span>
        </div>
      </div>
    </div>
  );
};
