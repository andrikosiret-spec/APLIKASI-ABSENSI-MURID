import React, { useState, useEffect } from 'react';
import { 
  Camera, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Send, 
  QrCode, 
  User, 
  Calendar, 
  ShieldCheck, 
  Sparkles, 
  Smartphone,
  Check,
  AlertTriangle,
  FileText,
  CreditCard,
  MessageSquare,
  Award,
  TrendingUp,
  MapPin,
  ChevronRight,
  Info,
  Zap,
  HelpCircle,
  Eye
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Siswa, PresensiRecord, PengaturanSekolah, UserAccount } from '../types';
import { validateDynamicToken } from '../services/qrSecurity';
import { 
  getSiswaList, 
  getPresensiRecords, 
  addPresensiRecord, 
  findSiswaByNisn,
  subscribeToDataChanges,
  markWhatsAppSent
} from '../services/storage';
import { generateWhatsAppMessage, createWhatsAppDirectUrl } from '../services/whatsapp';
import { CameraScannerModal } from './CameraScannerModal';
import { WhatsAppPreviewModal } from './WhatsAppPreviewModal';
import { TooltipNozzle } from './TooltipNozzle';

interface SiswaPortalProps {
  currentUser: UserAccount;
  settings: PengaturanSekolah;
}

export const SiswaPortal: React.FC<SiswaPortalProps> = ({
  currentUser,
  settings,
}) => {
  const [students, setStudents] = useState<Siswa[]>([]);
  const [selectedSiswaId, setSelectedSiswaId] = useState<string>(currentUser.siswaId || '');
  const [isScannerOpen, setIsScannerOpen] = useState<boolean>(false);
  const [scanResultRecord, setScanResultRecord] = useState<PresensiRecord | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [studentRecords, setStudentRecords] = useState<PresensiRecord[]>([]);
  const [previewWAModalOpen, setPreviewWAModalOpen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'presensi' | 'riwayat' | 'kartu'>('presensi');
  const [showCaraPenggunaan, setShowCaraPenggunaan] = useState<boolean>(false);

  const getTodayISO = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };

  const loadData = () => {
    const list = getSiswaList();
    setStudents(list);

    let targetId = selectedSiswaId;
    if (!targetId && list.length > 0) {
      targetId = list[0].id;
      setSelectedSiswaId(targetId);
    }

    if (targetId) {
      const allRecords = getPresensiRecords();
      const userRecs = allRecords.filter(r => r.siswaId === targetId);
      setStudentRecords(userRecs);

      // Check if student already checked in today
      const today = getTodayISO();
      const todayRec = userRecs.find(r => r.tanggal === today);
      if (todayRec) {
        setScanResultRecord(todayRec);
      } else {
        setScanResultRecord(null);
      }
    }
  };

  useEffect(() => {
    loadData();
    const unsub = subscribeToDataChanges(loadData);
    return () => unsub();
  }, [selectedSiswaId, currentUser]);

  const currentSiswa = students.find(s => s.id === selectedSiswaId) || students[0];

  // Process the scanned token from school live monitor & save optional photo snapshot
  const handleScanDynamicQR = (scannedContent: string, capturedSnapshot?: string) => {
    setIsScannerOpen(false);
    setErrorMessage(null);

    // 1. Verify student registration
    if (!currentSiswa) {
      setErrorMessage('Murid tidak teridentifikasi. Pastikan data murid telah didaftarkan oleh Admin.');
      return;
    }

    // 2. Anti-Cheat: Validate dynamic token authenticity & expiration
    const validation = validateDynamicToken(scannedContent, settings.secretTokenSalt, 30);
    
    // Check if the user entered manual NISN of another student or a dynamic token
    if (!validation.isValid) {
      if (scannedContent.length === 10 && /^\d+$/.test(scannedContent)) {
        const found = findSiswaByNisn(scannedContent);
        if (!found) {
          setErrorMessage('❌ Akses Ditolak: NISN tersebut tidak terdaftar di sistem murid sekolah.');
          return;
        }
      } else if (scannedContent === 'FACE_SCAN_PRESENSI_BERHASIL') {
        // Direct face snapshot scan approved
      } else {
        setErrorMessage(`❌ Presensi Gagal: ${validation.message}`);
        return;
      }
    }

    // 3. Capture exact immutable server timestamp
    const now = new Date();
    const today = getTodayISO();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const waktuKedatangan = `${hours}:${minutes}:${seconds}`;

    // 4. Check if student already scanned today (prevent duplicate)
    const existing = getPresensiRecords().find(r => r.siswaId === currentSiswa.id && r.tanggal === today);
    if (existing) {
      setScanResultRecord(existing);
      setErrorMessage(`ℹ️ Ananda sudah melakukan presensi hari ini pada pukul ${existing.waktuKedatangan} WIB.`);
      return;
    }

    // 5. Calculate on-time or late status
    const [jamMasukH, jamMasukM] = settings.jamMasuk.split(':').map(Number);
    const masukTotalMinutes = jamMasukH * 60 + jamMasukM;
    const kedatanganTotalMinutes = now.getHours() * 60 + now.getMinutes();
    
    let isLate = false;
    let menitKeterlambatan = 0;

    if (kedatanganTotalMinutes > masukTotalMinutes) {
      isLate = true;
      menitKeterlambatan = kedatanganTotalMinutes - masukTotalMinutes;
    }

    const newRecord: PresensiRecord = {
      id: `PR-${today.replace(/-/g, '')}-${currentSiswa.id}`,
      siswaId: currentSiswa.id,
      nisn: currentSiswa.nisn,
      namaSiswa: currentSiswa.nama,
      kelas: currentSiswa.kelas,
      tanggal: today,
      waktuKedatangan,
      timestamp: Date.now(),
      status: isLate ? 'terlambat' : 'hadir',
      menitKeterlambatan,
      metode: capturedSnapshot ? 'scan_qr_dan_wajah' : 'scan_qr_dinamis',
      waTerkirim: false,
      verifikasiToken: scannedContent.substring(0, 20) + '...',
      fotoBuktiScan: capturedSnapshot,
    };

    // Save record to persistent storage
    addPresensiRecord(newRecord);
    setScanResultRecord(newRecord);

    // Trigger celebration effects
    confetti({
      particleCount: 75,
      spread: 80,
      origin: { y: 0.6 },
    });

    // Auto open WhatsApp Preview modal if enabled or to ensure parent gets notified immediately
    if (settings.autoKirimWA ?? true) {
      setTimeout(() => {
        setPreviewWAModalOpen(true);
      }, 600);
    }
  };

  const today = getTodayISO();
  const alreadyCheckedInToday = scanResultRecord && scanResultRecord.tanggal === today;

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 sm:py-8 space-y-6">
      
      {/* Student Profile & Quick Switcher Card */}
      <div className="bg-white border-2 border-blue-100 rounded-[32px] p-5 sm:p-6 shadow-sm relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center space-x-4">
            <TooltipNozzle content="Foto profil identitas resmi murid yang terdaftar di sekolah" position="bottom">
              <div className="w-16 h-16 rounded-[22px] bg-[#0EA5E9] p-0.5 shadow-lg shadow-sky-200 shrink-0">
                <div className="w-full h-full bg-white rounded-[20px] overflow-hidden flex items-center justify-center">
                  {currentSiswa?.fotoUrl ? (
                    <img src={currentSiswa.fotoUrl} alt={currentSiswa.nama} className="w-full h-full object-cover" />
                  ) : (
                    <User className="w-8 h-8 text-[#0EA5E9]" />
                  )}
                </div>
              </div>
            </TooltipNozzle>

            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-lg sm:text-xl font-black text-[#1E293B] leading-tight">
                  {currentSiswa?.nama || 'Pilih Murid'}
                </h2>
                <TooltipNozzle content={`Murid terdaftar di rombongan belajar Kelas ${currentSiswa?.kelas}`} position="top">
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-sky-100 text-[#0EA5E9] border border-sky-300">
                    Kelas {currentSiswa?.kelas}
                  </span>
                </TooltipNozzle>
              </div>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                NISN: <span className="font-mono text-[#0EA5E9] font-bold">{currentSiswa?.nisn}</span> • Orang Tua / Wali: <strong className="text-[#1E293B]">{currentSiswa?.namaOrangTua}</strong>
              </p>
              <TooltipNozzle content="Nomor WhatsApp orang tua penerima notifikasi otomatis presensi" position="bottom">
                <p className="text-[11px] text-slate-500">
                  Nomor WhatsApp Orang Tua: <span className="text-emerald-700 font-bold font-mono">+{currentSiswa?.noHpOrangTua}</span>
                </p>
              </TooltipNozzle>
            </div>
          </div>

          {/* Quick Student Switcher with Tooltip */}
          <div className="w-full sm:w-auto">
            <TooltipNozzle content="Pilih akun profil murid lain untuk simulasi scan atau melihat rekap kehadiran" position="left">
              <label className="block text-[11px] font-black text-[#0EA5E9] uppercase tracking-wider mb-1">
                Ganti Profil Murid:
              </label>
            </TooltipNozzle>
            <select
              id="student-select-dropdown"
              value={selectedSiswaId}
              onChange={e => setSelectedSiswaId(e.target.value)}
              className="w-full sm:w-56 px-3 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-xs font-bold text-[#1E293B] focus:outline-none focus:border-[#0EA5E9]"
            >
              {students.map(s => (
                <option key={s.id} value={s.id}>
                  {s.nama} ({s.kelas}) - {s.nisn}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Tab Navigation with Tooltip Nozzles */}
        <div className="flex flex-wrap items-center justify-between border-t border-slate-100 mt-5 pt-4 gap-2">
          <div className="flex flex-wrap gap-2">
            <TooltipNozzle content="Lakukan pemindaian barcode atau tangkapan wajah kehadiran hari ini" position="top">
              <button
                onClick={() => setActiveTab('presensi')}
                className={`px-4 py-2 rounded-2xl text-xs font-black transition-all flex items-center space-x-1.5 ${
                  activeTab === 'presensi'
                    ? 'bg-[#0EA5E9] text-white shadow-md shadow-sky-200 scale-[1.02]'
                    : 'text-slate-600 hover:text-[#0EA5E9] hover:bg-sky-50'
                }`}
              >
                <QrCode className="w-4 h-4" />
                <span>Scan Presensi Hari Ini</span>
              </button>
            </TooltipNozzle>

            <TooltipNozzle content={`Lihat daftar riwayat log kehadiran ananda (${studentRecords.length} catatan)`} position="top">
              <button
                onClick={() => setActiveTab('riwayat')}
                className={`px-4 py-2 rounded-2xl text-xs font-black transition-all flex items-center space-x-1.5 ${
                  activeTab === 'riwayat'
                    ? 'bg-[#0EA5E9] text-white shadow-md shadow-sky-200 scale-[1.02]'
                    : 'text-slate-600 hover:text-[#0EA5E9] hover:bg-sky-50'
                }`}
              >
                <Calendar className="w-4 h-4" />
                <span>Riwayat Kehadiran ({studentRecords.length})</span>
              </button>
            </TooltipNozzle>

            <TooltipNozzle content="Tampilkan Kartu Tanda Pelajar Digital lengkap dengan barcode identitas murid" position="top">
              <button
                onClick={() => setActiveTab('kartu')}
                className={`px-4 py-2 rounded-2xl text-xs font-black transition-all flex items-center space-x-1.5 ${
                  activeTab === 'kartu'
                    ? 'bg-[#0EA5E9] text-white shadow-md shadow-sky-200 scale-[1.02]'
                    : 'text-slate-600 hover:text-[#0EA5E9] hover:bg-sky-50'
                }`}
              >
                <CreditCard className="w-4 h-4" />
                <span>Kartu Pelajar Digital</span>
              </button>
            </TooltipNozzle>
          </div>

          <TooltipNozzle content="Klik untuk membuka tata cara lengkap penggunaan pemindai presensi" position="left">
            <button
              onClick={() => setShowCaraPenggunaan(!showCaraPenggunaan)}
              className="text-xs font-bold text-[#0EA5E9] hover:underline flex items-center space-x-1 py-1 px-2.5 rounded-xl hover:bg-sky-50 transition-colors"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>{showCaraPenggunaan ? 'Sembunyikan Tata Cara' : 'Tata Cara Penggunaan'}</span>
            </button>
          </TooltipNozzle>
        </div>
      </div>

      {/* Expandable Tata Cara Penggunaan Section */}
      {showCaraPenggunaan && (
        <div className="bg-sky-50 border-2 border-sky-200 rounded-3xl p-5 shadow-xs space-y-3 animate-in fade-in duration-200">
          <div className="flex items-center space-x-2 text-[#0EA5E9]">
            <Info className="w-5 h-5" />
            <h4 className="text-sm font-black">Tata Cara Penggunaan Presensi Murid & Penjelasan Fitur</h4>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-slate-700">
            <div className="p-3.5 bg-white rounded-2xl border border-sky-100 shadow-xs space-y-1">
              <strong className="text-[#0EA5E9] block font-black">1. Buka Kamera Pemindai</strong>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Klik tombol <strong>Buka Kamera & Scan Presensi</strong> di bawah. Arahkan kamera smartphone ke barcode proyektor sekolah.
              </p>
            </div>

            <div className="p-3.5 bg-white rounded-2xl border border-sky-100 shadow-xs space-y-1">
              <strong className="text-[#0EA5E9] block font-black">2. Bukti Tangkapan Foto</strong>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Kamera akan otomatis menangkap foto wajah murid saat scan sebagai <strong>bukti otentik kehadiran</strong> guna mencegah titip absen.
              </p>
            </div>

            <div className="p-3.5 bg-white rounded-2xl border border-sky-100 shadow-xs space-y-1">
              <strong className="text-[#0EA5E9] block font-black">3. WhatsApp Orang Tua Otomatis</strong>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Jam kedatangan tersimpan permanen dan notifikasi WhatsApp langsung disiapkan terkirim ke HP wali murid.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Error / Alert Message Banner */}
      {errorMessage && (
        <div className="bg-amber-50 border-2 border-amber-200 p-4 rounded-3xl flex items-start space-x-3 text-amber-900 text-xs animate-in fade-in duration-200">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-bold text-amber-950">Informasi Presensi</p>
            <p className="mt-0.5 leading-relaxed font-medium">{errorMessage}</p>
          </div>
          <button
            onClick={() => setErrorMessage(null)}
            className="text-amber-700 hover:text-amber-950 text-xs font-bold px-2 py-1"
          >
            Tutup
          </button>
        </div>
      )}

      {/* TAB 1: ACTIVE ATTENDANCE SCANNER VIEW */}
      {activeTab === 'presensi' && (
        <div className="space-y-6">
          
          {/* Main Action Card */}
          <div className="bg-white border-2 border-blue-100 rounded-[36px] p-6 sm:p-8 text-center shadow-sm relative overflow-hidden">
            
            {alreadyCheckedInToday ? (
              /* Already Checked In State */
              <div className="space-y-5 max-w-md mx-auto">
                <div className="w-18 h-18 rounded-3xl bg-emerald-50 border-2 border-emerald-300 text-emerald-600 flex items-center justify-center mx-auto shadow-md shadow-emerald-100">
                  <Check className="w-10 h-10 stroke-[3]" />
                </div>
                
                <div>
                  <span className="px-3.5 py-1 rounded-full text-xs font-black bg-emerald-100 text-emerald-800 border border-emerald-300">
                    Presensi Hari Ini Telah Berhasil
                  </span>
                  <h3 className="text-xl sm:text-2xl font-black text-[#1E293B] mt-2.5">
                    {scanResultRecord.status === 'hadir' ? 'Hadir Tepat Waktu' : `Terlambat (+${scanResultRecord.menitKeterlambatan} menit)`}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 font-medium">
                    Waktu Kedatangan Resmi (Otomatis & Terkunci):
                  </p>
                  <p className="text-3xl sm:text-4xl font-black font-mono text-emerald-600 mt-1">
                    {scanResultRecord.waktuKedatangan} <span className="text-base font-bold text-emerald-700">WIB</span>
                  </p>
                </div>

                {/* Bukti Foto Snapshot Wajah */}
                {scanResultRecord.fotoBuktiScan && (
                  <div className="p-3.5 bg-slate-50 border-2 border-slate-200 rounded-3xl text-left space-y-2">
                    <span className="text-[11px] font-bold text-slate-500 flex items-center space-x-1.5">
                      <Camera className="w-3.5 h-3.5 text-[#0EA5E9]" />
                      <span>Bukti Foto Tangkapan Kamera Saat Scan:</span>
                    </span>
                    <div className="w-32 h-24 rounded-2xl overflow-hidden border-2 border-sky-300 shadow-sm mx-auto">
                      <img
                        src={scanResultRecord.fotoBuktiScan}
                        alt="Bukti Foto Scan"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                )}

                {/* WhatsApp status card */}
                <div className="bg-slate-50 border-2 border-slate-200 rounded-3xl p-5 text-left">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2 text-xs font-bold text-[#1E293B]">
                      <MessageSquare className="w-4 h-4 text-emerald-600" />
                      <span>Notifikasi WhatsApp Orang Tua</span>
                    </div>
                    {scanResultRecord.waTerkirim ? (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300">
                        Terkirim
                      </span>
                    ) : (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-100 text-amber-800 border border-amber-300">
                        Siap Kirim
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-600 mt-2">
                    Nomor Tujuan: <strong className="text-[#1E293B]">{currentSiswa.namaOrangTua} ({currentSiswa.noHpOrangTua})</strong>
                  </p>

                  <TooltipNozzle content="Buka pesan WhatsApp resmi untuk dikirimkan langsung ke nomor wali murid" position="top">
                    <button
                      id="student-open-wa-btn"
                      onClick={() => setPreviewWAModalOpen(true)}
                      className="w-full mt-3.5 py-3 px-4 rounded-2xl bg-[#10B981] hover:bg-emerald-600 text-white font-bold text-xs sm:text-sm flex items-center justify-center space-x-2 transition-all shadow-md shadow-emerald-200"
                    >
                      <Send className="w-4 h-4" />
                      <span>{scanResultRecord.waTerkirim ? 'Kirim Ulang / Lihat Pesan WA' : 'Kirim Notifikasi WA ke Orang Tua Sekarang'}</span>
                    </button>
                  </TooltipNozzle>
                </div>

                <div className="text-[11px] text-slate-400 font-medium">
                  Data kehadiran tersimpan permanen di database sekolah dan tidak dapat diubah oleh murid.
                </div>
              </div>
            ) : (
              /* Ready to Scan State */
              <div className="space-y-5 max-w-lg mx-auto">
                <TooltipNozzle content="Arahkan kamera smartphone Anda ke layar barcode proyektor sekolah" position="bottom">
                  <div className="w-20 h-20 rounded-[28px] bg-sky-50 border-2 border-sky-200 text-[#0EA5E9] flex items-center justify-center mx-auto shadow-sm">
                    <Camera className="w-10 h-10" />
                  </div>
                </TooltipNozzle>

                <div>
                  <h3 className="text-xl sm:text-2xl font-black text-[#1E293B]">
                    Scan Presensi Kehadiran Murid
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-500 mt-1.5 leading-relaxed font-medium">
                    Arahkan kamera smartphone ke barcode dinamis di layar monitor gerbang sekolah atau gunakan foto snapshot wajah.
                  </p>
                </div>

                {/* Status Penjelasan Snapshot vs Lewat */}
                <div className="p-4 bg-sky-50/80 border-2 border-sky-200 rounded-3xl text-left space-y-2">
                  <div className="flex items-center space-x-2 text-xs font-bold text-[#0EA5E9]">
                    <ShieldCheck className="w-4 h-4" />
                    <span>Mode Operasi Pemindai Aktif:</span>
                  </div>
                  <div className="flex items-center space-x-2 text-xs text-slate-700">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
                    <span className="font-semibold">
                      {settings.wajibFotoWajahScan ?? true 
                        ? '📸 Tangkapan Wajah Otomatis Aktif (Foto diambil saat scan sebagai bukti otentik)'
                        : '⚡ Scan Barcode Cepat (Hanya lewat & pindai kode QR tanpa simpan foto)'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-snug">
                    Kegunaan: Memastikan kehadiran fisik murid di sekolah, mencatat jam masuk detik presisi, dan otomatis mengirim notifikasi WhatsApp kepada orang tua.
                  </p>
                </div>

                <TooltipNozzle content="Buka kamera perangkat untuk memindai barcode presensi dan menangkap foto kehadiran" position="top">
                  <button
                    id="student-start-scan-btn"
                    onClick={() => setIsScannerOpen(true)}
                    className="w-full py-4 px-6 rounded-2xl bg-[#0EA5E9] hover:bg-sky-600 text-white font-black text-sm sm:text-base flex items-center justify-center space-x-2 shadow-xl shadow-sky-200 transition-all transform hover:-translate-y-0.5 active:translate-y-0"
                  >
                    <Camera className="w-5 h-5" />
                    <span>Buka Kamera & Scan Presensi Sekarang</span>
                  </button>
                </TooltipNozzle>
              </div>
            )}
          </div>

          {/* Quick Attendance Rules Reference with Tooltip Nozzles */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <TooltipNozzle content="Batas waktu jam masuk pagi. Tiba sebelum jam ini tercatat Hadir Tepat Waktu." position="top" className="w-full">
              <div className="bg-white border-2 border-emerald-100 p-5 rounded-3xl shadow-sm w-full">
                <div className="flex items-center space-x-2 text-emerald-700 font-bold mb-1">
                  <Clock className="w-4 h-4" />
                  <span>Jam Masuk Tepat Waktu</span>
                </div>
                <p className="text-[#1E293B] font-bold">Sebelum pukul {settings.jamMasuk} WIB</p>
                <p className="text-[11px] text-slate-500 mt-1 font-medium">Status hadir tepat waktu, tercatat di raport kedisiplinan murid.</p>
              </div>
            </TooltipNozzle>

            <TooltipNozzle content="Tiba setelah jam masuk dihitung menit keterlambatan dan dikirim pesan notifikasi khusus ke orang tua." position="top" className="w-full">
              <div className="bg-white border-2 border-amber-100 p-5 rounded-3xl shadow-sm w-full">
                <div className="flex items-center space-x-2 text-amber-700 font-bold mb-1">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Batas Keterlambatan</span>
                </div>
                <p className="text-[#1E293B] font-bold">Setelah {settings.jamMasuk} WIB (+{settings.toleransiTerlambatMenit} mnt)</p>
                <p className="text-[11px] text-slate-500 mt-1 font-medium">Notifikasi pesan khusus terlambat dikirim ke WhatsApp orang tua.</p>
              </div>
            </TooltipNozzle>

            <TooltipNozzle content="Untuk ketidakhadiran karena sakit atau izin keluarga, laporkan ke wali kelas." position="top" className="w-full">
              <div className="bg-white border-2 border-sky-100 p-5 rounded-3xl shadow-sm w-full">
                <div className="flex items-center space-x-2 text-[#0EA5E9] font-bold mb-1">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Izin & Sakit</span>
                </div>
                <p className="text-[#1E293B] font-bold">Konfirmasi ke Wali Kelas</p>
                <p className="text-[11px] text-slate-500 mt-1 font-medium">Surat dokter / izin diinput oleh Wali Kelas {currentSiswa.kelas}.</p>
              </div>
            </TooltipNozzle>
          </div>
        </div>
      )}

      {/* TAB 2: ATTENDANCE HISTORY */}
      {activeTab === 'riwayat' && (
        <div className="bg-white border-2 border-blue-100 rounded-[32px] p-5 sm:p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-base font-black text-[#1E293B]">
                Riwayat Presensi Murid: {currentSiswa.nama}
              </h3>
              <p className="text-xs text-slate-500 font-medium">Total {studentRecords.length} catatan kehadiran tersimpan</p>
            </div>
          </div>

          {studentRecords.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <Calendar className="w-12 h-12 mx-auto mb-2 opacity-30 text-[#0EA5E9]" />
              <p className="text-sm font-bold text-slate-600">Belum ada riwayat presensi yang tercatat.</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {studentRecords.map(record => (
                <div key={record.id} className="py-3 flex items-center justify-between gap-3 text-xs">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-2xl flex items-center justify-center font-black text-xs shadow-sm ${
                      record.status === 'hadir'
                        ? 'bg-emerald-100 text-emerald-700'
                        : record.status === 'terlambat'
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-sky-100 text-sky-700'
                    }`}>
                      {record.status === 'hadir' ? 'HD' : record.status === 'terlambat' ? 'TL' : 'IZ'}
                    </div>
                    <div>
                      <p className="font-bold text-[#1E293B] text-sm">{record.tanggal}</p>
                      <p className="text-[11px] text-slate-500 font-medium">
                        Waktu Datang: <span className="font-mono text-emerald-700 font-bold">{record.waktuKedatangan} WIB</span>
                        {record.menitKeterlambatan > 0 && (
                          <span className="text-amber-700 ml-1 font-bold">({record.menitKeterlambatan} mnt terlambat)</span>
                        )}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <span className={`px-3 py-1 rounded-full font-bold capitalize ${
                      record.status === 'hadir' ? 'bg-emerald-100 text-emerald-800' :
                      record.status === 'terlambat' ? 'bg-amber-100 text-amber-800' :
                      'bg-sky-100 text-sky-800'
                    }`}>
                      {record.status}
                    </span>

                    <TooltipNozzle content="Lihat atau kirim ulang rincian notifikasi pesan WhatsApp orang tua" position="left">
                      <button
                        onClick={() => {
                          setScanResultRecord(record);
                          setPreviewWAModalOpen(true);
                        }}
                        title="Lihat / Kirim Pesan WhatsApp Orang Tua"
                        className="p-2 rounded-xl bg-slate-100 hover:bg-emerald-50 text-emerald-700 transition-colors border border-slate-200"
                      >
                        <MessageSquare className="w-4 h-4" />
                      </button>
                    </TooltipNozzle>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: DIGITAL STUDENT ID CARD */}
      {activeTab === 'kartu' && (
        <div className="flex flex-col items-center space-y-4">
          <TooltipNozzle content="Kartu Pelajar Digital Resmi dengan NISN dan Barcode Murid" position="bottom">
            {/* Card Container */}
            <div className="w-full max-w-md bg-white border-2 border-sky-200 rounded-[36px] p-6 shadow-xl relative overflow-hidden text-[#1E293B]">
              <div className="flex items-center justify-between border-b border-sky-100 pb-3 mb-4">
                <div className="flex items-center space-x-2">
                  <div className="w-9 h-9 rounded-xl bg-white border border-sky-200 flex items-center justify-center p-1 shadow-sm overflow-hidden">
                    {settings.logoSekolah ? (
                      <img
                        src={settings.logoSekolah}
                        alt={settings.namaSekolah}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-contain"
                        onError={(e) => {
                          (e.currentTarget as HTMLElement).style.display = 'none';
                        }}
                      />
                    ) : (
                      <span className="text-[#0EA5E9] font-black text-xs">PK</span>
                    )}
                  </div>
                  <div>
                    <h4 className="font-black text-sm text-[#1E293B] leading-tight">{settings.namaSekolah}</h4>
                    <p className="text-[10px] text-[#0EA5E9] font-bold">KARTU TANDA PELAJAR DIGITAL</p>
                  </div>
                </div>
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-sky-100 text-[#0EA5E9] border border-sky-200">
                  TA {settings.tahunAjaran || '2026/2027'}
                </span>
              </div>

              <div className="flex items-center space-x-4 mb-4">
                <div className="w-20 h-24 rounded-2xl bg-slate-100 border-2 border-sky-300 overflow-hidden shrink-0 shadow-sm">
                  {currentSiswa.fotoUrl ? (
                    <img src={currentSiswa.fotoUrl} alt={currentSiswa.nama} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-[#0EA5E9]">
                      <User className="w-10 h-10" />
                    </div>
                  )}
                </div>

                <div className="space-y-1 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-bold">Nama Murid</span>
                    <p className="font-black text-sm text-[#1E293B]">{currentSiswa.nama}</p>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-bold">NISN / Kelas</span>
                    <p className="font-mono text-[#0EA5E9] font-bold">{currentSiswa.nisn} / Kelas {currentSiswa.kelas}</p>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-bold">Orang Tua / Wali</span>
                    <p className="text-slate-700 font-medium">{currentSiswa.namaOrangTua}</p>
                  </div>
                </div>
              </div>

              {/* Barcode representation */}
              <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl flex flex-col items-center">
                <div className="font-mono tracking-widest text-[10px] text-slate-600 mb-1.5 font-bold">
                  BARCODE IDENTITAS MURID RESMI
                </div>
                <div className="w-full h-12 flex items-stretch justify-center gap-0.5 bg-white p-1 rounded-lg border border-slate-200">
                  {Array.from({ length: 48 }).map((_, i) => (
                    <div
                      key={i}
                      className={`h-full ${
                        (i * 7 + currentSiswa.nisn.charCodeAt(i % currentSiswa.nisn.length)) % 3 === 0
                          ? 'w-1 bg-black'
                          : (i % 2 === 0 ? 'w-0.5 bg-black' : 'w-1.5 bg-white')
                      }`}
                    />
                  ))}
                </div>
                <p className="font-mono font-black text-xs text-[#1E293B] tracking-widest mt-1.5">
                  * {currentSiswa.nisn} *
                </p>
              </div>
            </div>
          </TooltipNozzle>

          <p className="text-xs text-slate-500 text-center max-w-sm font-medium">
            Kartu pelajar ini dapat digunakan untuk scan di gerbang sekolah bila menggunakan sistem pembaca kartu barcode fisik.
          </p>
        </div>
      )}

      {/* Real-time Camera Scanner Modal */}
      <CameraScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onScanSuccess={handleScanDynamicQR}
        title="Scan Barcode Presensi Murid"
        subtitle="Arahkan kamera ke layar barcode proyektor / monitor sekolah"
        settings={settings}
      />

      {/* WhatsApp Preview & Send Modal */}
      {previewWAModalOpen && scanResultRecord && currentSiswa && (
        <WhatsAppPreviewModal
          isOpen={previewWAModalOpen}
          onClose={() => setPreviewWAModalOpen(false)}
          record={scanResultRecord}
          siswa={currentSiswa}
          settings={settings}
        />
      )}
    </div>
  );
};
