import React from 'react';
import { AlertTriangle, Trash2, X, ShieldAlert } from 'lucide-react';

interface ConfirmDeleteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title?: string;
  itemName?: string;
  itemType?: string; // 'Siswa' | 'Guru' | 'Kelas' | 'Data Presensi' | 'Seluruh Database'
  description?: string;
  confirmButtonText?: string;
  cancelButtonText?: string;
  isDangerAll?: boolean;
}

export const ConfirmDeleteModal: React.FC<ConfirmDeleteModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  title = 'Konfirmasi Hapus Data',
  itemName,
  itemType = 'data',
  description,
  confirmButtonText = 'Ya, Hapus Data',
  cancelButtonText = 'Batalkan',
  isDangerAll = false,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white border-2 border-rose-200 w-full max-w-md rounded-[32px] overflow-hidden shadow-2xl flex flex-col text-[#1E293B] animate-in zoom-in-95 duration-150">
        
        {/* Header with Danger Accent */}
        <div className="p-6 pb-4 flex items-start space-x-4">
          <div className="w-12 h-12 rounded-2xl bg-rose-100 border border-rose-200 flex items-center justify-center text-[#F43F5E] shrink-0 shadow-inner">
            {isDangerAll ? <ShieldAlert className="w-6 h-6 stroke-[2.5]" /> : <Trash2 className="w-6 h-6 stroke-[2.5]" />}
          </div>

          <div className="flex-1 min-w-0">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-100 text-[#F43F5E] border border-rose-200">
              Tindakan Hapus {itemType}
            </span>
            <h3 className="text-lg font-black text-[#1E293B] mt-1 leading-snug">
              {title}
            </h3>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Box */}
        <div className="px-6 py-2 space-y-3 text-xs">
          {itemName && (
            <div className="p-3 bg-rose-50/70 border border-rose-200 rounded-2xl">
              <p className="text-[11px] font-bold text-rose-800 uppercase tracking-wide">
                Target Data yang Dihapus:
              </p>
              <p className="text-sm font-black text-rose-900 mt-0.5 font-mono break-all">
                {itemName}
              </p>
            </div>
          )}

          <div className="text-slate-600 space-y-1.5 font-medium leading-relaxed">
            <p>
              {description || (
                <>
                  Apakah Anda yakin bahwa Anda akan menghapus <strong>{itemType}</strong> ini? Data yang telah dihapus tidak dapat dipulihkan kembali.
                </>
              )}
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="p-6 pt-4 bg-slate-50 border-t border-slate-100 flex flex-col sm:flex-row gap-2.5">
          <button
            type="button"
            id="cancel-delete-confirm-btn"
            onClick={onClose}
            className="w-full sm:w-1/2 px-4 py-3 bg-white hover:bg-slate-100 text-slate-700 font-black rounded-2xl text-xs border border-slate-200 transition-all text-center"
          >
            {cancelButtonText}
          </button>

          <button
            type="button"
            id="confirm-delete-action-btn"
            onClick={() => {
              onConfirm();
              onClose();
            }}
            className="w-full sm:w-1/2 px-4 py-3 bg-[#F43F5E] hover:bg-rose-600 text-white font-black rounded-2xl text-xs flex items-center justify-center space-x-2 shadow-lg shadow-rose-200 transition-all active:scale-[0.98]"
          >
            <Trash2 className="w-4 h-4" />
            <span>{confirmButtonText}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
