import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Calendar, 
  Clock, 
  Send, 
  MessageSquare, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  Download, 
  Printer, 
  Filter, 
  Search, 
  Plus, 
  ShieldCheck, 
  Check, 
  X, 
  ChevronRight,
  Sparkles,
  Phone,
  Eye,
  Camera
} from 'lucide-react';
import { Guru, Siswa, PresensiRecord, PengaturanSekolah, UserAccount, StatusKehadiran } from '../types';
import { 
  getSiswaList, 
  getPresensiRecords, 
  updatePresensiStatus, 
  subscribeToDataChanges,
  getGuruList,
  getDaftarKelas,
  getWaliKelasMap
} from '../services/storage';
import { WhatsAppPreviewModal } from './WhatsAppPreviewModal';
import { TooltipNozzle } from './TooltipNozzle';

interface GuruPortalProps {
  currentUser: UserAccount;
  settings: PengaturanSekolah;
}

export const GuruPortal: React.FC<GuruPortalProps> = ({
  currentUser,
  settings,
}) => {
  const [daftarKelas, setDaftarKelas] = useState<string[]>([]);
  const [selectedKelas, setSelectedKelas] = useState<string>(
    currentUser.kelasAkses || '7A'
  );
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  });
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  const [allStudents, setAllStudents] = useState<Siswa[]>([]);
  const [allRecords, setAllRecords] = useState<PresensiRecord[]>([]);
  const [gurus, setGurus] = useState<Guru[]>([]);
  const [waliKelasMap, setWaliKelasMap] = useState<Record<string, string>>({});

  // Selected for WhatsApp preview
  const [activeWaStudent, setActiveWaStudent] = useState<{ student: Siswa; record: PresensiRecord } | null>(null);

  // Manual note modal
  const [noteModalStudent, setNoteModalStudent] = useState<Siswa | null>(null);
  const [noteStatus, setNoteStatus] = useState<StatusKehadiran>('izin');
  const [noteText, setNoteText] = useState<string>('');

  // Photo Zoom Modal
  const [photoZoom, setPhotoZoom] = useState<{ isOpen: boolean; photoUrl: string; title: string; subtitle: string }>({
    isOpen: false,
    photoUrl: '',
    title: '',
    subtitle: '',
  });

  const loadData = () => {
    const classes = getDaftarKelas();
    setDaftarKelas(classes);
    if (classes.length > 0 && !classes.includes(selectedKelas) && !currentUser.kelasAkses) {
      setSelectedKelas(classes[0]);
    }
    setAllStudents(getSiswaList());
    setAllRecords(getPresensiRecords());
    setGurus(getGuruList());
    setWaliKelasMap(getWaliKelasMap());
  };

  useEffect(() => {
    loadData();
    const unsub = subscribeToDataChanges(loadData);
    return () => unsub();
  }, []);

  // Filter students by assigned class
  const classStudents = allStudents.filter(s => s.kelas === selectedKelas);
  const filteredStudents = classStudents.filter(s => 
    s.nama.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.nisn.includes(searchQuery)
  );

  // Map attendance record for each student on the selected date
  const getRecordForStudent = (siswaId: string): PresensiRecord | undefined => {
    return allRecords.find(r => r.siswaId === siswaId && r.tanggal === selectedDate);
  };

  // Find Homeroom Teacher for current selected class (from map or guru list)
  const currentWaliName = waliKelasMap[selectedKelas] || gurus.find(g => g.waliKelas === selectedKelas)?.nama || currentUser.nama;

  // Stats for the selected class today
  const hadirCount = classStudents.filter(s => getRecordForStudent(s.id)?.status === 'hadir').length;
  const terlambatCount = classStudents.filter(s => getRecordForStudent(s.id)?.status === 'terlambat').length;
  const sakitCount = classStudents.filter(s => getRecordForStudent(s.id)?.status === 'sakit').length;
  const izinCount = classStudents.filter(s => getRecordForStudent(s.id)?.status === 'izin').length;
  const alpaCount = classStudents.filter(s => {
    const rec = getRecordForStudent(s.id);
    return rec?.status === 'alpa' || !rec;
  }).length;

  const handleQuickStatusChange = (siswa: Siswa, newStatus: StatusKehadiran) => {
    updatePresensiStatus(siswa.id, selectedDate, newStatus);
    loadData();
  };

  const handleSaveManualNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteModalStudent) return;
    updatePresensiStatus(noteModalStudent.id, selectedDate, noteStatus, noteText);
    setNoteModalStudent(null);
    setNoteText('');
    loadData();
  };

  const handleOpenWhatsAppForStudent = (siswa: Siswa) => {
    let rec = getRecordForStudent(siswa.id);
    if (!rec) {
      // Create draft record if not exists
      rec = updatePresensiStatus(siswa.id, selectedDate, 'alpa', 'Belum ada catatan kedatangan');
    }
    setActiveWaStudent({ student: siswa, record: rec });
  };

  const handlePrintRekap = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6">
      
      {/* Top Header Card */}
      <div className="bg-white border-2 border-blue-100 rounded-[32px] p-5 sm:p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <TooltipNozzle content="Portal Guru & Wali Kelas untuk mengelola kehadiran murid per rombel" position="bottom" badge="Guru">
            <div className="w-14 h-14 rounded-2xl bg-[#0EA5E9] flex items-center justify-center text-white font-bold shadow-lg shadow-sky-200 shrink-0">
              <Users className="w-7 h-7 stroke-[2.5]" />
            </div>
          </TooltipNozzle>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-xl sm:text-2xl font-black text-[#1E293B]">
                Presensi Kelas {selectedKelas}
              </h2>
              <span className="px-3 py-0.5 rounded-full text-xs font-black bg-sky-100 text-[#0EA5E9] border border-sky-300">
                Wali: {currentWaliName}
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Kelola kehadiran harian murid, verifikasi foto tangkapan scan, dan kirim laporan WhatsApp ke orang tua murid.
            </p>
          </div>
        </div>

        {/* Date & Class Selectors */}
        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          {/* Class Switcher */}
          <div className="flex items-center space-x-1 bg-slate-100 p-1.5 rounded-2xl border border-slate-200">
            {daftarKelas.map(k => (
              <TooltipNozzle key={k} content={`Beralih ke presensi murid Kelas ${k}`} position="top">
                <button
                  id={`guru-select-kelas-${k}`}
                  onClick={() => setSelectedKelas(k)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all ${
                    selectedKelas === k
                      ? 'bg-[#0EA5E9] text-white shadow-md shadow-sky-200 scale-[1.02]'
                      : 'text-slate-600 hover:text-[#0EA5E9] hover:bg-white'
                  }`}
                >
                  Kelas {k}
                </button>
              </TooltipNozzle>
            ))}
          </div>

          {/* Date Picker */}
          <TooltipNozzle content="Pilih tanggal presensi yang ingin dilihat atau diedit" position="top">
            <div className="flex items-center space-x-2 bg-slate-50 px-3.5 py-2 rounded-2xl border-2 border-slate-200 text-xs">
              <Calendar className="w-4 h-4 text-[#0EA5E9]" />
              <input
                type="date"
                id="guru-attendance-date-picker"
                value={selectedDate}
                onChange={e => setSelectedDate(e.target.value)}
                className="bg-transparent text-[#1E293B] font-bold text-xs focus:outline-none"
              />
            </div>
          </TooltipNozzle>

          <TooltipNozzle content="Cetak rekapitulasi absensi murid kelas hari ini" position="top">
            <button
              onClick={handlePrintRekap}
              className="p-2.5 rounded-2xl bg-white hover:bg-slate-50 text-slate-600 hover:text-[#0EA5E9] border-2 border-slate-200 transition-colors shadow-sm"
            >
              <Printer className="w-4 h-4" />
            </button>
          </TooltipNozzle>
        </div>
      </div>

      {/* Class Metric Highlights */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 sm:gap-4">
        <TooltipNozzle content={`Total murid yang terdaftar dalam rombel Kelas ${selectedKelas}`} position="top" className="w-full">
          <div className="bg-white border-2 border-sky-100 p-4 rounded-3xl shadow-sm w-full">
            <p className="text-xs text-slate-500 font-bold">Total Murid {selectedKelas}</p>
            <p className="text-2xl font-black text-[#1E293B] mt-1">{classStudents.length}</p>
            <span className="text-[11px] text-slate-400 font-medium">Terdaftar Aktif</span>
          </div>
        </TooltipNozzle>

        <TooltipNozzle content="Murid yang berhasil scan barcode sebelum jam masuk" position="top" className="w-full">
          <div className="bg-white border-2 border-emerald-100 p-4 rounded-3xl shadow-sm w-full">
            <p className="text-xs text-emerald-600 font-bold">Hadir Tepat Waktu</p>
            <p className="text-2xl font-black text-emerald-700 mt-1">{hadirCount}</p>
            <span className="text-[11px] text-slate-400 font-medium">≤ {settings.jamMasuk} WIB</span>
          </div>
        </TooltipNozzle>

        <TooltipNozzle content="Murid yang scan barcode setelah batas jam masuk" position="top" className="w-full">
          <div className="bg-white border-2 border-amber-100 p-4 rounded-3xl shadow-sm w-full">
            <p className="text-xs text-amber-600 font-bold">Terlambat</p>
            <p className="text-2xl font-black text-amber-700 mt-1">{terlambatCount}</p>
            <span className="text-[11px] text-slate-400 font-medium">&gt; {settings.jamMasuk} WIB</span>
          </div>
        </TooltipNozzle>

        <TooltipNozzle content="Murid yang memiliki surat keterangan sakit atau izin keluarga" position="top" className="w-full">
          <div className="bg-white border-2 border-blue-100 p-4 rounded-3xl shadow-sm w-full">
            <p className="text-xs text-[#0EA5E9] font-bold">Sakit & Izin</p>
            <p className="text-2xl font-black text-[#0EA5E9] mt-1">{sakitCount + izinCount}</p>
            <span className="text-[11px] text-slate-400 font-medium">{sakitCount} Sakit • {izinCount} Izin</span>
          </div>
        </TooltipNozzle>

        <TooltipNozzle content="Murid yang belum hadir atau tidak ada keterangan kabar hari ini" position="top" className="w-full col-span-2 sm:col-span-1">
          <div className="bg-white border-2 border-rose-100 p-4 rounded-3xl shadow-sm w-full">
            <p className="text-xs text-rose-600 font-bold">Alpa / Belum Hadir</p>
            <p className="text-2xl font-black text-rose-700 mt-1">{alpaCount}</p>
            <span className="text-[11px] text-slate-400 font-medium">Perlu Konfirmasi</span>
          </div>
        </TooltipNozzle>
      </div>

      {/* Main Student Attendance Table & Controls */}
      <div className="bg-white border-2 border-blue-100 rounded-[32px] p-5 sm:p-6 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <h3 className="text-base font-black text-[#1E293B]">
              Daftar Murid Kelas {selectedKelas} ({filteredStudents.length})
            </h3>
            <span className="text-xs text-slate-500 font-medium">
              • Tanggal: {selectedDate}
            </span>
          </div>

          <div className="flex items-center space-x-3 w-full sm:w-auto">
            {/* Search Input */}
            <div className="relative flex-1 sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari nama murid / NISN..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-xs text-[#1E293B] placeholder-slate-400 focus:outline-none focus:border-[#0EA5E9] font-medium"
              />
            </div>
          </div>
        </div>

        {/* Student Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider text-[11px]">
                <th className="py-3 px-3">No</th>
                <th className="py-3 px-3">Nama Murid / NISN</th>
                <th className="py-3 px-3">Waktu Datang</th>
                <th className="py-3 px-3">Bukti Foto Scan</th>
                <th className="py-3 px-3">Status Kehadiran</th>
                <th className="py-3 px-3">Orang Tua / No. WA</th>
                <th className="py-3 px-3 text-right">Aksi & Notifikasi WA</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400 font-medium">
                    Tidak ada data murid ditemukan untuk kelas {selectedKelas}.
                  </td>
                </tr>
              ) : (
                filteredStudents.map((siswa, index) => {
                  const record = getRecordForStudent(siswa.id);
                  const status = record?.status || 'alpa';

                  return (
                    <tr key={siswa.id} className="hover:bg-sky-50/50 transition-colors">
                      {/* Number */}
                      <td className="py-3.5 px-3 text-slate-400 font-mono font-bold">{index + 1}</td>

                      {/* Student Info */}
                      <td className="py-3.5 px-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-9 h-9 rounded-xl bg-slate-100 border border-slate-200 overflow-hidden shrink-0 flex items-center justify-center">
                            {siswa.fotoUrl ? (
                              <img src={siswa.fotoUrl} alt={siswa.nama} className="w-full h-full object-cover" />
                            ) : (
                              <span className="font-black text-[#0EA5E9] text-xs">{siswa.nama.charAt(0)}</span>
                            )}
                          </div>
                          <div>
                            <p className="font-bold text-[#1E293B] text-sm">{siswa.nama}</p>
                            <p className="text-[11px] text-slate-500 font-mono">NISN: {siswa.nisn}</p>
                          </div>
                        </div>
                      </td>

                      {/* Arrival Time */}
                      <td className="py-3.5 px-3">
                        {record ? (
                          <div className="flex items-center space-x-1.5 text-[#1E293B] font-mono">
                            <Clock className="w-3.5 h-3.5 text-emerald-600" />
                            <span className="font-black">{record.waktuKedatangan}</span>
                            {record.menitKeterlambatan > 0 && (
                              <span className="text-[10px] text-amber-600 font-sans font-bold">
                                (+{record.menitKeterlambatan}m)
                              </span>
                            )}
                          </div>
                        ) : (
                          <span className="text-slate-400 font-mono font-medium">--:--:--</span>
                        )}
                      </td>

                      {/* Photo Snapshot Proof */}
                      <td className="py-3.5 px-3">
                        {record?.fotoBuktiScan ? (
                          <TooltipNozzle content="Klik untuk melihat bukti foto tangkapan scan murid" position="top">
                            <button
                              onClick={() => setPhotoZoom({
                                isOpen: true,
                                photoUrl: record.fotoBuktiScan!,
                                title: `Foto Scan: ${siswa.nama}`,
                                subtitle: `${record.tanggal} • Pukul ${record.waktuKedatangan} WIB (${record.status.toUpperCase()})`
                              })}
                              className="group flex items-center space-x-1.5 p-1 bg-slate-100 hover:bg-sky-100 rounded-xl border border-slate-200 hover:border-sky-300 transition-all"
                            >
                              <img
                                src={record.fotoBuktiScan}
                                alt={`Wajah ${siswa.nama}`}
                                className="w-8 h-8 rounded-lg object-cover border border-white"
                              />
                              <Eye className="w-3.5 h-3.5 text-[#0EA5E9] group-hover:scale-110 transition-transform" />
                            </button>
                          </TooltipNozzle>
                        ) : (
                          <span className="text-slate-400 text-[11px] italic">-</span>
                        )}
                      </td>

                      {/* Status Toggle Buttons */}
                      <td className="py-3.5 px-3">
                        <div className="flex items-center space-x-1">
                          <TooltipNozzle content="Tandai Hadir Tepat Waktu (H)" position="top">
                            <button
                              id={`guru-set-hadir-${siswa.id}`}
                              onClick={() => handleQuickStatusChange(siswa, 'hadir')}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-black transition-all ${
                                status === 'hadir'
                                  ? 'bg-emerald-500 text-white shadow-sm scale-[1.05]'
                                  : 'bg-slate-100 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50'
                              }`}
                            >
                              H
                            </button>
                          </TooltipNozzle>

                          <TooltipNozzle content="Tandai Terlambat (T)" position="top">
                            <button
                              id={`guru-set-terlambat-${siswa.id}`}
                              onClick={() => handleQuickStatusChange(siswa, 'terlambat')}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-black transition-all ${
                                status === 'terlambat'
                                  ? 'bg-amber-500 text-white shadow-sm scale-[1.05]'
                                  : 'bg-slate-100 text-slate-500 hover:text-amber-600 hover:bg-amber-50'
                              }`}
                            >
                              T
                            </button>
                          </TooltipNozzle>

                          <TooltipNozzle content="Input Status Sakit & Surat Keterangan (S)" position="top">
                            <button
                              id={`guru-set-sakit-${siswa.id}`}
                              onClick={() => {
                                setNoteModalStudent(siswa);
                                setNoteStatus('sakit');
                                setNoteText(record?.catatan || 'Surat dokter / keterangan sakit dari orang tua');
                              }}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-black transition-all ${
                                status === 'sakit'
                                  ? 'bg-[#0EA5E9] text-white shadow-sm scale-[1.05]'
                                  : 'bg-slate-100 text-slate-500 hover:text-[#0EA5E9] hover:bg-sky-50'
                              }`}
                            >
                              S
                            </button>
                          </TooltipNozzle>

                          <TooltipNozzle content="Input Status Izin & Alasan (I)" position="top">
                            <button
                              id={`guru-set-izin-${siswa.id}`}
                              onClick={() => {
                                setNoteModalStudent(siswa);
                                setNoteStatus('izin');
                                setNoteText(record?.catatan || 'Izin acara keluarga / keperluan penting');
                              }}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-black transition-all ${
                                status === 'izin'
                                  ? 'bg-purple-500 text-white shadow-sm scale-[1.05]'
                                  : 'bg-slate-100 text-slate-500 hover:text-purple-600 hover:bg-purple-50'
                              }`}
                            >
                              I
                            </button>
                          </TooltipNozzle>

                          <TooltipNozzle content="Tandai Alpa / Tidak Hadir (A)" position="top">
                            <button
                              id={`guru-set-alpa-${siswa.id}`}
                              onClick={() => handleQuickStatusChange(siswa, 'alpa')}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-black transition-all ${
                                status === 'alpa'
                                  ? 'bg-[#F43F5E] text-white shadow-sm scale-[1.05]'
                                  : 'bg-slate-100 text-slate-500 hover:text-rose-600 hover:bg-rose-50'
                              }`}
                            >
                              A
                            </button>
                          </TooltipNozzle>
                        </div>
                        {record?.catatan && (
                          <p className="text-[10px] text-slate-500 italic mt-1 line-clamp-1 font-medium">
                            Ket: {record.catatan}
                          </p>
                        )}
                      </td>

                      {/* Parent / WhatsApp Contact */}
                      <td className="py-3.5 px-3">
                        <p className="text-[#1E293B] font-bold">{siswa.namaOrangTua}</p>
                        <p className="text-[11px] text-emerald-700 font-mono font-bold">+{siswa.noHpOrangTua}</p>
                      </td>

                      {/* Action & WhatsApp Trigger */}
                      <td className="py-3.5 px-3 text-right">
                        <TooltipNozzle content={`Kirim pesan WhatsApp resmi ke nomor orang tua ${siswa.nama}`} position="left">
                          <button
                            id={`guru-send-wa-${siswa.id}`}
                            onClick={() => handleOpenWhatsAppForStudent(siswa)}
                            className={`px-3.5 py-2 rounded-xl font-black text-xs inline-flex items-center space-x-1.5 transition-all ${
                              record?.waTerkirim
                                ? 'bg-emerald-50 text-emerald-800 border border-emerald-300 hover:bg-emerald-100'
                                : 'bg-[#10B981] hover:bg-emerald-600 text-white shadow-md shadow-emerald-200'
                            }`}
                          >
                            <Send className="w-3.5 h-3.5" />
                            <span>{record?.waTerkirim ? 'Kirim Ulang WA' : 'Kirim WA Ortu'}</span>
                          </button>
                        </TooltipNozzle>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Manual Note Modal (for Sakit / Izin) */}
      {noteModalStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white border-2 border-blue-100 w-full max-w-md rounded-[32px] p-6 shadow-2xl space-y-4 text-[#1E293B]">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-black text-[#1E293B]">
                Catatan Presensi: {noteModalStudent.nama}
              </h3>
              <button
                onClick={() => setNoteModalStudent(null)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveManualNote} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-600 font-bold mb-1.5">Status Kehadiran:</label>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setNoteStatus('sakit')}
                    className={`flex-1 py-2.5 rounded-2xl font-black transition-all ${
                      noteStatus === 'sakit' ? 'bg-[#0EA5E9] text-white shadow-md shadow-sky-200' : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    Sakit (S)
                  </button>
                  <button
                    type="button"
                    onClick={() => setNoteStatus('izin')}
                    className={`flex-1 py-2.5 rounded-2xl font-black transition-all ${
                      noteStatus === 'izin' ? 'bg-purple-600 text-white shadow-md shadow-purple-200' : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    Izin (I)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-bold mb-1.5">Keterangan / Alasan:</label>
                <textarea
                  value={noteText}
                  onChange={e => setNoteText(e.target.value)}
                  rows={3}
                  placeholder="Contoh: Demam berdarah / izin acara keluarga..."
                  className="w-full p-3 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] placeholder-slate-400 focus:outline-none focus:border-[#0EA5E9] text-xs font-medium"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setNoteModalStudent(null)}
                  className="px-4 py-2 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-2xl bg-[#0EA5E9] hover:bg-sky-600 text-white font-black shadow-md shadow-sky-200"
                >
                  Simpan Catatan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* WhatsApp Preview Modal */}
      {activeWaStudent && (
        <WhatsAppPreviewModal
          isOpen={!!activeWaStudent}
          onClose={() => setActiveWaStudent(null)}
          record={activeWaStudent.record}
          siswa={activeWaStudent.student}
          settings={settings}
        />
      )}

      {/* Photo Zoom Modal */}
      {photoZoom.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="bg-white border-2 border-blue-100 w-full max-w-md rounded-[32px] p-6 shadow-2xl space-y-4 text-[#1E293B]">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-black text-[#1E293B]">
                  {photoZoom.title}
                </h3>
                <p className="text-xs text-slate-500 font-medium">{photoZoom.subtitle}</p>
              </div>
              <button
                onClick={() => setPhotoZoom({ ...photoZoom, isOpen: false })}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="rounded-2xl overflow-hidden border-2 border-slate-200 bg-slate-950 aspect-video flex items-center justify-center">
              <img
                src={photoZoom.photoUrl}
                alt="Foto Bukti Scan Murid"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setPhotoZoom({ ...photoZoom, isOpen: false })}
                className="px-5 py-2.5 rounded-2xl bg-[#0EA5E9] hover:bg-sky-600 text-white font-black text-xs shadow-md shadow-sky-200"
              >
                Tutup Pratinjau
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
