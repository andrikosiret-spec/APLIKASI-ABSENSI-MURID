import React, { useState } from 'react';
import { 
  School, 
  Upload, 
  Image, 
  CheckCircle2, 
  Save, 
  RotateCcw, 
  Building2, 
  MapPin, 
  Phone, 
  Mail, 
  Globe, 
  Award, 
  UserCheck, 
  Sparkles,
  Link2,
  Trash2,
  FileCheck,
  Calendar,
  Layers
} from 'lucide-react';
import { PengaturanSekolah } from '../types';
import { saveSettings } from '../services/storage';
import { TooltipNozzle } from './TooltipNozzle';

interface ProfilSekolahTabProps {
  settings: PengaturanSekolah;
  onSettingsUpdated: (newSettings: PengaturanSekolah) => void;
}

export const ProfilSekolahTab: React.FC<ProfilSekolahTabProps> = ({
  settings,
  onSettingsUpdated,
}) => {
  const [formData, setFormData] = useState<PengaturanSekolah>({ ...settings });
  const [saveSuccessNotice, setSaveSuccessNotice] = useState<boolean>(false);
  const [logoInputType, setLogoInputType] = useState<'upload' | 'url'>('upload');
  const [fotoKepsekType, setFotoKepsekType] = useState<'upload' | 'url'>('upload');

  // Handle Logo file upload (Convert to Base64)
  const handleLogoFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert('Ukuran file logo terlalu besar. Harap pilih gambar di bawah 2MB.');
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setFormData(prev => ({ ...prev, logoSekolah: reader.result as string }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle Kepsek Photo file upload
  const handleKepsekFotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert('Ukuran foto terlalu besar. Harap pilih gambar di bawah 2MB.');
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setFormData(prev => ({ ...prev, fotoKepalaSekolah: reader.result as string }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Submit and save profile
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.namaSekolah.trim()) {
      alert('Nama Sekolah tidak boleh kosong.');
      return;
    }

    saveSettings(formData);
    onSettingsUpdated(formData);

    setSaveSuccessNotice(true);
    setTimeout(() => setSaveSuccessNotice(false), 4000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Info Banner */}
      <div className="bg-white border-2 border-sky-100 rounded-[32px] p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <TooltipNozzle content="Identitas resmi lembaga sekolah yang menjadi kop dokumen presensi" position="bottom">
            <div className="w-14 h-14 rounded-2xl bg-[#0EA5E9] flex items-center justify-center text-white shadow-lg shadow-sky-200 shrink-0">
              <School className="w-7 h-7 stroke-[2.5]" />
            </div>
          </TooltipNozzle>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-xl sm:text-2xl font-black text-[#1E293B]">
                Profil Lembaga Sekolah & Kepala Sekolah
              </h2>
              <span className="px-3 py-0.5 rounded-full text-xs font-black bg-emerald-100 text-emerald-700 border border-emerald-300">
                Data Master Resmi
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Ubah logo sekolah, nama sekolah, nomor identitas lembaga (NPSN/NSS), kontak resmi, hingga profil dan tanda tangan Kepala Sekolah secara manual.
            </p>
          </div>
        </div>

        {saveSuccessNotice && (
          <div className="flex items-center space-x-2 bg-emerald-50 text-emerald-700 border-2 border-emerald-300 px-4 py-2 rounded-2xl text-xs font-black animate-in fade-in slide-in-from-right duration-200">
            <CheckCircle2 className="w-4 h-4" />
            <span>Profil Sekolah Berhasil Disimpan!</span>
          </div>
        )}
      </div>

      {/* Main Profile Form */}
      <form onSubmit={handleSaveProfile} className="space-y-6">

        {/* SECTION 1: LOGO & IDENTITAS UTAMA SEKOLAH */}
        <div className="bg-white border-2 border-blue-100 rounded-[32px] p-6 sm:p-8 shadow-sm space-y-6">
          <div className="flex items-center space-x-2.5 border-b border-slate-100 pb-4">
            <Building2 className="w-5 h-5 text-[#0EA5E9]" />
            <h3 className="text-base font-black text-[#1E293B]">
              1. Logo & Identitas Utama Lembaga Sekolah
            </h3>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Logo Manager Box */}
            <div className="lg:col-span-4 bg-sky-50/70 border-2 border-sky-100 rounded-3xl p-5 text-center flex flex-col items-center justify-center space-y-3">
              <p className="text-xs font-black text-[#0EA5E9] uppercase tracking-wider">
                Logo Resmi Sekolah
              </p>

              {/* Logo Preview Box */}
              <div className="w-32 h-32 bg-white rounded-2xl border-2 border-sky-200 shadow-sm flex items-center justify-center p-2 relative overflow-hidden group">
                {formData.logoSekolah ? (
                  <img
                    src={formData.logoSekolah}
                    alt={formData.namaSekolah}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-contain"
                    onError={(e) => {
                      (e.currentTarget as HTMLElement).style.display = 'none';
                    }}
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center text-slate-400">
                    <School className="w-12 h-12 text-slate-300 mb-1" />
                    <span className="text-[10px] font-bold">Belum Ada Logo</span>
                  </div>
                )}
              </div>

              {/* Upload Type Switcher */}
              <div className="flex items-center bg-white p-1 rounded-xl border border-sky-200 text-[11px] font-bold w-full">
                <button
                  type="button"
                  onClick={() => setLogoInputType('upload')}
                  className={`flex-1 py-1 rounded-lg transition-all ${
                    logoInputType === 'upload' ? 'bg-[#0EA5E9] text-white shadow-xs' : 'text-slate-600 hover:text-[#0EA5E9]'
                  }`}
                >
                  Upload Gambar
                </button>
                <button
                  type="button"
                  onClick={() => setLogoInputType('url')}
                  className={`flex-1 py-1 rounded-lg transition-all ${
                    logoInputType === 'url' ? 'bg-[#0EA5E9] text-white shadow-xs' : 'text-slate-600 hover:text-[#0EA5E9]'
                  }`}
                >
                  Gunakan URL
                </button>
              </div>

              {logoInputType === 'upload' ? (
                <label className="w-full cursor-pointer py-2 px-3 bg-white hover:bg-sky-100/50 border-2 border-dashed border-[#0EA5E9] text-[#0EA5E9] font-bold rounded-2xl text-xs flex items-center justify-center space-x-2 transition-all">
                  <Upload className="w-4 h-4" />
                  <span>Pilih File Logo (PNG/JPG)</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleLogoFileUpload}
                    className="hidden"
                  />
                </label>
              ) : (
                <div className="w-full space-y-1">
                  <input
                    type="url"
                    placeholder="https://domain.sch.id/logo.png"
                    value={formData.logoSekolah || ''}
                    onChange={e => setFormData({ ...formData, logoSekolah: e.target.value })}
                    className="w-full px-3 py-1.5 bg-white border border-sky-200 rounded-xl text-xs font-mono text-[#1E293B] focus:outline-none focus:border-[#0EA5E9]"
                  />
                </div>
              )}

              {formData.logoSekolah && (
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, logoSekolah: '' })}
                  className="text-[11px] font-bold text-rose-600 hover:text-rose-700 flex items-center space-x-1"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Hapus Logo</span>
                </button>
              )}
            </div>

            {/* Main Form Fields */}
            <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="sm:col-span-2">
                <label className="block text-slate-700 font-bold mb-1">
                  Nama Lengkap Sekolah / Madrasah: *
                </label>
                <input
                  type="text"
                  required
                  value={formData.namaSekolah}
                  onChange={e => setFormData({ ...formData, namaSekolah: e.target.value })}
                  placeholder="Contoh: SMP Islam Al-Azhar 9"
                  className="w-full px-4 py-2.5 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-black text-sm focus:outline-none focus:border-[#0EA5E9]"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  Nama ini akan otomatis terpasang pada Navbar, Layar Monitor Gerbang, Kartu Murid, dan Pesan WhatsApp.
                </span>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  NPSN (Nomor Pokok Sekolah Nasional):
                </label>
                <input
                  type="text"
                  value={formData.npsn}
                  onChange={e => setFormData({ ...formData, npsn: e.target.value })}
                  placeholder="Contoh: 20108921"
                  className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-mono font-bold focus:outline-none focus:border-[#0EA5E9]"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  NSS / NDS (Nomor Statistik Sekolah):
                </label>
                <input
                  type="text"
                  value={formData.nss || ''}
                  onChange={e => setFormData({ ...formData, nss: e.target.value })}
                  placeholder="Contoh: 202026501009"
                  className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-mono font-bold focus:outline-none focus:border-[#0EA5E9]"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Bentuk Pendidikan / Jenjang:
                </label>
                <select
                  value={formData.bentukPendidikan || 'SMP'}
                  onChange={e => setFormData({ ...formData, bentukPendidikan: e.target.value })}
                  className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-bold focus:outline-none focus:border-[#0EA5E9]"
                >
                  <option value="SD">SD (Sekolah Dasar)</option>
                  <option value="MI">MI (Madrasah Ibtidaiyah)</option>
                  <option value="SMP">SMP (Sekolah Menengah Pertama)</option>
                  <option value="MTs">MTs (Madrasah Tsanawiyah)</option>
                  <option value="SMA">SMA (Sekolah Menengah Atas)</option>
                  <option value="MA">MA (Madrasah Aliyah)</option>
                  <option value="SMK">SMK (Sekolah Menengah Kejuruan)</option>
                  <option value="Pesantren">Pondok Pesantren / Islamic Boarding</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Status Sekolah:
                </label>
                <select
                  value={formData.statusSekolah || 'Swasta'}
                  onChange={e => setFormData({ ...formData, statusSekolah: e.target.value })}
                  className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-bold focus:outline-none focus:border-[#0EA5E9]"
                >
                  <option value="Swasta">Swasta (Yayasan)</option>
                  <option value="Negeri">Negeri (Pemerintah)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Akreditasi Sekolah:
                </label>
                <input
                  type="text"
                  value={formData.akreditasi || ''}
                  onChange={e => setFormData({ ...formData, akreditasi: e.target.value })}
                  placeholder="Contoh: A (Unggul)"
                  className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-bold focus:outline-none focus:border-[#0EA5E9]"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Tahun Ajaran & Semester Aktif:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={formData.tahunAjaran || '2026/2027'}
                    onChange={e => setFormData({ ...formData, tahunAjaran: e.target.value })}
                    placeholder="2026/2027"
                    className="w-full px-3 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-bold focus:outline-none focus:border-[#0EA5E9]"
                  />
                  <select
                    value={formData.semesterAktif || 'Ganjil'}
                    onChange={e => setFormData({ ...formData, semesterAktif: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-bold focus:outline-none focus:border-[#0EA5E9]"
                  >
                    <option value="Ganjil">Ganjil</option>
                    <option value="Genap">Genap</option>
                  </select>
                </div>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-700 font-bold mb-1">
                  Motto / Visi Singkat Sekolah:
                </label>
                <input
                  type="text"
                  value={formData.mottoVisi || ''}
                  onChange={e => setFormData({ ...formData, mottoVisi: e.target.value })}
                  placeholder="Contoh: Membentuk Generasi Qur’ani, Cerdas, Berakhlak Mulia, dan Berwawasan Global"
                  className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-medium focus:outline-none focus:border-[#0EA5E9]"
                />
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 2: ALAMAT & KONTAK SEKOLAH */}
        <div className="bg-white border-2 border-blue-100 rounded-[32px] p-6 sm:p-8 shadow-sm space-y-4">
          <div className="flex items-center space-x-2.5 border-b border-slate-100 pb-4">
            <MapPin className="w-5 h-5 text-[#0EA5E9]" />
            <h3 className="text-base font-black text-[#1E293B]">
              2. Alamat Lengkap & Kontak Resmi Sekolah
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            <div className="sm:col-span-2 lg:col-span-3">
              <label className="block text-slate-700 font-bold mb-1">
                Alamat Jalan / Gedung:
              </label>
              <input
                type="text"
                value={formData.alamatSekolah}
                onChange={e => setFormData({ ...formData, alamatSekolah: e.target.value })}
                placeholder="Contoh: Jl. Kemang Pratama Raya No. 9"
                className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-bold focus:outline-none focus:border-[#0EA5E9]"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">Kelurahan / Desa:</label>
              <input
                type="text"
                value={formData.kelurahan || ''}
                onChange={e => setFormData({ ...formData, kelurahan: e.target.value })}
                placeholder="Bojong Rawalumbu"
                className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] focus:outline-none focus:border-[#0EA5E9]"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">Kecamatan:</label>
              <input
                type="text"
                value={formData.kecamatan || ''}
                onChange={e => setFormData({ ...formData, kecamatan: e.target.value })}
                placeholder="Rawalumbu"
                className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] focus:outline-none focus:border-[#0EA5E9]"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">Kabupaten / Kota:</label>
              <input
                type="text"
                value={formData.kabupatenKota || ''}
                onChange={e => setFormData({ ...formData, kabupatenKota: e.target.value })}
                placeholder="Kota Bekasi"
                className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] focus:outline-none focus:border-[#0EA5E9]"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">Provinsi:</label>
              <input
                type="text"
                value={formData.provinsi || ''}
                onChange={e => setFormData({ ...formData, provinsi: e.target.value })}
                placeholder="Jawa Barat"
                className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] focus:outline-none focus:border-[#0EA5E9]"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">Kode Pos:</label>
              <input
                type="text"
                value={formData.kodePos || ''}
                onChange={e => setFormData({ ...formData, kodePos: e.target.value })}
                placeholder="17116"
                className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-mono focus:outline-none focus:border-[#0EA5E9]"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">No. Telepon Kantor:</label>
              <input
                type="text"
                value={formData.noTelepon || ''}
                onChange={e => setFormData({ ...formData, noTelepon: e.target.value })}
                placeholder="(021) 82412345"
                className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-mono focus:outline-none focus:border-[#0EA5E9]"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">Email Resmi Sekolah:</label>
              <input
                type="email"
                value={formData.emailSekolah || ''}
                onChange={e => setFormData({ ...formData, emailSekolah: e.target.value })}
                placeholder="info@smpia9.sch.id"
                className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] focus:outline-none focus:border-[#0EA5E9]"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">Website Resmi:</label>
              <input
                type="text"
                value={formData.website || ''}
                onChange={e => setFormData({ ...formData, website: e.target.value })}
                placeholder="https://smpia9.sch.id"
                className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] focus:outline-none focus:border-[#0EA5E9]"
              />
            </div>
          </div>
        </div>

        {/* SECTION 3: DATA KEPALA SEKOLAH */}
        <div className="bg-white border-2 border-blue-100 rounded-[32px] p-6 sm:p-8 shadow-sm space-y-6">
          <div className="flex items-center space-x-2.5 border-b border-slate-100 pb-4">
            <UserCheck className="w-5 h-5 text-[#0EA5E9]" />
            <h3 className="text-base font-black text-[#1E293B]">
              3. Profil & Data Kepala Sekolah
            </h3>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Foto Kepsek Box */}
            <div className="lg:col-span-4 bg-slate-50 border-2 border-slate-200 rounded-3xl p-5 text-center flex flex-col items-center justify-center space-y-3">
              <p className="text-xs font-black text-slate-700 uppercase tracking-wider">
                Foto Kepala Sekolah
              </p>

              <div className="w-28 h-36 bg-white rounded-2xl border-2 border-slate-300 shadow-sm overflow-hidden flex items-center justify-center">
                {formData.fotoKepalaSekolah ? (
                  <img
                    src={formData.fotoKepalaSekolah}
                    alt={formData.namaKepalaSekolah}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <UserCheck className="w-12 h-12 text-slate-300" />
                )}
              </div>

              <div className="flex items-center bg-white p-1 rounded-xl border border-slate-200 text-[11px] font-bold w-full">
                <button
                  type="button"
                  onClick={() => setFotoKepsekType('upload')}
                  className={`flex-1 py-1 rounded-lg transition-all ${
                    fotoKepsekType === 'upload' ? 'bg-[#0EA5E9] text-white shadow-xs' : 'text-slate-600 hover:text-[#0EA5E9]'
                  }`}
                >
                  Upload Foto
                </button>
                <button
                  type="button"
                  onClick={() => setFotoKepsekType('url')}
                  className={`flex-1 py-1 rounded-lg transition-all ${
                    fotoKepsekType === 'url' ? 'bg-[#0EA5E9] text-white shadow-xs' : 'text-slate-600 hover:text-[#0EA5E9]'
                  }`}
                >
                  Gunakan URL
                </button>
              </div>

              {fotoKepsekType === 'upload' ? (
                <label className="w-full cursor-pointer py-2 px-3 bg-white hover:bg-slate-100 border-2 border-dashed border-slate-400 text-slate-700 font-bold rounded-2xl text-xs flex items-center justify-center space-x-2 transition-all">
                  <Upload className="w-4 h-4 text-[#0EA5E9]" />
                  <span>Pilih Foto Pasfoto</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleKepsekFotoUpload}
                    className="hidden"
                  />
                </label>
              ) : (
                <input
                  type="url"
                  placeholder="https://.../foto-kepsek.jpg"
                  value={formData.fotoKepalaSekolah || ''}
                  onChange={e => setFormData({ ...formData, fotoKepalaSekolah: e.target.value })}
                  className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs text-[#1E293B] focus:outline-none focus:border-[#0EA5E9]"
                />
              )}
            </div>

            {/* Kepsek Form Fields */}
            <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="sm:col-span-2">
                <label className="block text-slate-700 font-bold mb-1">
                  Nama Lengkap Kepala Sekolah (Beserta Gelar): *
                </label>
                <input
                  type="text"
                  required
                  value={formData.namaKepalaSekolah}
                  onChange={e => setFormData({ ...formData, namaKepalaSekolah: e.target.value })}
                  placeholder="Contoh: Dr. H. Muhammad Arifin, M.Pd."
                  className="w-full px-3.5 py-2.5 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-black focus:outline-none focus:border-[#0EA5E9]"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  NIP / NUPTK Kepala Sekolah:
                </label>
                <input
                  type="text"
                  value={formData.nipKepalaSekolah}
                  onChange={e => setFormData({ ...formData, nipKepalaSekolah: e.target.value })}
                  placeholder="19750812 200003 1 004"
                  className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-mono font-bold focus:outline-none focus:border-[#0EA5E9]"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Pangkat / Golongan:
                </label>
                <input
                  type="text"
                  value={formData.pangkatGolongan || ''}
                  onChange={e => setFormData({ ...formData, pangkatGolongan: e.target.value })}
                  placeholder="Pembina Utama Muda / IV-c"
                  className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] focus:outline-none focus:border-[#0EA5E9]"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Nomor WhatsApp / HP Kepala Sekolah:
                </label>
                <input
                  type="text"
                  value={formData.noHpKepalaSekolah || ''}
                  onChange={e => setFormData({ ...formData, noHpKepalaSekolah: e.target.value })}
                  placeholder="081287654321"
                  className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] font-mono focus:outline-none focus:border-[#0EA5E9]"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Email Kepala Sekolah:
                </label>
                <input
                  type="email"
                  value={formData.emailKepalaSekolah || ''}
                  onChange={e => setFormData({ ...formData, emailKepalaSekolah: e.target.value })}
                  placeholder="kepsek.arifin@smpia9.sch.id"
                  className="w-full px-3.5 py-2 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] focus:outline-none focus:border-[#0EA5E9]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-700 font-bold mb-1">
                  Pesan / Sambutan Singkat Kepala Sekolah:
                </label>
                <textarea
                  rows={3}
                  value={formData.sambutanKepalaSekolah || ''}
                  onChange={e => setFormData({ ...formData, sambutanKepalaSekolah: e.target.value })}
                  placeholder="Tuliskan pesan motivasi atau pengantar sistem presensi untuk guru dan wali murid..."
                  className="w-full p-3 bg-slate-50 border-2 border-slate-200 rounded-2xl text-[#1E293B] text-xs focus:outline-none focus:border-[#0EA5E9]"
                />
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 4: PRATINJAU KOP SURAT RESMI */}
        <div className="bg-white border-2 border-sky-200 rounded-[32px] p-6 sm:p-8 shadow-md space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center space-x-2">
              <FileCheck className="w-5 h-5 text-[#0EA5E9]" />
              <h3 className="text-base font-black text-[#1E293B]">
                Pratinjau Kop Surat Resmi & Dokumen Laporan
              </h3>
            </div>
            <span className="text-[10px] font-black px-3 py-1 bg-sky-100 text-[#0EA5E9] rounded-full border border-sky-300">
              Live Preview
            </span>
          </div>

          <div className="bg-slate-50 border-2 border-slate-200 p-6 rounded-2xl shadow-inner">
            <div className="flex items-center justify-between pb-4 border-b-4 border-[#1E293B] gap-4">
              <div className="w-16 h-16 bg-white rounded-2xl border border-slate-200 p-1 flex items-center justify-center shrink-0">
                {formData.logoSekolah ? (
                  <img src={formData.logoSekolah} alt="Logo" className="w-full h-full object-contain" />
                ) : (
                  <School className="w-10 h-10 text-[#0EA5E9]" />
                )}
              </div>
              <div className="text-center flex-1">
                <h4 className="text-base sm:text-lg font-black text-[#1E293B] tracking-tight uppercase">
                  {formData.namaSekolah}
                </h4>
                <p className="text-[11px] font-bold text-slate-600">
                  {formData.bentukPendidikan || 'SMP'} • Status: {formData.statusSekolah || 'Swasta'} • Akreditasi: {formData.akreditasi || 'A (Unggul)'}
                </p>
                <p className="text-[10px] text-slate-500 font-medium">
                  {formData.alamatSekolah} {formData.kelurahan ? `, Kel. ${formData.kelurahan}` : ''} {formData.kecamatan ? `, Kec. ${formData.kecamatan}` : ''} {formData.kabupatenKota || ''} {formData.kodePos ? `Kode Pos ${formData.kodePos}` : ''}
                </p>
                <p className="text-[10px] text-[#0EA5E9] font-mono font-bold">
                  Telp: {formData.noTelepon || '-'} | Email: {formData.emailSekolah || '-'} | NPSN: {formData.npsn}
                </p>
              </div>
              <div className="w-16 h-16 hidden sm:flex items-center justify-center opacity-0">
                .
              </div>
            </div>

            <div className="pt-4 flex justify-between items-end text-[11px]">
              <div>
                <p className="text-slate-500 font-medium">Tahun Ajaran: <strong className="text-[#1E293B]">{formData.tahunAjaran || '2026/2027'} ({formData.semesterAktif || 'Ganjil'})</strong></p>
                <p className="text-slate-500 font-medium">Sistem: <strong className="text-[#0EA5E9]">Presensi Barcode QR Dinamis Real-Time</strong></p>
              </div>

              <div className="text-right">
                <p className="text-slate-500">Mengetahui,</p>
                <p className="font-bold text-[#1E293B]">Kepala Sekolah</p>
                <div className="h-10"></div>
                <p className="font-black text-[#1E293B] underline">{formData.namaKepalaSekolah}</p>
                <p className="text-[10px] text-slate-500 font-mono">NIP. {formData.nipKepalaSekolah}</p>
              </div>
            </div>
          </div>
        </div>

        {/* BOTTOM SAVE BAR */}
        <div className="bg-white border-2 border-blue-100 rounded-[28px] p-5 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4 sticky bottom-4 z-30">
          <div className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
            <Sparkles className="w-4 h-4 text-[#0EA5E9]" />
            <span>Perubahan logo dan nama sekolah akan langsung berlaku di seluruh sistem presensi murid.</span>
          </div>

          <TooltipNozzle content="Simpan perubahan identitas sekolah, logo, dan profil kepala sekolah" position="top">
            <button
              id="save-school-profile-btn"
              type="submit"
              className="w-full sm:w-auto px-8 py-3.5 bg-[#0EA5E9] hover:bg-sky-600 text-white font-black rounded-2xl text-xs flex items-center justify-center space-x-2 shadow-xl shadow-sky-200 transition-all scale-[1.02] active:scale-[0.98]"
            >
              <Save className="w-4 h-4" />
              <span>Simpan Seluruh Profil Sekolah</span>
            </button>
          </TooltipNozzle>
        </div>
      </form>
    </div>
  );
};
