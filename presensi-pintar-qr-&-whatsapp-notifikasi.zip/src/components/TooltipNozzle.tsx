import React, { useState } from 'react';

interface TooltipNozzleProps {
  content: string;
  children: React.ReactNode;
  position?: 'top' | 'bottom' | 'left' | 'right';
  className?: string;
  badge?: string;
}

export const TooltipNozzle: React.FC<TooltipNozzleProps> = ({
  content,
  children,
  position = 'top',
  className = '',
  badge,
}) => {
  const [isVisible, setIsVisible] = useState(false);

  const getPositionClasses = () => {
    switch (position) {
      case 'bottom':
        return 'top-full left-1/2 -translate-x-1/2 mt-2';
      case 'left':
        return 'right-full top-1/2 -translate-y-1/2 mr-2';
      case 'right':
        return 'left-full top-1/2 -translate-y-1/2 ml-2';
      case 'top':
      default:
        return 'bottom-full left-1/2 -translate-x-1/2 mb-2';
    }
  };

  const getNozzleArrowClasses = () => {
    switch (position) {
      case 'bottom':
        return 'bottom-full left-1/2 -translate-x-1/2 border-b-slate-900 border-x-transparent border-t-transparent border-[6px]';
      case 'left':
        return 'left-full top-1/2 -translate-y-1/2 border-l-slate-900 border-y-transparent border-r-transparent border-[6px]';
      case 'right':
        return 'right-full top-1/2 -translate-y-1/2 border-r-slate-900 border-y-transparent border-l-transparent border-[6px]';
      case 'top':
      default:
        return 'top-full left-1/2 -translate-x-1/2 border-t-slate-900 border-x-transparent border-b-transparent border-[6px]';
    }
  };

  return (
    <div
      className={`relative inline-flex items-center ${className}`}
      onMouseEnter={() => setIsVisible(true)}
      onMouseLeave={() => setIsVisible(false)}
      onFocus={() => setIsVisible(true)}
      onBlur={() => setIsVisible(false)}
    >
      {children}

      {isVisible && content && (
        <div
          role="tooltip"
          className={`absolute z-50 pointer-events-none transition-all duration-150 animate-in fade-in zoom-in-95 ${getPositionClasses()}`}
        >
          <div className="relative bg-slate-900/95 text-white text-[11px] font-semibold py-1.5 px-3 rounded-xl shadow-2xl border border-slate-700/80 max-w-xs whitespace-normal backdrop-blur-md">
            {badge && (
              <span className="inline-block px-1.5 py-0.2 rounded bg-[#0EA5E9] text-[9px] font-black uppercase tracking-wider text-white mr-1.5 mb-0.5">
                {badge}
              </span>
            )}
            <span className="leading-snug text-slate-100">{content}</span>
            {/* Triangular Nozzle Arrow */}
            <div className={`absolute w-0 h-0 ${getNozzleArrowClasses()}`} />
          </div>
        </div>
      )}
    </div>
  );
};
