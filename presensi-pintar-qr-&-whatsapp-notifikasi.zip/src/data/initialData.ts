import { Siswa, Guru, PengaturanSekolah, PresensiRecord, UserAccount } from '../types';

export const INITIAL_SETTINGS: PengaturanSekolah = {
  // Identitas Sekolah
  namaSekolah: 'SMP Islam Al-Azhar 9',
  npsn: '20108921',
  nss: '202026501009',
  bentukPendidikan: 'SMP',
  statusSekolah: 'Swasta',
  akreditasi: 'A (Unggul)',
  tahunAjaran: '2026/2027',
  semesterAktif: 'Ganjil',
  mottoVisi: 'Membentuk Generasi Qur’ani, Cerdas, Berakhlak Mulia, dan Berwawasan Global',

  // Logo & Media
  logoSekolah: 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=120&auto=format&fit=crop&q=80',

  // Lokasi & Kontak Sekolah
  alamatSekolah: 'Jl. Kemang Pratama Raya No. 9',
  kelurahan: 'Bojong Rawalumbu',
  kecamatan: 'Rawalumbu',
  kabupatenKota: 'Kota Bekasi',
  provinsi: 'Jawa Barat',
  kodePos: '17116',
  noTelepon: '(021) 82412345',
  emailSekolah: 'info@smpia9.sch.id',
  website: 'https://smpia9.sch.id',

  // Data Kepala Sekolah
  namaKepalaSekolah: 'Dr. H. Muhammad Arifin, M.Pd.',
  gelarKepalaSekolah: 'Dr., M.Pd.',
  nipKepalaSekolah: '19750812 200003 1 004',
  pangkatGolongan: 'Pembina Utama Muda / IV-c',
  noHpKepalaSekolah: '081287654321',
  emailKepalaSekolah: 'kepsek.arifin@smpia9.sch.id',
  fotoKepalaSekolah: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&auto=format&fit=crop&q=80',
  sambutanKepalaSekolah: 'Selamat datang di Sistem Presensi Digital Sekolah. Kami berkomitmen mewujudkan transparansi, kedisiplinan, dan komunikasi real-time terpercaya bersama orang tua murid.',

  // Operasional Presensi & Jam
  jamMasuk: '07:15',
  toleransiTerlambatMenit: 15, // > 07:15 is considered late; tolerance window for arrival
  jamPulang: '15:00',
  secretTokenSalt: 'SMPIA9_SECURE_SALT_2026_ANTI_CHEAT',
  durasiQrDetik: 20,
  waGatewayMode: 'direct_web',
  templatePesanWA: `🔔 *NOTIFIKASI PRESENSI KEHADIRAN*
*{SEKOLAH}*

Assalamu’alaikum Wr. Wb.
Yth. Bapak/Ibu *{NAMA_ORTU}*
Wali Murid dari ananda:

👤 *Nama:* {NAMA}
🔢 *NISN:* {NISN}
🏫 *Kelas:* {KELAS}

📌 *Status Kehadiran:* {STATUS}
🕒 *Waktu Datang:* {WAKTU} WIB
📅 *Hari, Tanggal:* {TANGGAL}

Alhamdulillah, ananda telah tiba di sekolah dan melakukan scan barcode presensi dengan aman dan tertib.

Wassalamu’alaikum Wr. Wb.
_— Sistem Presensi Digital {SEKOLAH}_`,
  templatePesanTerlambatWA: `⚠️ *PEMBERITAHUAN KETERLAMBATAN SISWA*
*{SEKOLAH}*

Assalamu’alaikum Wr. Wb.
Yth. Bapak/Ibu *{NAMA_ORTU}*
Wali Murid dari ananda:

👤 *Nama:* {NAMA}
🔢 *NISN:* {NISN}
🏫 *Kelas:* {KELAS}

📌 *Status Kehadiran:* {STATUS}
🕒 *Waktu Datang:* {WAKTU} WIB (Batas Masuk: {JAM_MASUK} WIB)
⏱️ *Keterlambatan:* {MENIT_TERLAMBAT} Menit
📅 *Hari, Tanggal:* {TANGGAL}

Mohon perhatian Bapak/Ibu agar dapat membantu mengingatkan ananda untuk berangkat lebih awal agar tidak terlambat mengikuti kegiatan pembiasaan pagi dan literasi.

Wassalamu’alaikum Wr. Wb.
_— Tim Kesiswaan & Wali Kelas {SEKOLAH}_`,
  templatePesanIzinSakitWA: `📋 *INFORMASI KETIDAKHADIRAN SISWA*
*{SEKOLAH}*

Assalamu’alaikum Wr. Wb.
Yth. Bapak/Ibu *{NAMA_ORTU}*
Wali Murid dari ananda:

👤 *Nama:* {NAMA}
🔢 *NISN:* {NISN}
🏫 *Kelas:* {KELAS}

📌 *Keterangan:* {STATUS}
📅 *Tanggal:* {TANGGAL}
📝 *Catatan:* {CATATAN}

Data ketidakhadiran ananda telah tercatat secara resmi di buku presensi digital wali kelas. Semoga lekas sembuh dan urusan dipermudah.

Wassalamu’alaikum Wr. Wb.
_— Tata Usaha & Wali Kelas {SEKOLAH}_`,
};

export const INITIAL_GURU: Guru[] = [
  {
    id: 'G01',
    nip: '19820415 200801 1 009',
    nama: 'Drs. H. Rudi Hartono, M.Pd.',
    email: 'rudi.hartono@smpia9.sch.id',
    noHp: '081288334455',
    waliKelas: '7A',
    mataPelajaran: 'Matematika',
    fotoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'G02',
    nip: '19870923 201102 2 015',
    nama: 'Siti Rahmawati, S.Pd.',
    email: 'siti.rahmawati@smpia9.sch.id',
    noHp: '081399445566',
    waliKelas: '7B',
    mataPelajaran: 'Bahasa Indonesia',
    fotoUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'G03',
    nip: '19850110 200901 1 012',
    nama: 'Ahmad Fauzi, S.Kom., M.T.',
    email: 'ahmad.fauzi@smpia9.sch.id',
    noHp: '081511223344',
    waliKelas: '8A',
    mataPelajaran: 'Informatika & Robotik',
    fotoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'G04',
    nip: '19901105 201503 2 008',
    nama: 'Nurul Hidayah, M.Pd.',
    email: 'nurul.hidayah@smpia9.sch.id',
    noHp: '081822334455',
    waliKelas: '8B',
    mataPelajaran: 'Bahasa Inggris',
    fotoUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'G05',
    nip: '19790618 200501 1 007',
    nama: 'Bambang Sudarsono, S.Pd.',
    email: 'bambang.sudarsono@smpia9.sch.id',
    noHp: '081933445566',
    waliKelas: '9A',
    mataPelajaran: 'Ilmu Pengetahuan Alam (IPA)',
    fotoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
  },
];

export const INITIAL_SISWA: Siswa[] = [
  // KELAS 7A
  {
    id: 'S01',
    nisn: '0098451201',
    nama: 'Muhammad Rayhan Pratama',
    kelas: '7A',
    jenisKelamin: 'L',
    namaOrangTua: 'Bpk. Hendra Pratama',
    noHpOrangTua: '081289001122',
    alamat: 'Jl. Kemang Melati No. 12',
    pin: '1234',
    terdaftarPada: '2026-07-15',
    fotoUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'S02',
    nisn: '0098451202',
    nama: 'Aisyah Zahira Putri',
    kelas: '7A',
    jenisKelamin: 'P',
    namaOrangTua: 'Ibu Ratna Dewi',
    noHpOrangTua: '081399887766',
    alamat: 'Jl. Raya Pekayon Blok B No. 4',
    pin: '1234',
    terdaftarPada: '2026-07-15',
    fotoUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'S03',
    nisn: '0098451203',
    nama: 'Fathir Alvaro Danendra',
    kelas: '7A',
    jenisKelamin: 'L',
    namaOrangTua: 'Bpk. Danang Danendra',
    noHpOrangTua: '081577665544',
    alamat: 'Perum Grand Kemang A3/15',
    pin: '1234',
    terdaftarPada: '2026-07-15',
    fotoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'S04',
    nisn: '0098451204',
    nama: 'Nabila Syakira Anwar',
    kelas: '7A',
    jenisKelamin: 'P',
    namaOrangTua: 'Ibu Maya Anwar',
    noHpOrangTua: '081822446688',
    alamat: 'Jl. KH Noer Ali Kav. 88',
    pin: '1234',
    terdaftarPada: '2026-07-15',
    fotoUrl: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'S05',
    nisn: '0098451205',
    nama: 'Rizky Alfarizi Ramadhan',
    kelas: '7A',
    jenisKelamin: 'L',
    namaOrangTua: 'Bpk. H. Syamsul Ramadhan',
    noHpOrangTua: '081911335577',
    alamat: 'Jl. Ahmad Yani No. 50',
    pin: '1234',
    terdaftarPada: '2026-07-15',
    fotoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'S06',
    nisn: '0098451206',
    nama: 'Zalfa Kayla Salsabila',
    kelas: '7A',
    jenisKelamin: 'P',
    namaOrangTua: 'Ibu Eni Salsabila',
    noHpOrangTua: '081277334411',
    alamat: 'Taman Galaxy Indah Blok C2',
    pin: '1234',
    terdaftarPada: '2026-07-15',
    fotoUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
  },

  // KELAS 7B
  {
    id: 'S07',
    nisn: '0098451207',
    nama: 'Dimas Arya Wiratama',
    kelas: '7B',
    jenisKelamin: 'L',
    namaOrangTua: 'Bpk. Wiratama Kusuma',
    noHpOrangTua: '081299112233',
    alamat: 'Jl. Caman Raya No. 7A',
    pin: '1234',
    terdaftarPada: '2026-07-15',
    fotoUrl: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'S08',
    nisn: '0098451208',
    nama: 'Keisha Amanda Lovina',
    kelas: '7B',
    jenisKelamin: 'P',
    namaOrangTua: 'Ibu Lovina Sari',
    noHpOrangTua: '081377889900',
    alamat: 'Kemang Pratama 3 Blok H',
    pin: '1234',
    terdaftarPada: '2026-07-15',
    fotoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'S09',
    nisn: '0098451209',
    nama: 'Gibran Atharizz Anshori',
    kelas: '7B',
    jenisKelamin: 'L',
    namaOrangTua: 'Bpk. Lukman Anshori',
    noHpOrangTua: '081544332211',
    alamat: 'Jl. Rawa Semut No. 19',
    pin: '1234',
    terdaftarPada: '2026-07-15',
    fotoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'S10',
    nisn: '0098451210',
    nama: 'Salwa Nadira Maharani',
    kelas: '7B',
    jenisKelamin: 'P',
    namaOrangTua: 'Ibu Ratih Maharani',
    noHpOrangTua: '081855667788',
    alamat: 'Villa Galaxy No. 22',
    pin: '1234',
    terdaftarPada: '2026-07-15',
    fotoUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
  },

  // KELAS 8A
  {
    id: 'S11',
    nisn: '0087342101',
    nama: 'Aditya Bagus Nugroho',
    kelas: '8A',
    jenisKelamin: 'L',
    namaOrangTua: 'Bpk. Ir. Joko Nugroho',
    noHpOrangTua: '081233445566',
    alamat: 'Jl. Pahlawan Perjuangan No. 3',
    pin: '1234',
    terdaftarPada: '2025-07-15',
    fotoUrl: 'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'S12',
    nisn: '0087342102',
    nama: 'Chelsea Olivia Clarissa',
    kelas: '8A',
    jenisKelamin: 'P',
    namaOrangTua: 'Ibu Clarissa Wijaya',
    noHpOrangTua: '081388776655',
    alamat: 'Boulevard Regency No. 8',
    pin: '1234',
    terdaftarPada: '2025-07-15',
    fotoUrl: 'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'S13',
    nisn: '0087342103',
    nama: 'Farhan Dwi Cahyono',
    kelas: '8A',
    jenisKelamin: 'L',
    namaOrangTua: 'Bpk. Cahyo Wibowo',
    noHpOrangTua: '081566778899',
    alamat: 'Jl. Narogong Sakti No. 44',
    pin: '1234',
    terdaftarPada: '2025-07-15',
    fotoUrl: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&auto=format&fit=crop&q=80',
  },

  // KELAS 8B
  {
    id: 'S14',
    nisn: '0087342104',
    nama: 'Irfan Maulana Malik',
    kelas: '8B',
    jenisKelamin: 'L',
    namaOrangTua: 'Bpk. Malik Ibrahim',
    noHpOrangTua: '081299334455',
    alamat: 'Perum Mustika Jaya No. 10',
    pin: '1234',
    terdaftarPada: '2025-07-15',
    fotoUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'S15',
    nisn: '0087342105',
    nama: 'Naura Putri Kencana',
    kelas: '8B',
    jenisKelamin: 'P',
    namaOrangTua: 'Ibu Kencana Ayu',
    noHpOrangTua: '081322446688',
    alamat: 'Jl. Kemang Pratama 1 No. 5',
    pin: '1234',
    terdaftarPada: '2025-07-15',
    fotoUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
  },

  // KELAS 9A
  {
    id: 'S16',
    nisn: '0076231001',
    nama: 'Zaky Abhinaya Kusuma',
    kelas: '9A',
    jenisKelamin: 'L',
    namaOrangTua: 'Bpk. Kusuma Wardhana',
    noHpOrangTua: '081211223344',
    alamat: 'Jl. Cut Meutia No. 18',
    pin: '1234',
    terdaftarPada: '2024-07-15',
    fotoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'S17',
    nisn: '0076231002',
    nama: 'Tiara Aurelia Syafira',
    kelas: '9A',
    jenisKelamin: 'P',
    namaOrangTua: 'Ibu Syafira Dewi',
    noHpOrangTua: '081355667788',
    alamat: 'Jl. Pengasinan Raya No. 9',
    pin: '1234',
    terdaftarPada: '2024-07-15',
    fotoUrl: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150&auto=format&fit=crop&q=80',
  },
];

export const INITIAL_PRESENSI: PresensiRecord[] = [
  {
    id: 'PR-20260814-S01',
    siswaId: 'S01',
    nisn: '0098451201',
    namaSiswa: 'Muhammad Rayhan Pratama',
    kelas: '7A',
    tanggal: '2026-08-14',
    waktuKedatangan: '06:48:22',
    timestamp: 1786697302000,
    status: 'hadir',
    menitKeterlambatan: 0,
    metode: 'scan_qr_dinamis',
    waTerkirim: true,
    waTerkirimPada: '2026-08-14 06:48:25',
    waPenerima: '081289001122 (Bpk. Hendra Pratama)',
    waPesan: 'Notifikasi kehadiran tepat waktu telah dikirimkan via WhatsApp.',
  },
  {
    id: 'PR-20260814-S02',
    siswaId: 'S02',
    nisn: '0098451202',
    namaSiswa: 'Aisyah Zahira Putri',
    kelas: '7A',
    tanggal: '2026-08-14',
    waktuKedatangan: '06:55:10',
    timestamp: 1786697710000,
    status: 'hadir',
    menitKeterlambatan: 0,
    metode: 'scan_qr_dinamis',
    waTerkirim: true,
    waTerkirimPada: '2026-08-14 06:55:14',
    waPenerima: '081399887766 (Ibu Ratna Dewi)',
    waPesan: 'Notifikasi kehadiran tepat waktu telah dikirimkan via WhatsApp.',
  },
  {
    id: 'PR-20260814-S07',
    siswaId: 'S07',
    nisn: '0098451207',
    namaSiswa: 'Dimas Arya Wiratama',
    kelas: '7B',
    tanggal: '2026-08-14',
    waktuKedatangan: '07:22:45',
    timestamp: 1786699365000,
    status: 'terlambat',
    menitKeterlambatan: 7,
    metode: 'scan_qr_dinamis',
    catatan: 'Terlambat karena kendala lalu lintas',
    waTerkirim: true,
    waTerkirimPada: '2026-08-14 07:22:48',
    waPenerima: '081299112233 (Bpk. Wiratama Kusuma)',
    waPesan: 'Pemberitahuan keterlambatan 7 menit telah dikirimkan ke orang tua.',
  },
  {
    id: 'PR-20260814-S11',
    siswaId: 'S11',
    nisn: '0087342101',
    namaSiswa: 'Aditya Bagus Nugroho',
    kelas: '8A',
    tanggal: '2026-08-14',
    waktuKedatangan: '07:05:30',
    timestamp: 1786698330000,
    status: 'hadir',
    menitKeterlambatan: 0,
    metode: 'scan_kartu_siswa',
    waTerkirim: true,
    waTerkirimPada: '2026-08-14 07:05:35',
    waPenerima: '081233445566 (Bpk. Ir. Joko Nugroho)',
  },
  {
    id: 'PR-20260814-S16',
    siswaId: 'S16',
    nisn: '0076231001',
    namaSiswa: 'Zaky Abhinaya Kusuma',
    kelas: '9A',
    tanggal: '2026-08-14',
    waktuKedatangan: '06:50:11',
    timestamp: 1786697411000,
    status: 'hadir',
    menitKeterlambatan: 0,
    metode: 'scan_qr_dinamis',
    waTerkirim: true,
    waTerkirimPada: '2026-08-14 06:50:15',
    waPenerima: '081211223344 (Bpk. Kusuma Wardhana)',
  },
];

export const INITIAL_USERS: UserAccount[] = [
  {
    id: 'U-ADMIN',
    username: 'admin',
    nama: 'Administrator Presensi & Kesiswaan',
    role: 'admin',
  },
  {
    id: 'U-GURU-7A',
    username: 'guru.rudi',
    nama: 'Drs. H. Rudi Hartono, M.Pd. (Wali 7A)',
    role: 'guru',
    guruId: 'G01',
    kelasAkses: '7A',
  },
  {
    id: 'U-GURU-7B',
    username: 'guru.siti',
    nama: 'Siti Rahmawati, S.Pd. (Wali 7B)',
    role: 'guru',
    guruId: 'G02',
    kelasAkses: '7B',
  },
  {
    id: 'U-GURU-8A',
    username: 'guru.fauzi',
    nama: 'Ahmad Fauzi, S.Kom. (Wali 8A)',
    role: 'guru',
    guruId: 'G03',
    kelasAkses: '8A',
  },
  {
    id: 'U-GURU-9A',
    username: 'guru.bambang',
    nama: 'Bambang Sudarsono, S.Pd. (Wali 9A)',
    role: 'guru',
    guruId: 'G05',
    kelasAkses: '9A',
  },
  {
    id: 'U-SISWA-RAYHAN',
    username: '0098451201',
    nama: 'Muhammad Rayhan Pratama (7A)',
    role: 'siswa',
    siswaId: 'S01',
    kelasAkses: '7A',
  },
  {
    id: 'U-SISWA-AISYAH',
    username: '0098451202',
    nama: 'Aisyah Zahira Putri (7A)',
    role: 'siswa',
    siswaId: 'S02',
    kelasAkses: '7A',
  },
  {
    id: 'U-KIOSK',
    username: 'kiosk.gerbang',
    nama: 'Layar Monitor Proyektor Gerbang Sekolah',
    role: 'kiosk',
  },
];

export const DAFTAR_KELAS = ['7A', '7B', '8A', '8B', '9A'];
