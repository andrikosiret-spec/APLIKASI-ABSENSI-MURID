export type UserRole = 'admin' | 'guru' | 'siswa' | 'kiosk';

export type StatusKehadiran = 'hadir' | 'terlambat' | 'sakit' | 'izin' | 'alpa';

export type MetodePresensi = 'scan_qr_dinamis' | 'scan_qr_dan_wajah' | 'scan_kartu_siswa' | 'manual_guru' | 'manual_admin';

export interface Siswa {
  id: string;
  nisn: string;
  nama: string;
  kelas: string;
  jenisKelamin: 'L' | 'P';
  namaOrangTua: string;
  noHpOrangTua: string; // Format e.g., "081234567890" or "6281234567890"
  alamat?: string;
  fotoUrl?: string;
  pin?: string; // 4-digit PIN for student self-service verification
  terdaftarPada: string;
}

export interface Guru {
  id: string;
  nip: string;
  nama: string;
  email: string;
  noHp: string;
  waliKelas?: string; // e.g. "7A", "7B", or empty if non-homeroom
  mataPelajaran?: string;
  fotoUrl?: string;
}

export interface PresensiRecord {
  id: string;
  siswaId: string;
  nisn: string;
  namaSiswa: string;
  kelas: string;
  tanggal: string; // YYYY-MM-DD
  waktuKedatangan: string; // HH:mm:ss
  timestamp: number; // exact epoch ms
  status: StatusKehadiran;
  menitKeterlambatan: number; // 0 if on time
  metode: MetodePresensi;
  catatan?: string;
  fotoBuktiScan?: string; // Captured photo snapshot taken at scan time (Base64)
  waTerkirim: boolean;
  waTerkirimPada?: string;
  waPenerima?: string;
  waPesan?: string;
  verifikasiToken?: string;
}

export interface PengaturanSekolah {
  // Identitas Sekolah
  namaSekolah: string;
  npsn: string;
  nss?: string;
  bentukPendidikan?: string; // SMP, MTs, SMA, SMK, SD, dll
  statusSekolah?: string; // Negeri / Swasta
  akreditasi?: string; // A (Unggul), B, C, dll
  tahunAjaran?: string; // misal "2026/2027"
  semesterAktif?: string; // "Ganjil" | "Genap"
  mottoVisi?: string; // Visi atau Motto Sekolah
  
  // Daftar Kelas Tersedia (Bisa ditambah / dikurangi manual)
  daftarKelas?: string[];

  // Logo & Media
  logoSekolah?: string; // URL or Base64 data URL
  
  // Lokasi & Kontak Sekolah
  alamatSekolah: string;
  kelurahan?: string;
  kecamatan?: string;
  kabupatenKota?: string;
  provinsi?: string;
  kodePos?: string;
  noTelepon?: string;
  emailSekolah?: string;
  website?: string;
  
  // Data Kepala Sekolah
  namaKepalaSekolah: string;
  gelarKepalaSekolah?: string;
  nipKepalaSekolah: string;
  pangkatGolongan?: string;
  noHpKepalaSekolah?: string;
  emailKepalaSekolah?: string;
  fotoKepalaSekolah?: string;
  sambutanKepalaSekolah?: string;

  // Pengaturan Operasional & Presensi
  jamMasuk: string; // e.g. "07:15"
  toleransiTerlambatMenit: number; // e.g. 15 minutes -> until 07:30
  jamPulang: string; // e.g. "15:00"
  templatePesanWA: string;
  templatePesanTerlambatWA: string;
  templatePesanIzinSakitWA: string;
  secretTokenSalt: string;
  durasiQrDetik: number; // e.g. 20 seconds before rotating
  waGatewayMode: 'direct_web' | 'simulated_api' | 'fonnte_api';
  fonnteApiKey?: string;
  autoKirimWA?: boolean; // Kirim notifikasi WA ke ortu secara otomatis saat scan
  wajibFotoWajahScan?: boolean; // Tangkap foto snapshot wajah saat scan
}

export interface UserAccount {
  id: string;
  username: string;
  nama: string;
  role: UserRole;
  guruId?: string;
  siswaId?: string;
  kelasAkses?: string; // specific class for teacher
}

export interface DynamicQRToken {
  token: string;
  timestamp: number;
  expiresAt: number;
  nonce: string;
  schoolId: string;
}
