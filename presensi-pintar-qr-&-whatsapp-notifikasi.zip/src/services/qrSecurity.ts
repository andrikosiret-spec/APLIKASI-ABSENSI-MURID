import QRCode from 'qrcode';
import { DynamicQRToken } from '../types';

/**
 * Dynamic QR Code Service for Anti-Cheat Student Attendance
 * Tokens refresh every few seconds to prevent link-sharing or screenshot reuse.
 */

// Simple robust hash function for client-side cryptographic salt simulation
function hashString(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0; // Convert to 32bit integer
  }
  return Math.abs(hash).toString(36);
}

export function generateDynamicToken(salt: string, validitySeconds: number = 25): DynamicQRToken {
  const now = Date.now();
  const expiresAt = now + validitySeconds * 1000;
  const nonce = Math.random().toString(36).substring(2, 8);
  const signature = hashString(`${now}_${expiresAt}_${nonce}_${salt}`);
  
  // Format: "SCHPRESENSI_V1:{now}:{expiresAt}:{nonce}:{sig}"
  const payload = `SCHPRESENSI_V1:${now}:${expiresAt}:${nonce}:${signature}`;
  const token = btoa(payload);

  return {
    token,
    timestamp: now,
    expiresAt,
    nonce,
    schoolId: 'SMP-ISLAM-ALAZHAR-09',
  };
}

export interface TokenValidationResult {
  isValid: boolean;
  message: string;
  generatedAt?: Date;
  expiresAt?: Date;
  ageSeconds?: number;
}

export function validateDynamicToken(
  tokenStr: string,
  salt: string,
  gracePeriodSeconds: number = 45
): TokenValidationResult {
  try {
    let payload = '';
    // Handle both direct payload string and base64 encoded token
    if (tokenStr.startsWith('SCHPRESENSI_V1:')) {
      payload = tokenStr;
    } else {
      try {
        payload = atob(tokenStr.trim());
      } catch {
        payload = tokenStr;
      }
    }

    if (!payload.startsWith('SCHPRESENSI_V1:')) {
      return {
        isValid: false,
        message: 'Format QR Code tidak valid atau bukan QR resmi presensi sekolah.',
      };
    }

    const parts = payload.split(':');
    if (parts.length < 5) {
      return {
        isValid: false,
        message: 'Struktur kode QR rusak atau tidak lengkap.',
      };
    }

    const [, nowStr, expiresAtStr, nonce, sig] = parts;
    const generatedTimestamp = parseInt(nowStr, 10);
    const expiresAtTimestamp = parseInt(expiresAtStr, 10);
    const expectedSig = hashString(`${nowStr}_${expiresAtStr}_${nonce}_${salt}`);

    if (sig !== expectedSig) {
      return {
        isValid: false,
        message: 'Tanda tangan digital QR Code tidak cocok (kemungkinan palsu).',
      };
    }

    const now = Date.now();
    // Allow small grace period for network or camera scanning delays
    const maxExpiry = expiresAtTimestamp + gracePeriodSeconds * 1000;

    if (now > maxExpiry) {
      const expiredAgoSeconds = Math.round((now - expiresAtTimestamp) / 1000);
      return {
        isValid: false,
        message: `QR Code sudah kedaluwarsa (${expiredAgoSeconds} detik yang lalu). Silakan scan QR Code terbaru di layar monitor sekolah.`,
        generatedAt: new Date(generatedTimestamp),
        expiresAt: new Date(expiresAtTimestamp),
        ageSeconds: Math.round((now - generatedTimestamp) / 1000),
      };
    }

    return {
      isValid: true,
      message: 'QR Code valid dan terverifikasi dari server sekolah.',
      generatedAt: new Date(generatedTimestamp),
      expiresAt: new Date(expiresAtTimestamp),
      ageSeconds: Math.round((now - generatedTimestamp) / 1000),
    };
  } catch (err) {
    return {
      isValid: false,
      message: 'Gagal memproses kode QR: ' + (err instanceof Error ? err.message : 'Unknown error'),
    };
  }
}

export async function generateQRCodeDataURL(text: string, size = 300): Promise<string> {
  try {
    return await QRCode.toDataURL(text, {
      width: size,
      margin: 2,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'M',
    });
  } catch (err) {
    console.error('Failed to generate QR Code:', err);
    return '';
  }
}
