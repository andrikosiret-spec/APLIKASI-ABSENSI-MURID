import { PresensiRecord, Siswa, PengaturanSekolah } from '../types';

/**
 * Format standard Indonesian phone number into WhatsApp international format (e.g. 628123456789)
 */
export function formatPhoneNumberForWhatsApp(phone: string): string {
  let cleaned = phone.replace(/[^0-9]/g, '');
  if (cleaned.startsWith('0')) {
    cleaned = '62' + cleaned.slice(1);
  } else if (cleaned.startsWith('+62')) {
    cleaned = cleaned.slice(1);
  } else if (!cleaned.startsWith('62')) {
    cleaned = '62' + cleaned;
  }
  return cleaned;
}

/**
 * Format date to Indonesian locale string (e.g. "Jumat, 14 Agustus 2026")
 */
export function formatTanggalIndonesia(dateStr: string): string {
  try {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      const date = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
      return date.toLocaleDateString('id-ID', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      });
    }
  } catch {
    // fallback
  }
  return dateStr;
}

/**
 * Generate customized WhatsApp message based on student attendance record and school settings
 */
export function generateWhatsAppMessage(
  record: PresensiRecord,
  siswa: Siswa,
  settings: PengaturanSekolah
): string {
  const tanggalIndo = formatTanggalIndonesia(record.tanggal);
  const statusUpper = record.status === 'hadir' 
    ? 'HADIR (Tepat Waktu)' 
    : record.status === 'terlambat' 
    ? `TERLAMBAT (+${record.menitKeterlambatan} menit)` 
    : record.status === 'sakit'
    ? 'SAKIT'
    : record.status === 'izin'
    ? 'IZIN'
    : 'ALPA / TIDAK HADIR';

  const defaultTemplate = record.status === 'terlambat'
    ? `🔔 *NOTIFIKASI KEHADIRAN SISWA*\n*${settings.namaSekolah}*\n\nAssalamu’alaikum Wr. Wb.\nYth. Bapak/Ibu Wali Murid dari ananda:\n\n👤 *Nama:* {NAMA}\n🔢 *NISN:* {NISN}\n🏫 *Kelas:* {KELAS}\n\n📌 *Status:* {STATUS}\n🕒 *Waktu Datang:* {WAKTU} WIB\n📅 *Hari, Tanggal:* {TANGGAL}\n⏱️ *Keterlambatan:* {MENIT_TERLAMBAT} menit dari batas masuk {JAM_MASUK} WIB\n\nMohon pendampingan agar ananda dapat hadir tepat waktu pada hari berikutnya. Terima kasih atas perhatian dan kerja samanya.\n\nWassalamu’alaikum Wr. Wb.\n_— Sistem Presensi Digital Sekolah_`
    : record.status === 'sakit' || record.status === 'izin'
    ? `📋 *INFORMASI KETIDAKHADIRAN SISWA*\n*${settings.namaSekolah}*\n\nAssalamu’alaikum Wr. Wb.\nYth. Bapak/Ibu Wali Murid dari ananda:\n\n👤 *Nama:* {NAMA}\n🔢 *NISN:* {NISN}\n🏫 *Kelas:* {KELAS}\n\n📌 *Status:* {STATUS}\n📅 *Hari, Tanggal:* {TANGGAL}\n📝 *Keterangan:* {CATATAN}\n\nData izin/sakit ananda telah tercatat dalam buku presensi wali kelas. Semoga lekas sembuh/urusan dimudahkan.\n\nWassalamu’alaikum Wr. Wb.\n_— Wali Kelas & Tata Usaha_`
    : `🔔 *NOTIFIKASI KEHADIRAN SISWA*\n*${settings.namaSekolah}*\n\nAssalamu’alaikum Wr. Wb.\nYth. Bapak/Ibu Wali Murid dari ananda:\n\n👤 *Nama:* {NAMA}\n🔢 *NISN:* {NISN}\n🏫 *Kelas:* {KELAS}\n\n📌 *Status:* {STATUS}\n🕒 *Waktu Datang:* {WAKTU} WIB\n📅 *Hari, Tanggal:* {TANGGAL}\n\nAlhamdulillah, ananda telah tiba di sekolah dan melakukan scan presensi dengan tertib dan tepat waktu.\n\nWassalamu’alaikum Wr. Wb.\n_— Sistem Presensi Digital Sekolah_`;

  let template = record.status === 'terlambat' && settings.templatePesanTerlambatWA
    ? settings.templatePesanTerlambatWA
    : (record.status === 'sakit' || record.status === 'izin') && settings.templatePesanIzinSakitWA
    ? settings.templatePesanIzinSakitWA
    : (settings.templatePesanWA || defaultTemplate);

  return template
    .replace(/{NAMA}/g, siswa.nama)
    .replace(/{NISN}/g, siswa.nisn)
    .replace(/{KELAS}/g, siswa.kelas)
    .replace(/{STATUS}/g, statusUpper)
    .replace(/{WAKTU}/g, record.waktuKedatangan)
    .replace(/{TANGGAL}/g, tanggalIndo)
    .replace(/{NAMA_ORTU}/g, siswa.namaOrangTua)
    .replace(/{SEKOLAH}/g, settings.namaSekolah)
    .replace(/{JAM_MASUK}/g, settings.jamMasuk)
    .replace(/{MENIT_TERLAMBAT}/g, String(record.menitKeterlambatan))
    .replace(/{CATATAN}/g, record.catatan || 'Keterangan tercatat di sistem');
}

/**
 * Creates direct WhatsApp Web / App intent URL
 */
export function createWhatsAppDirectUrl(phoneNumber: string, message: string): string {
  const formattedPhone = formatPhoneNumberForWhatsApp(phoneNumber);
  const encodedMessage = encodeURIComponent(message);
  return `https://api.whatsapp.com/send?phone=${formattedPhone}&text=${encodedMessage}`;
}

/**
 * Send or trigger simulated WhatsApp API gateway
 */
export async function sendWhatsAppNotification(
  record: PresensiRecord,
  siswa: Siswa,
  settings: PengaturanSekolah
): Promise<{ success: boolean; message: string; url: string; rawMessage: string }> {
  const rawMessage = generateWhatsAppMessage(record, siswa, settings);
  const formattedPhone = formatPhoneNumberForWhatsApp(siswa.noHpOrangTua);
  const url = createWhatsAppDirectUrl(siswa.noHpOrangTua, rawMessage);

  if (settings.waGatewayMode === 'fonnte_api' && settings.fonnteApiKey) {
    try {
      const response = await fetch('https://api.fonnte.com/send', {
        method: 'POST',
        headers: {
          Authorization: settings.fonnteApiKey,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          target: formattedPhone,
          message: rawMessage,
          countryCode: '62',
        }),
      });
      const data = await response.json();
      if (data.status) {
        return {
          success: true,
          message: `Notifikasi WhatsApp terkirim otomatis ke ${siswa.namaOrangTua} (${formattedPhone}) via Fonnte Gateway.`,
          url,
          rawMessage,
        };
      }
    } catch {
      // fallback to simulated/direct
    }
  }

  // Direct Web / Simulated Gateway response
  return {
    success: true,
    message: `Pesan WhatsApp siap dikirim ke ${siswa.namaOrangTua} (${formattedPhone}).`,
    url,
    rawMessage,
  };
}
