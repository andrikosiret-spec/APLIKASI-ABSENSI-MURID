import { Siswa, Guru, PengaturanSekolah, PresensiRecord, UserAccount, StatusKehadiran } from '../types';
import { DAFTAR_KELAS, INITIAL_GURU, INITIAL_PRESENSI, INITIAL_SETTINGS, INITIAL_SISWA, INITIAL_USERS } from '../data/initialData';

const STORAGE_KEYS = {
  SISWA: 'presensi_app_siswa_v1',
  GURU: 'presensi_app_guru_v1',
  PRESENSI: 'presensi_app_records_v1',
  SETTINGS: 'presensi_app_settings_v1',
  CURRENT_USER: 'presensi_app_current_user_v1',
  KELAS: 'presensi_app_kelas_v1',
  WALI_KELAS: 'presensi_app_wali_kelas_v1',
};

const CHANGE_EVENT_NAME = 'presensi_data_updated';

function triggerChangeEvent() {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(CHANGE_EVENT_NAME));
  }
}

export function subscribeToDataChanges(callback: () => void): () => void {
  if (typeof window === 'undefined') return () => {};
  window.addEventListener(CHANGE_EVENT_NAME, callback);
  window.addEventListener('storage', callback);
  return () => {
    window.removeEventListener(CHANGE_EVENT_NAME, callback);
    window.removeEventListener('storage', callback);
  };
}

// ----------------- SISWA STORAGE -----------------
export function getSiswaList(): Siswa[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SISWA);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.SISWA, JSON.stringify(INITIAL_SISWA));
      return INITIAL_SISWA;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_SISWA;
  }
}

export function saveSiswa(siswa: Siswa): void {
  const list = getSiswaList();
  const index = list.findIndex(s => s.id === siswa.id || s.nisn === siswa.nisn);
  if (index >= 0) {
    list[index] = { ...list[index], ...siswa };
  } else {
    list.push(siswa);
  }
  localStorage.setItem(STORAGE_KEYS.SISWA, JSON.stringify(list));
  triggerChangeEvent();
}

export function deleteSiswa(id: string): void {
  const list = getSiswaList().filter(s => s.id !== id);
  localStorage.setItem(STORAGE_KEYS.SISWA, JSON.stringify(list));
  triggerChangeEvent();
}

export function findSiswaByNisn(nisn: string): Siswa | undefined {
  const cleaned = nisn.trim();
  return getSiswaList().find(s => s.nisn === cleaned);
}

export function findSiswaById(id: string): Siswa | undefined {
  return getSiswaList().find(s => s.id === id);
}

// ----------------- GURU STORAGE -----------------
export function getGuruList(): Guru[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.GURU);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.GURU, JSON.stringify(INITIAL_GURU));
      return INITIAL_GURU;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_GURU;
  }
}

export function saveGuru(guru: Guru): void {
  const list = getGuruList();
  const index = list.findIndex(g => g.id === guru.id);
  if (index >= 0) {
    list[index] = { ...list[index], ...guru };
  } else {
    list.push(guru);
  }
  localStorage.setItem(STORAGE_KEYS.GURU, JSON.stringify(list));
  triggerChangeEvent();
}

export function deleteGuru(id: string): void {
  const list = getGuruList().filter(g => g.id !== id);
  localStorage.setItem(STORAGE_KEYS.GURU, JSON.stringify(list));
  triggerChangeEvent();
}

// ----------------- PRESENSI STORAGE -----------------
export function getPresensiRecords(): PresensiRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PRESENSI);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.PRESENSI, JSON.stringify(INITIAL_PRESENSI));
      return INITIAL_PRESENSI;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_PRESENSI;
  }
}

export function addPresensiRecord(record: PresensiRecord): void {
  const records = getPresensiRecords();
  // Check if existing record exists for this student on the same date
  const existingIdx = records.findIndex(r => r.siswaId === record.siswaId && r.tanggal === record.tanggal);
  if (existingIdx >= 0) {
    records[existingIdx] = record;
  } else {
    records.unshift(record);
  }
  localStorage.setItem(STORAGE_KEYS.PRESENSI, JSON.stringify(records));
  triggerChangeEvent();
}

export function updatePresensiStatus(
  siswaId: string,
  tanggal: string,
  status: StatusKehadiran,
  catatan?: string
): PresensiRecord {
  const siswa = findSiswaById(siswaId);
  if (!siswa) throw new Error('Siswa tidak ditemukan');

  const records = getPresensiRecords();
  const existingIdx = records.findIndex(r => r.siswaId === siswaId && r.tanggal === tanggal);

  const now = new Date();
  const waktuStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;

  let record: PresensiRecord;
  if (existingIdx >= 0) {
    record = {
      ...records[existingIdx],
      status,
      catatan: catatan !== undefined ? catatan : records[existingIdx].catatan,
    };
    records[existingIdx] = record;
  } else {
    record = {
      id: `PR-${tanggal.replace(/-/g, '')}-${siswa.id}`,
      siswaId: siswa.id,
      nisn: siswa.nisn,
      namaSiswa: siswa.nama,
      kelas: siswa.kelas,
      tanggal,
      waktuKedatangan: waktuStr,
      timestamp: Date.now(),
      status,
      menitKeterlambatan: status === 'terlambat' ? 10 : 0,
      metode: 'manual_guru',
      catatan,
      waTerkirim: false,
    };
    records.unshift(record);
  }

  localStorage.setItem(STORAGE_KEYS.PRESENSI, JSON.stringify(records));
  triggerChangeEvent();
  return record;
}

export function markWhatsAppSent(recordId: string, recipientText: string): void {
  const records = getPresensiRecords();
  const idx = records.findIndex(r => r.id === recordId);
  if (idx >= 0) {
    records[idx].waTerkirim = true;
    records[idx].waTerkirimPada = new Date().toISOString().replace('T', ' ').substring(0, 19);
    records[idx].waPenerima = recipientText;
    localStorage.setItem(STORAGE_KEYS.PRESENSI, JSON.stringify(records));
    triggerChangeEvent();
  }
}

export function deletePresensiRecord(recordId: string): void {
  const records = getPresensiRecords().filter(r => r.id !== recordId);
  localStorage.setItem(STORAGE_KEYS.PRESENSI, JSON.stringify(records));
  triggerChangeEvent();
}

// ----------------- KELAS STORAGE -----------------
export function getDaftarKelas(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.KELAS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.KELAS, JSON.stringify(DAFTAR_KELAS));
      return DAFTAR_KELAS;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return DAFTAR_KELAS;
  } catch {
    return DAFTAR_KELAS;
  }
}

export function saveDaftarKelas(kelasList: string[]): void {
  const unique = Array.from(new Set(kelasList.map(k => k.trim()).filter(Boolean)));
  localStorage.setItem(STORAGE_KEYS.KELAS, JSON.stringify(unique));
  triggerChangeEvent();
}

export function addKelas(namaKelas: string): boolean {
  const cleaned = namaKelas.trim().toUpperCase();
  if (!cleaned) return false;
  const list = getDaftarKelas();
  if (!list.includes(cleaned)) {
    list.push(cleaned);
    // Sort naturally or keep order
    list.sort();
    saveDaftarKelas(list);
    return true;
  }
  return false;
}

export function deleteKelas(namaKelas: string): void {
  const cleaned = namaKelas.trim();
  const list = getDaftarKelas().filter(k => k !== cleaned);
  saveDaftarKelas(list);
  deleteWaliKelasForClass(cleaned);
}

// ----------------- WALI KELAS STORAGE -----------------
const DEFAULT_WALI_MAP: Record<string, string> = {
  '7A': 'Drs. H. Rudi Hartono, M.Pd.',
  '7B': 'Siti Rahmawati, S.Pd.',
  '8A': 'Ahmad Fauzi, S.Kom., M.T.',
  '8B': 'Nurul Hidayah, M.Pd.',
  '9A': 'Bambang Sudarsono, S.Pd.',
};

export function getWaliKelasMap(): Record<string, string> {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.WALI_KELAS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.WALI_KELAS, JSON.stringify(DEFAULT_WALI_MAP));
      return DEFAULT_WALI_MAP;
    }
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_WALI_MAP, ...parsed };
  } catch {
    return DEFAULT_WALI_MAP;
  }
}

export function saveWaliKelasForClass(kelas: string, namaWali: string): void {
  const cleanedKelas = kelas.trim();
  const cleanedNama = namaWali.trim();
  const map = getWaliKelasMap();
  map[cleanedKelas] = cleanedNama;
  localStorage.setItem(STORAGE_KEYS.WALI_KELAS, JSON.stringify(map));
  triggerChangeEvent();
}

export function deleteWaliKelasForClass(kelas: string): void {
  const cleaned = kelas.trim();
  const map = getWaliKelasMap();
  delete map[cleaned];
  localStorage.setItem(STORAGE_KEYS.WALI_KELAS, JSON.stringify(map));
  triggerChangeEvent();
}

// ----------------- SETTINGS STORAGE -----------------
export function getSettings(): PengaturanSekolah {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(INITIAL_SETTINGS));
      return INITIAL_SETTINGS;
    }
    return { ...INITIAL_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return INITIAL_SETTINGS;
  }
}

export function saveSettings(settings: PengaturanSekolah): void {
  localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  triggerChangeEvent();
}

// ----------------- CURRENT USER -----------------
export function getCurrentUser(): UserAccount {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(INITIAL_USERS[0]));
      return INITIAL_USERS[0];
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_USERS[0];
  }
}

export function setCurrentUser(user: UserAccount): void {
  localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
  triggerChangeEvent();
}

export function getAllAvailableUsers(): UserAccount[] {
  return INITIAL_USERS;
}

// ----------------- RESET DATA -----------------
export function resetToDefaultData(): void {
  localStorage.setItem(STORAGE_KEYS.SISWA, JSON.stringify(INITIAL_SISWA));
  localStorage.setItem(STORAGE_KEYS.GURU, JSON.stringify(INITIAL_GURU));
  localStorage.setItem(STORAGE_KEYS.PRESENSI, JSON.stringify(INITIAL_PRESENSI));
  localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(INITIAL_SETTINGS));
  localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(INITIAL_USERS[0]));
  localStorage.setItem(STORAGE_KEYS.KELAS, JSON.stringify(DAFTAR_KELAS));
  localStorage.setItem(STORAGE_KEYS.WALI_KELAS, JSON.stringify(DEFAULT_WALI_MAP));
  triggerChangeEvent();
}
