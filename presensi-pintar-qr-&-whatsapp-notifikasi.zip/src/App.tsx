import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { LayarMonitorKiosk } from './components/LayarMonitorKiosk';
import { SiswaPortal } from './components/SiswaPortal';
import { GuruPortal } from './components/GuruPortal';
import { AdminPortal } from './components/AdminPortal';
import { UserAccount, PengaturanSekolah } from './types';
import { getCurrentUser, getSettings, subscribeToDataChanges } from './services/storage';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserAccount>(() => getCurrentUser());
  const [settings, setSettings] = useState<PengaturanSekolah>(() => getSettings());
  const [activeView, setActiveView] = useState<string>(() => {
    const user = getCurrentUser();
    return user.role === 'kiosk' ? 'kiosk' : user.role === 'siswa' ? 'siswa' : user.role === 'guru' ? 'guru' : 'admin';
  });

  useEffect(() => {
    const unsub = subscribeToDataChanges(() => {
      setSettings(getSettings());
      setCurrentUser(getCurrentUser());
    });
    return () => unsub();
  }, []);

  const handleUserChange = (newUser: UserAccount) => {
    setCurrentUser(newUser);
  };

  const handleSettingsUpdated = (newSettings: PengaturanSekolah) => {
    setSettings(newSettings);
  };

  return (
    <div className="min-h-screen bg-[#F0F9FF] text-[#1E293B] flex flex-col font-sans selection:bg-[#0EA5E9] selection:text-white">
      {/* Top Navigation Bar */}
      <Navbar
        currentUser={currentUser}
        onUserChange={handleUserChange}
        activeView={activeView}
        setActiveView={setActiveView}
        settings={settings}
      />

      {/* Main Content Body */}
      <main className="flex-1">
        {activeView === 'kiosk' && (
          <LayarMonitorKiosk
            settings={settings}
            onOpenStudentScanner={() => setActiveView('siswa')}
          />
        )}

        {activeView === 'siswa' && (
          <SiswaPortal
            currentUser={currentUser}
            settings={settings}
          />
        )}

        {activeView === 'guru' && (
          <GuruPortal
            currentUser={currentUser}
            settings={settings}
          />
        )}

        {activeView === 'admin' && (
          <AdminPortal
            settings={settings}
            onSettingsUpdated={handleSettingsUpdated}
          />
        )}
      </main>
    </div>
  );
}
